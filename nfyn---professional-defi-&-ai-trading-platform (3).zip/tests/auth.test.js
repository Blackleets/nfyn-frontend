const request = require('supertest');
const express = require('express');
const authRoutes = require('../api/routes/auth');
const User = require('../api/models/User');

// Create a new express app for testing
const app = express();
app.use(express.json());
app.use('/api/auth', authRoutes);

describe('POST /api/auth/connect', () => {
  const testWallet = 'So11111111111111111111111111111111111111112';

  it('should create a new user with a default sandbox_balance if wallet does not exist', async () => {
    const res = await request(app)
      .post('/api/auth/connect')
      .send({ wallet: testWallet });

    expect(res.statusCode).toEqual(200);
    expect(res.body).toHaveProperty('wallet', testWallet);
    expect(res.body).toHaveProperty('sandbox_balance', 10000); // Check for default
    expect(res.body).toHaveProperty('createdAt');

    const userInDb = await User.findOne({ wallet: testWallet });
    expect(userInDb).not.toBeNull();
    expect(userInDb.sandbox_balance).toBe(10000);
  });

  it('should be idempotent: return existing user if called again with the same wallet', async () => {
    // First call to create the user
    await request(app)
      .post('/api/auth/connect')
      .send({ wallet: testWallet });

    // Second call
    const res = await request(app)
      .post('/api/auth/connect')
      .send({ wallet: testWallet });
      
    expect(res.statusCode).toEqual(200);
    expect(res.body.wallet).toEqual(testWallet);

    const users = await User.find({ wallet: testWallet });
    expect(users.length).toBe(1); // Ensure no duplicate was created
  });
  
  it('should not overwrite an existing sandbox_balance', async () => {
    // Manually create a user with a different balance
    const user = new User({ wallet: testWallet, sandbox_balance: 500 });
    await user.save();
    
    const res = await request(app)
      .post('/api/auth/connect')
      .send({ wallet: testWallet });
      
    expect(res.statusCode).toEqual(200);
    expect(res.body.sandbox_balance).toBe(500); // Verify balance was not reset to default
  });

  it('should return 400 if wallet is not provided', async () => {
    const res = await request(app)
      .post('/api/auth/connect')
      .send({});
      
    expect(res.statusCode).toEqual(400);
    expect(res.body.msg).toEqual('Wallet address is required.');
  });
  
  it('should return 400 for an address with invalid format (bad characters or length)', async () => {
    const res = await request(app)
      .post('/api/auth/connect')
      .send({ wallet: 'invalid-wallet-address-with-hyphens-and-O' });
      
    expect(res.statusCode).toEqual(400);
    expect(res.body.msg).toEqual('Invalid wallet address format. Please provide a valid Base58 encoded address.');
  });
  
  it('should return 400 for a cryptographically invalid address that passes regex', async () => {
    // This string has valid characters and length, but is not a valid public key.
    // The PublicKey constructor will throw an error.
    const cryptographicallyInvalidWallet = '6X4X1v2V3s5t7u9wZzAbCdEfGhIjKlMnOpQrStUvWxYz'; // 44 chars, valid base58 chars

    const res = await request(app)
      .post('/api/auth/connect')
      .send({ wallet: cryptographicallyInvalidWallet });
      
    expect(res.statusCode).toEqual(400);
    expect(res.body.msg).toEqual('Invalid Solana wallet address.');
  });
});