const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
  // Solana wallet address, unique and indexed for fast lookups.
  wallet: {
    type: String,
    required: true,
    unique: true,
    index: true,
  },
  // Optional user name.
  name: {
    type: String,
  },
  // Sandbox balance for simulated trading.
  // This field is non-destructive:
  // - It has a default value of 10,000, which is ONLY applied when a new user document is created.
  // - It will NOT be added or modified on existing documents by Mongoose automatically.
  // - A separate migration script handles adding this to existing users safely.
  sandbox_balance: {
    type: Number,
    default: 10000,
  },
  // Array to store transaction history (schema can be defined later).
  transactions: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Transaction', // Assumes a 'Transaction' model will be created later.
    },
  ],
  // Timestamp for when the user was created.
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

module.exports = mongoose.model('User', UserSchema);
