const express = require('express');
const router = express.Router();
const User = require('../models/User');
const { PublicKey } = require('@solana/web3.js');

// @route   POST /api/auth/connect
// @desc    Connect a wallet. Creates a user if they don't exist (idempotent).
// @access  Public
router.post('/connect', async (req, res) => {
  const { wallet } = req.body;

  // Basic validation: check if wallet address is provided.
  if (!wallet) {
    return res.status(400).json({ msg: 'Wallet address is required.' });
  }

  // Security Step 1: Basic format validation with Regex.
  // This checks for valid Base58 characters and typical length (32-44 chars).
  const solanaAddressRegex = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/;
  if (!solanaAddressRegex.test(wallet)) {
    return res.status(400).json({ msg: 'Invalid wallet address format. Please provide a valid Base58 encoded address.' });
  }

  // Security Step 2: Cryptographic validation using the official Solana library.
  // This ensures the address is not just a random Base58 string but a valid public key.
  try {
    new PublicKey(wallet);
  } catch (error) {
    // This will catch addresses that are valid Base58 but not valid public keys.
    return res.status(400).json({ msg: 'Invalid Solana wallet address.' });
  }

  try {
    // This is an idempotent operation.
    // - `findOneAndUpdate` with `upsert: true` will find a user or create one if not found.
    // - `new: true` ensures the returned document is the one that was found or created.
    // - `setDefaultsOnInsert: true` is crucial. It tells Mongoose to apply the schema's
    //   default values (like sandbox_balance) ONLY when a new document is inserted (upserted).
    //   It will NOT modify an existing user who might be missing this field.
    const user = await User.findOneAndUpdate(
      { wallet: wallet },
      { $setOnInsert: { wallet: wallet } }, // Set wallet only on insert to avoid changing case
      {
        new: true,
        upsert: true,
        setDefaultsOnInsert: true,
      }
    );

    res.json(user);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

module.exports = router;