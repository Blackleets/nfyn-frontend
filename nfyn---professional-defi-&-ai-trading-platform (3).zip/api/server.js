require('dotenv').config();
const express = require('express');
const connectDB = require('./config/db');
const authRoutes = require('./routes/auth');

const app = express();

// Connect to MongoDB
connectDB();

// Init Middleware
// This allows us to accept JSON data in the body of requests.
app.use(express.json({ extended: false }));

// Define a simple root route
app.get('/', (req, res) => res.send('NFYN API Running'));

// Use Routes
app.use('/api/auth', authRoutes);

const PORT = process.env.PORT || 3001;

app.listen(PORT, () => console.log(`API Server started on port ${PORT}`));
