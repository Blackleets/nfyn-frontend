import { Coin, ScalpingTrade, FarmingPool, FuturesPosition, LpPosition, NewsArticle, KOL, EducationCourse, GovernanceProposal, LeaderboardUser, NFT, Achievement } from './types';
import { TopTraderIcon, EarlyAdopterIcon, CommunityContributorIcon } from './components/icons/BadgeIcons';

export const INITIAL_COIN_DATA: Coin[] = [
  { id: 'bitcoin', symbol: 'BTC', name: 'Bitcoin', price: 68123.45, change24h: 2.5 },
  { id: 'ethereum', symbol: 'ETH', name: 'Ethereum', price: 3543.21, change24h: -1.2 },
  { id: 'solana', symbol: 'SOL', name: 'Solana', price: 168.99, change24h: 5.8 },
  { id: 'binance-coin', symbol: 'BNB', name: 'BNB', price: 594.50, change24h: 0.5 },
  { id: 'xrp', symbol: 'XRP', name: 'XRP', price: 0.52, change24h: -0.8 },
  { id: 'cardano', symbol: 'ADA', name: 'Cardano', price: 0.45, change24h: 1.5 },
  { id: 'dogecoin', symbol: 'DOGE', name: 'Dogecoin', price: 0.15, change24h: -2.1 },
  { id: 'polygon', symbol: 'MATIC', name: 'Polygon', price: 0.71, change24h: 3.2 },
];

export const SCALPING_TRADES: ScalpingTrade[] = [
  { id: '1', symbol: 'SOL', entry: 165.20, current: 168.99, pnl: 2.29, signal: 'Buy' },
  { id: '2', symbol: 'ETH', entry: 3580.10, current: 3543.21, pnl: -1.03, signal: 'Sell' },
];

// Mocks removed as they will be managed by AI modules or fetched dynamically.
// export const FARMING_POOLS: FarmingPool[] = [ ... ];
// export const FUTURES_POSITIONS: FuturesPosition[] = [ ... ];
// export const LP_POSITIONS: LpPosition[] = [ ... ];

// NEWS_ARTICLES and KOLS are now fetched dynamically, removed from constants.
// export const NEWS_ARTICLES: NewsArticle[] = [ ... ];
// export const KOLS: KOL[] = [ ... ];


export const EDUCATION_COURSES: EducationCourse[] = [
    { id: '1', title: 'Intro to DeFi', description: 'Learn the basics of decentralized finance.', progress: 75, xp: 100 },
    { id: '2', title: 'Scalping Strategies 101', description: 'Master short-term trading techniques.', progress: 30, xp: 150 },
    { id: '3', title: 'Understanding Liquidity Pools', description: 'A deep dive into providing liquidity.', progress: 0, xp: 200 },
];

export const GOVERNANCE_PROPOSALS: GovernanceProposal[] = [
    { id: '1', title: 'Upgrade Scalping Bot to v2', status: 'Active', description: 'Proposal to implement a new algorithm based on volume profile in addition to RSI/MACD.', votesFor: 1250, votesAgainst: 340, endDate: Date.now() + 3 * 24 * 60 * 60 * 1000 },
    { id: '2', title: 'Add New Farming Aggregator', status: 'Passed', description: 'Integrate Yearn Finance pools into the farming module.', votesFor: 2100, votesAgainst: 150, endDate: Date.now() - 5 * 24 * 60 * 60 * 1000 },
    { id: '3', title: 'Reduce Futures Trading Fees', status: 'Failed', description: 'A proposal to lower simulated trading fees by 10% was rejected by the community.', votesFor: 800, votesAgainst: 1500, endDate: Date.now() - 10 * 24 * 60 * 60 * 1000 },
    { id: '4', title: 'Community Grant for Educational Content', status: 'Active', description: 'Allocate 50,000 USDT from the treasury to fund high-quality video tutorials for the Academy.', votesFor: 980, votesAgainst: 50, endDate: Date.now() + 7 * 24 * 60 * 60 * 1000 },
];

export const LEADERBOARD_DATA: { [key: string]: LeaderboardUser[] } = {
    scalping: [
        { rank: 1, name: 'TraderX', metric: '+154% PnL' },
        { rank: 2, name: 'SignalSurfer', metric: '+123% PnL' },
        { rank: 3, name: 'RSI_King', metric: '+98% PnL' },
    ],
    farming: [
        { rank: 1, name: 'YieldYoda', metric: '125% APY Avg' },
        { rank: 2, name: 'FarmerFran', metric: '110% APY Avg' },
        { rank: 3, name: 'APY_Hunter', metric: '95% APY Avg' },
    ],
    lp: [
        { rank: 1, name: 'LiquidityLord', metric: '$5,230 Fees' },
        { rank: 2, name: 'RangeRider', metric: '$4,180 Fees' },
        { rank: 3, name: 'FeeFiFoFum', metric: '$3,500 Fees' },
    ]
};

export const NFT_DATA: NFT[] = [
    { id: '1', name: 'Chrono-Synth #124', collection: 'Chrono-Synths', description: 'A sentient AI from the year 2342, encapsulated in a quantum-forged chrome shell.', imageUrl: 'https://images.unsplash.com/photo-1678830499097-78160459a1e0?w=500&q=80', traits: { Shell: 'Quantum Chrome', Core: 'Temporal Singularity' } },
    { id: '2', name: 'Aetherial Bloom #7', collection: 'Aetheria', description: 'A bioluminescent flower from a parallel dimension, pulsing with cosmic energy.', imageUrl: 'https://images.unsplash.com/photo-1684717639103-34882199b59e?w=500&q=80', traits: { Energy: 'Cosmic', Background: 'Nebula' } },
    { id: '3', name: 'Geode Golem #33', collection: 'Geode Golems', description: 'Crystalline guardian formed in the heart of a dying star. Its core hums with untold power.', imageUrl: 'https://images.unsplash.com/photo-1655027038930-1e4b3e4a2b27?w=500&q=80', traits: { Material: 'Stardust Geode', Core: 'Gravity Well' } },
    { id: '4', name: 'Chrono-Synth #256', collection: 'Chrono-Synths', description: 'This unit specializes in temporal data analysis, predicting market shifts moments before they occur.', imageUrl: 'https://images.unsplash.com/photo-1671041249568-a496f0143899?w=500&q=80', traits: { Shell: 'Obsidian Weave', Core: 'Temporal Singularity' } },
    { id: '5', name: 'Void Walker #1', collection: 'The Void', description: 'An entity that traverses the space between networks, collecting forgotten data packets.', imageUrl: 'https://images.unsplash.com/photo-1644447378632-026ac5675034?w=500&q=80', traits: { Type: 'Data Wraith', Aura: 'Glitching' } },
    { id: '6', name: 'Aetherial Bloom #42', collection: 'Aetheria', description: 'Rare variant with petals that mimic the nebulae of its home galaxy.', imageUrl: 'https://images.unsplash.com/photo-1681240134263-44872c72b02e?w=500&q=80', traits: { Energy: 'Starlight', Background: 'Galaxy' } },
    { id: '7', name: 'Geode Golem #101', collection: 'Geode Golems', description: 'Forged from pure Solana-crystal, this golem is exceptionally fast and resilient.', imageUrl: 'https://images.unsplash.com/photo-1689631375225-4527a6927424?w=500&q=80', traits: { Material: 'Solana Crystal', Core: 'Charged' } },
    { id: '8', name: 'Data-Sprite #777', collection: 'Data-Sprites', description: 'A playful being made of raw code, known to corrupt or fix systems at its whim.', imageUrl: 'https://images.unsplash.com/photo-1679085299945-8a278077553b?w=500&q=80', traits: { Encoding: 'Binary', State: 'Whimsical' } },
];

export const MOCK_QUIZ_QUESTIONS = [
    {
        "id": 1,
        "question": "What does 'DeFi' stand for?",
        "answers": {
            "answer_a": "Decentralized Finance",
            "answer_b": "Digital Finance",
            "answer_c": "Distributed Funding",
            "answer_d": null
        },
        "correct_answers": {
            "answer_a_correct": "true",
            "answer_b_correct": "false",
            "answer_c_correct": "false",
            "answer_d_correct": "false"
        }
    },
    {
        "id": 2,
        "question": "Which of the following is a characteristic of a 'DAO'?",
        "answers": {
            "answer_a": "Controlled by a single CEO",
            "answer_b": "Community-governed through voting",
            "answer_c": "Physical headquarters",
            "answer_d": "Only issues physical stock certificates"
        },
        "correct_answers": {
            "answer_a_correct": "false",
            "answer_b_correct": "true",
            "answer_c_correct": "false",
            "answer_d_correct": "false"
        }
    },
    {
        "id": 3,
        "question": "What is 'Impermanent Loss' in the context of Liquidity Pools?",
        "answers": {
            "answer_a": "The loss from a hacking incident.",
            "answer_b": "The temporary loss of funds when a transaction is pending.",
            "answer_c": "The difference in value between holding assets in a pool versus holding them in a wallet.",
            "answer_d": "A permanent loss due to a protocol bug."
        },
        "correct_answers": {
            "answer_a_correct": "false",
            "answer_b_correct": "false",
            "answer_c_correct": "true",
            "answer_d_correct": "false"
        }
    }
];

export const ACHIEVEMENTS: Achievement[] = [
    {
        id: 'early_adopter',
        name: 'Early Adopter',
        description: 'Joined the NFYN platform in its early stages. Welcome!',
        icon: EarlyAdopterIcon,
        unlocked: () => true, // Everyone gets this for now
    },
    {
        id: 'top_trader_10',
        name: 'Pro Trader',
        description: 'Achieved Level 10 through consistent performance.',
        icon: TopTraderIcon,
        unlocked: (xp, level) => level >= 10,
    },
     {
        id: 'community_pioneer',
        name: 'Community Pioneer',
        description: 'Helped shape the community by being an active participant.',
        icon: CommunityContributorIcon,
        unlocked: () => true, // Mocked as true for now
    }
];