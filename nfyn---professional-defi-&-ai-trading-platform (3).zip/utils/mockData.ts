import { HistoricalDataPoint } from '../types';

// A simple function to generate plausible historical crypto data
export const generateHistoricalData = (
  basePrice: number,
  timeframe: '1H' | '1D' | '1W' | '1M'
): HistoricalDataPoint[] => {
  const data: HistoricalDataPoint[] = [];
  let numPoints: number;
  let timeStep: number; // in milliseconds
  let volatility: number;

  switch (timeframe) {
    case '1H':
      numPoints = 60; // 60 minutes
      timeStep = 60 * 1000;
      volatility = 0.0005;
      break;
    case '1D':
      numPoints = 24; // 24 hours
      timeStep = 60 * 60 * 1000;
      volatility = 0.002;
      break;
    case '1W':
      numPoints = 7; // 7 days
      timeStep = 24 * 60 * 60 * 1000;
      volatility = 0.008;
      break;
    case '1M':
    default:
      numPoints = 30; // 30 days
      timeStep = 24 * 60 * 60 * 1000;
      volatility = 0.015;
      break;
  }

  let currentPrice = basePrice * (1 - (Math.random() - 0.5) * volatility * numPoints);
  const now = new Date().getTime();

  for (let i = numPoints; i > 0; i--) {
    const time = now - i * timeStep;
    data.push({
      time: time,
      price: parseFloat(currentPrice.toFixed(2)),
    });
    // Simulate price walk
    const change = (Math.random() - 0.48) * volatility * currentPrice; // Slight bullish bias
    currentPrice += change;
  }
  
  // Add current price point
  data.push({ time: now, price: basePrice });

  return data;
};
