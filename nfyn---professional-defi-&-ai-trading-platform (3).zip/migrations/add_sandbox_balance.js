const mongoose = require('mongoose');
const User = require('../api/models/User');
require('dotenv').config();

const MONGO_URI = process.env.MONGO_URI;
const DEFAULT_SANDBOX_BALANCE = 10000;

const runMigration = async () => {
  console.log('Starting migration: Add sandbox_balance to existing users...');
  
  try {
    // 1. Connect to the database
    await mongoose.connect(MONGO_URI);
    console.log('MongoDB connected for migration.');

    // 2. Define the filter and update operations
    // This is the core of the non-destructive approach.
    // We ONLY target documents where the 'sandbox_balance' field does NOT exist.
    const filter = { sandbox_balance: { $exists: false } };
    
    // We will SET the 'sandbox_balance' field to the default value.
    const update = { $set: { sandbox_balance: DEFAULT_SANDBOX_BALANCE } };

    // 3. Perform the update operation on multiple documents
    console.log('Finding and updating users without sandbox_balance...');
    const result = await User.updateMany(filter, update);

    // 4. Log the result of the operation
    console.log('Migration completed.');
    console.log(`- Documents matched (missing sandbox_balance): ${result.matchedCount}`);
    console.log(`- Documents updated: ${result.modifiedCount}`);
    
    if (result.matchedCount === 0) {
        console.log('All users already have the sandbox_balance field. No action was needed.');
    } else {
        console.log(`Successfully added sandbox_balance of ${DEFAULT_SANDBOX_BALANCE} to ${result.modifiedCount} users.`);
    }

  } catch (err) {
    console.error('An error occurred during migration:', err);
    console.error('\n--- MIGRATION FAILED ---');
    console.error('No data was changed in this failed attempt.');
  } finally {
    // 5. Ensure the database connection is closed
    await mongoose.disconnect();
    console.log('MongoDB connection closed.');
  }
};

// Execute the migration
runMigration();
