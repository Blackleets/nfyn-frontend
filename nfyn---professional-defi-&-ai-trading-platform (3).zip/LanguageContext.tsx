import React, { createContext, useState, useContext, useEffect, useCallback } from 'react';
import { NfynLogo } from './components/icons/Logo';

// Translations will be loaded asynchronously
const initialTranslations = {
  en: {},
  es: {},
};

type Language = 'en' | 'es';
type Translations = typeof initialTranslations;

// This function safely gets a value from a nested object
const getTranslationValue = (obj: any, key: string): string | undefined => {
  // The translation files use flat keys with dot notation (e.g., "onboarding.mainTitle").
  // This directly accesses the key instead of incorrectly trying to traverse a nested object.
  return obj ? obj[key] : undefined;
};

interface LanguageContextType {
  language: Language;
  setLanguage: (language: Language) => void;
  t: (key: string, options?: { [key: string]: string | number }) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const AppLoader: React.FC = () => (
    <div className="flex items-center justify-center min-h-screen bg-slate-50 dark:bg-slate-900">
        <div className="relative">
            <NfynLogo className="w-48 h-18" />
            <div className="absolute -bottom-6 left-0 right-0 text-center text-slate-500 dark:text-slate-400 text-sm font-medium">
                Loading Interface...
            </div>
        </div>
    </div>
);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('en');
  const [translations, setTranslations] = useState<Translations>(initialTranslations);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Detect browser language
    const browserLang = navigator.language.split('-')[0];
    if (browserLang === 'es') {
      setLanguage('es');
    }

    // Fetch translation files
    const fetchTranslations = async () => {
      try {
        const [enResponse, esResponse] = await Promise.all([
          fetch('./locales/en.json'),
          fetch('./locales/es.json')
        ]);
        const enData = await enResponse.json();
        const esData = await esResponse.json();
        setTranslations({ en: enData, es: esData });
      } catch (error) {
        console.error("Failed to load translation files:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchTranslations();
  }, []);

  const t = useCallback((key: string, options?: { [key: string]: string | number }) => {
    const translationSet = translations[language];
    let translation = getTranslationValue(translationSet, key) || key;

    if (options) {
      Object.keys(options).forEach(optionKey => {
        translation = translation.replace(`{{${optionKey}}}`, String(options[optionKey]));
      });
    }
    return translation;
  }, [language, translations]);
  
  if (isLoading) {
    return <AppLoader />;
  }

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useTranslation = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useTranslation must be used within a LanguageProvider');
  }
  return context;
};