import React from 'react';




export interface AppNotification {
  id: number;
  message: string;
  read: boolean;
}

export interface Coin {
  id:string;
  symbol: string;
  name: string;
  price: number;
  change24h: number;
}

export interface LiveCoin extends Coin {
  logoUrl: string;
  sparklineData: number[];
  marketCap?: number;
  volume24h?: number;
}

export interface ScalpingTrade {
  id: string;
  symbol: string;
  entry: number;
  current: number;
  pnl: number;
  signal: 'Buy' | 'Sell';
}

export interface FarmingPool {
  id: string;
  platform: string;
  pair: string;
  apy: number;
  risk: 'Low' | 'Medium' | 'High';
  stakedAmount?: number;
  rewardsEarned?: number;
}

export interface FuturesPosition {
  id: string;
  symbol: string;
  leverage: number;
  entry: number;
  pnl: number;
  side: 'Long' | 'Short';
  size: number;
  currentPrice?: number;
}

export interface LpPosition {
    id: string;
    pair: string;
    rangeMin: number;
    rangeMax: number;
    fees: number;
    il: number;
    liquidityProvided: number; // e.g., in USD value
}

export interface NewsArticle {
  id: string;
  title: string;
  source: string;
  summary: string;
  impact?: 'Bullish' | 'Bearish' | 'Neutral';
  link: string;
}

// For externally fetched news data
export interface ApiNewsArticle {
  id: string;
  title: string;
  summary: string;
  imageUrl: string;
  source: string;
  articleUrl: string;
  publishedAt: string;
}


export interface KOL {
  id: string;
  name: string;
  handle: string;
  score: number;
  latestSignal: string;
}

export interface EducationCourse {
    id: string;
    title: string;
    description: string;
    progress: number;
    xp: number;
}

export interface GovernanceProposal {
    id: string;
    title: string;
    status: 'Active' | 'Passed' | 'Failed';
    description: string;
    votesFor: number;
    votesAgainst: number;
    endDate: number;
}

export interface LeaderboardUser {
    rank: number;
    name: string;
    metric: string;
}

export interface BotTrade {
  id: string;
  symbol: string;
  side: 'Buy' | 'Sell';
  entryPrice: number;
  currentPrice: number;
  exitPrice?: number;
  size: number; // in USD
  pnl?: number; // in USD
  status: 'Open' | 'Closed';
  timestamp: number;
}

export interface BotEvent {
  id: string;
  timestamp: number;
  module: ModuleName | 'System';
  message: string;
  pnl?: number;
}

export type ModuleName = 'Scalping' | 'Grid' | 'Sniper' | 'Farming' | 'LP' | 'Futures';
export type ScalpingRiskProfile = 'Conservative' | 'Moderate' | 'Aggressive';

export interface ModuleState {
    name: ModuleName;
    capital: number;
    pnl: number;
    status: 'Active' | 'Idle' | 'Error';
    
    // Scalping & Sniper config
    stopLossPercent?: number;
    takeProfitPercent?: number;
    positionSizePercent?: number;
    
    // Scalping-specific metrics
    totalTrades?: number;
    wins?: number;
    winRate?: number;
    openPositions?: BotTrade[];
    closedTrades?: BotTrade[];
    
    // Grid config
    gridCount?: number;
    upperPrice?: number;
    lowerPrice?: number;
    gridStopLossPrice?: number;
    gridTakeProfitPrice?: number;

    // Sniper-specific metrics
    snipes?: number;
    avgProfit?: number;

    // Farming-specific config & metrics
    farmingPools?: FarmingPool[]; // List of pools the bot is managing
    minApyThreshold?: number; // AI uses this to find opportunities
    
    // LP-specific config & metrics
    lpPositions?: LpPosition[]; // List of LP positions
    rangeTolerance?: number; // AI uses this to optimize ranges

    // Futures-specific config & metrics
    futuresPositions?: FuturesPosition[];
    maxLeverage?: number;
    fundingRateThreshold?: number; // AI uses this for funding rate analysis
}

export interface ScheduledEvent {
  id: string;
  title: string;
  description: string;
  dueDate: number; // timestamp
  recurrence: 'None' | 'Daily' | 'Weekly';
  completed: boolean;
}

// Gemini Chat Types - this is for the AI assistant
export interface ChatMessage {
  role: 'user' | 'model';
  parts: { text: string }[];
}

// Community Chat Types
export interface CommunityUser {
    id: string;
    name: string;
    avatarUrl: string;
    isOnline: boolean;
}

export interface CommunityMessage {
    id: string;
    userId: string;

    text: string;
    timestamp: number;
}

export type ChatChannel = 'Global' | 'DeFi' | 'NFTs' | 'Memecoins' | 'DMs';

export interface HistoricalDataPoint {
  time: number;
  price: number;
}

export interface NFT {
  id: string;
  name: string;
  collection: string;
  description: string;
  imageUrl: string;
  traits?: { [key: string]: string; };
}

export type Screen = 'Dashboard' | 'Trade' | 'Automate' | 'Market' | 'Tokens' | 'Simulation' | 'Intel' | 'Academy' | 'Governance' | 'Profile' | 'MarketOverview' | 'Community';

export interface SentimentData {
    classification: 'Bullish' | 'Bearish' | 'Neutral';
    confidenceScores: {
        bullish: number;
        bearish: number;
        neutral: number;
    };
}

// Charting Data Types
export interface HistoricalPriceData {
  time: number; // unix timestamp in seconds
  value: number;
}

export interface HistoricalVolumeData extends HistoricalPriceData {
  color: string;
}

export interface HistoricalOHLCData {
  time: number; // unix timestamp in seconds
  open: number;
  high: number;
  low: number;
  close: number;
}

export interface ChartData {
    priceData: HistoricalPriceData[];
    volumeData: HistoricalVolumeData[];
    ohlcData: HistoricalOHLCData[];
    rsiData: { time: number; value: number }[];
}

export interface TrendingCoin {
  id: string;
  name: string;
  symbol: string;
  thumb: string;
  market_cap_rank?: number;
}
export interface TickerAsset {
  symbol: string;
  price: number | null;
  change: number | null;
}

export interface AISignal {
    id: string;
    asset: 'BTC' | 'ETH' | 'SOL';
    type: 'BUY' | 'SELL';
    strength: 'High' | 'Medium' | 'Low';
    timestamp: number;
}

export interface ProfileData {
  username: string;
  displayName: string;
  email: string;
  avatar: string; // base64 string
}

export interface Achievement {
    id: string;
    name: string;
    description: string;
    icon: React.FC<{className?: string}>;
    unlocked: (xp: number, level: number) => boolean;
}

export interface FearAndGreedIndex {
  value: number;
  value_classification: string;
  timestamp: string;
}

export interface MarketMover {
  id: string;
  name: string;
  symbol: string;
  logoUrl: string;
  price: number;
  change24h: number;
  sparkline: number[];
}

// --- NEW AI TRADING MODULE TYPES ---

export interface TrendAnalysisResult {
  direction: 'Bullish' | 'Bearish' | 'Neutral';
  entrySuggestion: string; // e.g., "Consider long entry above $X"
  exitSuggestion: string;  // e.g., "Consider short entry below $Y"
  confidence: number; // 0-100
  reasoning: string;
}

export interface FuturesFundingAnalysis {
  prediction: 'LongBias' | 'ShortBias' | 'Neutral'; // Indicates if funding favors long/short or is neutral
  reasoning: string;
  optimalLeverage?: number; // AI suggested leverage
}

export interface YieldFarmingOpportunity {
  protocol: string;
  pair: string;
  apy: number; // Estimated APY
  risk: 'Low' | 'Medium' | 'High';
  reasoning: string;
}

export interface LpRecommendation {
  minPrice: number;
  maxPrice: number;
  reasoning: string;
  feeTier: '0.05%' | '0.3%' | '1%'; // Uniswap V3 fee tiers
}

// --- NEW TOKEN DISCOVERY HUB TYPES ---

export type TokenNetwork = 'Ethereum' | 'Solana' | 'BSC' | 'Arbitrum' | 'Polygon';
export type TokenAge = 'new' | '1d' | '7d' | '30d'; // 'new' for under 1 hour, '1d' for 1-24 hours, etc.

export interface NewTokenLaunch {
  id: string;
  name: string;
  symbol: string;
  logoUrl: string;
  network: TokenNetwork;
  price: number;
  change24h: number;
  marketCap: number; // Initial/Current Market Cap
  liquidity: number; // Current Liquidity in USD
  volume24h: number; // 24h Trading Volume
  launchDate: number; // Unix timestamp
  contractAddress: string;
  description: string;
  hasAudit: boolean; // Indicates if contract has been audited
  // AI analysis will be merged into this object
  aiAnalysis?: AITokenAnalysisResult;
}

export interface AITokenAnalysisResult {
  safety: 'Very Low' | 'Low' | 'Medium' | 'High' | 'Very High'; // e.g., based on audit, liquidity, tokenomics
  potential: 'Very Low' | 'Low' | 'Medium' | 'High' | 'Very High'; // e.g., based on market cap, volume, narrative
  reasoning: string;
}

// --- NEW DASHBOARD TYPES ---

export type WidgetId = 'balance' | 'priceChart' | 'aiPortfolioInsights' | 'marketSummary' | 'aiSignals' | 'kolWatchlist' | 'newsFeed';

export interface WidgetConfig {
  id: WidgetId;
  visible: boolean;
}

export interface AIPortfolioAnalysis {
  riskScore: number; // 0-100
  riskLevel: 'Low' | 'Medium' | 'High';
  recommendation: string;
  analysis: string;
}