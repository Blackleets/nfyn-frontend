import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, TrendingUp, BarChart } from 'lucide-react';
import { Asset } from '../pages/market';
import { fetchHistoricalData } from '../../services/coingeckoService';
import { ChartData } from '../../types';

type Timeframe = '1D' | '7D' | '1M' | '1Y';

// --- HELPER FUNCTIONS ---
const formatLargeNumber = (num: number): string => {
    if (num >= 1_000_000_000_000) return `$${(num / 1_000_000_000_000).toFixed(2)}T`;
    if (num >= 1_000_000_000) return `$${(num / 1_000_000_000).toFixed(2)}B`;
    if (num >= 1_000_000) return `$${(num / 1_000_000).toFixed(2)}M`;
    return `$${num.toLocaleString()}`;
};
const formatPrice = (price: number) => {
    if (price > 100) return price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    if (price < 0.01) return price.toLocaleString('en-US', { minimumFractionDigits: 4, maximumFractionDigits: 6 });
    return price.toLocaleString('en-US', { minimumFractionDigits: 4, maximumFractionDigits: 4 });
};

// --- CHILD COMPONENTS ---

const ToggleButton: React.FC<{ label: string; active: boolean; onClick: () => void }> = ({ label, active, onClick }) => (
    <button
        onClick={onClick}
        className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors duration-200 ${
            active ? 'bg-accent-cyan text-slate-900 shadow-md' : 'bg-slate-700/50 text-slate-300 hover:bg-slate-600/50'
        }`}
    >
        {label}
    </button>
);


// --- MAIN MODAL COMPONENT ---

interface ChartModalProps {
    asset: Asset;
    onClose: () => void;
}

const ChartModal: React.FC<ChartModalProps> = ({ asset, onClose }) => {
    const [chartData, setChartData] = useState<ChartData | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [activeTimeframe, setActiveTimeframe] = useState<Timeframe>('1M');

    const timeframeMap: Record<Timeframe, number> = { '1D': 1, '7D': 7, '1M': 30, '1Y': 365 };

    useEffect(() => {
        const loadChartData = async () => {
            setIsLoading(true);
            const data = await fetchHistoricalData(asset.id, timeframeMap[activeTimeframe]);
            setChartData(data); // Keep fetching to simulate loading for the placeholder
            setIsLoading(false);
        };
        loadChartData();
    }, [asset.id, activeTimeframe]);


    const isPositive = asset.change24h !== null && asset.change24h >= 0;

    return (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 bg-black/70 backdrop-blur-md flex items-center justify-center" onClick={onClose}>
            <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                className="w-[95%] h-[90%] max-w-6xl bg-[#0A0D18] border border-slate-700 rounded-2xl shadow-2xl shadow-black/50 flex flex-col"
                onClick={e => e.stopPropagation()}
            >
                <header className="flex items-center justify-between p-4 border-b border-slate-800 flex-wrap gap-y-2">
                    <div className="flex items-center gap-4">
                        {asset.logoUrl && <img src={asset.logoUrl} alt={asset.name} className="w-10 h-10 rounded-full" />}
                        <div><h2 className="text-xl md:text-2xl font-bold text-white">{asset.name}</h2><p className="text-sm text-slate-400">{asset.symbol}/USD</p></div>
                    </div>
                    <div className="flex items-center gap-2 md:gap-4">
                        <div className="flex items-center gap-2 p-1 bg-slate-800 rounded-lg">
                            {Object.keys(timeframeMap).map(tf => <ToggleButton key={tf} label={tf} active={activeTimeframe === tf} onClick={() => setActiveTimeframe(tf as Timeframe)} />)}
                        </div>
                    </div>
                    <button onClick={onClose} className="p-2 text-slate-400 rounded-full hover:bg-slate-800 hover:text-white transition-colors"><X size={24} /></button>
                </header>

                <div className="flex-grow flex flex-col md:flex-row p-4 gap-4 overflow-hidden">
                    <div className="relative flex-grow h-full min-h-[300px] flex items-center justify-center bg-slate-900/30 rounded-lg">
                        {isLoading ? (
                            <div className="text-center">
                                 <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }} className="w-8 h-8 border-2 border-t-accent-cyan border-slate-700 rounded-full mx-auto" />
                                 <p className="text-slate-400 mt-2 text-sm">Loading Chart Data...</p>
                            </div>
                        ) : (
                            <div className="text-center text-slate-400 p-4">
                                <BarChart size={48} className="mx-auto text-slate-600 mb-4" />
                                <h3 className="font-semibold text-lg text-slate-300">Chart Temporarily Unavailable</h3>
                                <p className="text-sm mt-1">Our charting service is currently under maintenance.</p>
                            </div>
                        )}
                    </div>
                    <aside className="w-full md:w-64 flex-shrink-0 bg-slate-900/50 rounded-lg p-4 space-y-4 overflow-y-auto">
                        <h3 className="text-lg font-bold text-white">Key Metrics</h3>
                        <div className="space-y-3 text-sm">
                            {asset.price !== null && <div className="flex justify-between items-baseline"><span className="text-slate-400">Price</span><span className="font-mono text-lg font-bold text-white">${formatPrice(asset.price)}</span></div>}
                            <div className="flex justify-between items-baseline"><span className="text-slate-400">24h Change</span><span className={`font-mono font-bold ${isPositive ? 'text-neon-green' : 'text-accent-red'}`}>{asset.change24h !== null ? `${isPositive ? '+' : ''}${asset.change24h.toFixed(2)}%` : '--'}</span></div>
                            {asset.marketCap != null && (<div className="flex justify-between items-baseline"><span className="text-slate-400">Market Cap</span><span className="font-mono font-bold text-white">{formatLargeNumber(asset.marketCap)}</span></div>)}
                            {asset.volume24h != null && (<div className="flex justify-between items-baseline"><span className="text-slate-400">Volume (24h)</span><span className="font-mono font-bold text-white">{formatLargeNumber(asset.volume24h)}</span></div>)}
                        </div>
                        <button className="w-full mt-4 bg-gradient-to-r from-accent-cyan to-accent-purple text-slate-900 font-bold py-3 rounded-lg flex items-center justify-center gap-2 hover:opacity-90 transition-opacity"><TrendingUp size={20} /> Trade {asset.symbol}</button>
                    </aside>
                </div>
            </motion.div>
        </motion.div>
    );
};

export default ChartModal;
