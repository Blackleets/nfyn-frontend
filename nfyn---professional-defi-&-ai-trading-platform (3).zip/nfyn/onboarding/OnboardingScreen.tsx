import React from 'react';
import { motion } from 'framer-motion';
import { NfynLogo } from '../../components/icons/Logo';
import { useTranslation } from '../../LanguageContext';
import { ArrowRight } from 'lucide-react';

interface OnboardingScreenProps {
  onComplete: () => void;
}

const OnboardingScreen: React.FC<OnboardingScreenProps> = ({ onComplete }) => {
  const { t } = useTranslation();

  return (
    <div className="fixed inset-0 bg-dark-bg text-white flex flex-col items-center justify-center p-4 font-sans overflow-hidden">
      {/* Background VFX */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        <div className="absolute -top-1/4 -left-1/4 w-1/2 h-1/2 bg-accent-purple/30 rounded-full filter blur-3xl opacity-50 animate-pulse" style={{ animationDelay: '0s' }}></div>
        <div className="absolute -bottom-1/4 -right-1/4 w-1/2 h-1/2 bg-accent-cyan/30 rounded-full filter blur-3xl opacity-50 animate-pulse" style={{ animationDelay: '2s' }}></div>
      </div>

      <div className="relative z-10 w-full max-w-2xl mx-auto flex flex-col items-center text-center">
          
          <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
          >
              <NfynLogo className="w-48 h-24" />
          </motion.div>

          <motion.h1 
              className="text-4xl md:text-6xl font-extrabold mt-8 bg-clip-text text-transparent bg-gradient-to-r from-accent-cyan to-accent-purple"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.5, ease: 'easeOut' }}
          >
              {t('onboarding.mainTitle')}
          </motion.h1>

          <motion.p 
              className="text-lg md:text-xl text-slate-300 mt-6 max-w-xl"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.7, ease: 'easeOut' }}
          >
              {t('onboarding.mainSubtitle')}
          </motion.p>

          <motion.button
              onClick={onComplete}
              className="mt-12 group relative inline-flex items-center justify-center px-8 py-4 text-lg font-bold text-white bg-gradient-to-r from-accent-cyan to-accent-purple rounded-lg overflow-hidden shadow-lg shadow-cyan-500/20"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.9, ease: 'easeOut' }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.98 }}
          >
              <span className="absolute inset-0 bg-gradient-to-r from-accent-cyan to-accent-purple opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-gradient-shine bg-[length:200%_auto]"></span>
              <span className="relative flex items-center gap-2">
                  {t('onboarding.mainCta')}
                  <ArrowRight className="transition-transform duration-300 group-hover:translate-x-1" />
              </span>
          </motion.button>
      </div>
    </div>
  );
};

export default OnboardingScreen;