

import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, ChevronDown, ArrowUp, ArrowDown, LayoutGrid, List, Star } from 'lucide-react';
import Card from '../../components/Card';
import { fetchMarketData } from '../../services/coingeckoService';
import { LiveCoin } from '../../types';
import ChartModal from '../components/ChartModal';
import SkeletonLoader from '../../components/SkeletonLoader';
import { useTranslation } from '../../LanguageContext';

// The Asset type is what ChartModal expects. It's essentially the same as LiveCoin.
export type Asset = LiveCoin;

// Expanded list of coin IDs for this screen
const MARKET_COIN_IDS = [
    'bitcoin', 'ethereum', 'solana', 'binancecoin', 'xrp', 'cardano', 'dogecoin', 'polygon', 'tether',
    'shiba-inu', 'pepe', 'the-open-network', 'bonk', 'polkadot', 'tron', 'litecoin', 'near', 'chainlink',
    'uniswap', 'avalanche-2', 'bitcoin-cash', 'stellar', 'internet-computer', 'filecoin', 'render-token',
    'hedera-hashgraph', 'fantom', 'algorand', 'the-graph'
];

// --- Sub-components for Market Screen ---

const AssetCard: React.FC<{ asset: Asset; onClick: () => void; isWatched: boolean; onToggleWatchlist: (id: string) => void; }> = ({ asset, onClick, isWatched, onToggleWatchlist }) => {
    const isPositive = asset.change24h >= 0;
    return (
        <motion.div
            layout
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            transition={{ type: 'spring', stiffness: 300, damping: 25 }}
            whileHover={{ scale: 1.05, y: -5, boxShadow: isPositive ? '0 0 20px rgba(140, 255, 0, 0.4)' : '0 0 20px rgba(239, 68, 68, 0.4)' }}
        >
            <Card className="p-3 h-full flex flex-col justify-between cursor-pointer" highlight={isPositive ? 'green' : 'red'} onClick={onClick}>
                <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                        <img src={asset.logoUrl} alt={asset.name} className="w-8 h-8 rounded-full" />
                        <div>
                            <p className="font-bold text-slate-50">{asset.symbol}</p>
                            <p className="text-xs text-slate-400 truncate w-20">{asset.name}</p>
                        </div>
                    </div>
                     <button onClick={(e) => { e.stopPropagation(); onToggleWatchlist(asset.id); }} className="text-slate-500 hover:text-glovo-yellow transition-colors z-10">
                        <Star size={18} className={isWatched ? 'fill-current text-glovo-yellow' : ''} />
                    </button>
                </div>
                <div className="mt-3 text-right">
                    <p className="font-mono font-semibold text-slate-50">${asset.price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: asset.price > 1 ? 2 : 6 })}</p>
                    <p className={`text-sm font-bold flex items-center justify-end gap-1 ${isPositive ? 'text-accent-green' : 'text-accent-red'}`}>
                        {isPositive ? <ArrowUp size={14} /> : <ArrowDown size={14} />} {asset.change24h.toFixed(2)}%
                    </p>
                </div>
            </Card>
        </motion.div>
    );
};

const AssetRow: React.FC<{ asset: Asset; onClick: () => void; isWatched: boolean; onToggleWatchlist: (id: string) => void; }> = ({ asset, onClick, isWatched, onToggleWatchlist }) => {
    const isPositive = asset.change24h >= 0;
    return (
        <motion.tr
            layout
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="border-b border-slate-800 last:border-b-0 hover:bg-slate-800/50 cursor-pointer transition-colors"
            onClick={onClick}
        >
            <td className="p-3">
                <div className="flex items-center gap-3">
                    <button onClick={(e) => { e.stopPropagation(); onToggleWatchlist(asset.id); }} className="text-slate-500 hover:text-glovo-yellow transition-colors z-10">
                        <Star size={18} className={isWatched ? 'fill-current text-glovo-yellow' : ''} />
                    </button>
                    <img src={asset.logoUrl} alt={asset.name} className="w-8 h-8 rounded-full" />
                    <div>
                        <p className="font-bold text-slate-50">{asset.name}</p>
                        <p className="text-xs text-slate-400">{asset.symbol}</p>
                    </div>
                </div>
            </td>
            <td className="p-3 text-right font-mono text-slate-50">${asset.price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: asset.price > 1 ? 2 : 6 })}</td>
            <td className={`p-3 text-right font-mono font-bold ${isPositive ? 'text-accent-green' : 'text-accent-red'}`}>{isPositive && '+'}{asset.change24h.toFixed(2)}%</td>
            <td className="p-3 text-right font-mono text-slate-300 hidden md:table-cell">${(asset.marketCap ?? 0).toLocaleString()}</td>
            <td className="p-3 text-right font-mono text-slate-300 hidden lg:table-cell">${(asset.volume24h ?? 0).toLocaleString()}</td>
        </motion.tr>
    );
};


// --- Main Component ---
interface MarketMosaicScreenProps {
    watchlist: string[];
    toggleWatchlist: (coinId: string) => void;
}

const MarketMosaicScreen: React.FC<MarketMosaicScreenProps> = ({ watchlist, toggleWatchlist }) => {
    const { t } = useTranslation();
    const [assets, setAssets] = useState<Asset[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [sortBy, setSortBy] = useState('marketCap-desc');
    const [selectedAsset, setSelectedAsset] = useState<Asset | null>(null);
    const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

    useEffect(() => {
        const loadMarketData = async () => {
            setIsLoading(true);
            const data = await fetchMarketData(MARKET_COIN_IDS);
            setAssets(data);
            setIsLoading(false);
        };
        loadMarketData();
        const interval = setInterval(loadMarketData, 60000); // Refresh every minute
        return () => clearInterval(interval);
    }, []);

    const filteredAndSortedAssets = useMemo(() => {
        let filtered = assets.filter(asset =>
            asset.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            asset.symbol.toLowerCase().includes(searchTerm.toLowerCase())
        );

        return filtered.sort((a, b) => {
            const [key, direction] = sortBy.split('-');
            const valA = a[key as keyof Asset] ?? 0;
            const valB = b[key as keyof Asset] ?? 0;

            if (typeof valA === 'number' && typeof valB === 'number') {
                return direction === 'asc' ? valA - valB : valB - valA;
            }
            if (typeof valA === 'string' && typeof valB === 'string') {
                return direction === 'asc' ? valA.localeCompare(valB) : valB.localeCompare(valA);
            }
            return 0;
        });
    }, [assets, searchTerm, sortBy]);

    const sortOptions = [
        { value: 'marketCap-desc', label: t('market.sort.marketCapDesc', {defaultValue: 'Market Cap Desc'}) },
        { value: 'marketCap-asc', label: t('market.sort.marketCapAsc', {defaultValue: 'Market Cap Asc'}) },
        { value: 'price-desc', label: t('market.sort.priceDesc', {defaultValue: 'Price Desc'}) },
        { value: 'price-asc', label: t('market.sort.priceAsc', {defaultValue: 'Price Asc'}) },
        { value: 'change24h-desc', label: t('market.sort.changeDesc', {defaultValue: '24h Change Desc'}) },
        { value: 'change24h-asc', label: t('market.sort.changeAsc', {defaultValue: '24h Change Asc'}) },
        { value: 'name-asc', label: t('market.sort.nameAsc', {defaultValue: 'Name A-Z'}) },
    ];

    return (
        <div className="p-4 md:p-6 space-y-6">
            <h1 className="text-3xl font-bold font-orbitron bg-gradient-to-r from-accent-cyan to-accent-purple text-transparent bg-clip-text">{t('market.title', {defaultValue: 'Market Explorer'})}</h1>

            <Card className="p-4">
                <div className="flex flex-wrap items-center gap-4">
                    <div className="relative flex-grow min-w-[200px]">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                        <input
                            type="text"
                            placeholder={t('market.searchPlaceholder', {defaultValue: 'Search asset...'})}
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                            className="w-full bg-slate-700 border-2 border-transparent focus:border-accent-cyan focus:ring-0 rounded-lg pl-10 pr-4 py-2 text-sm"
                        />
                    </div>
                    <div className="relative flex-grow min-w-[200px]">
                        <select
                            value={sortBy}
                            onChange={e => setSortBy(e.target.value)}
                            className="w-full appearance-none bg-slate-700 border-2 border-transparent focus:border-accent-cyan focus:ring-0 rounded-lg px-4 py-2 text-sm"
                        >
                            {sortOptions.map(opt => <option key={opt.value} value={opt.value} className="bg-slate-800">{opt.label}</option>)}
                        </select>
                        <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 pointer-events-none" />
                    </div>
                    <div className="flex items-center p-1 bg-slate-700 rounded-lg">
                        <button onClick={() => setViewMode('grid')} className={`p-2 rounded-md transition-colors ${viewMode === 'grid' ? 'bg-slate-600' : 'text-slate-400'}`}><LayoutGrid size={20} /></button>
                        <button onClick={() => setViewMode('list')} className={`p-2 rounded-md transition-colors ${viewMode === 'list' ? 'bg-slate-600' : 'text-slate-400'}`}><List size={20} /></button>
                    </div>
                </div>
            </Card>

            {isLoading ? (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
                    {[...Array(18)].map((_, i) => <SkeletonLoader key={i} className="h-40 rounded-2xl" />)}
                </div>
            ) : viewMode === 'grid' ? (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
                    <AnimatePresence>
                        {filteredAndSortedAssets.map(asset => <AssetCard key={asset.id} asset={asset} onClick={() => setSelectedAsset(asset)} isWatched={watchlist.includes(asset.id)} onToggleWatchlist={toggleWatchlist} />)}
                    </AnimatePresence>
                </div>
            ) : (
                <Card className="overflow-x-auto">
                    <table className="w-full text-sm">
                        <thead className="bg-slate-800/50">
                            <tr>
                                <th className="p-3 text-left font-semibold text-slate-300">Asset</th>
                                <th className="p-3 text-right font-semibold text-slate-300">Price</th>
                                <th className="p-3 text-right font-semibold text-slate-300">24h %</th>
                                <th className="p-3 text-right font-semibold text-slate-300 hidden md:table-cell">Market Cap</th>
                                <th className="p-3 text-right font-semibold text-slate-300 hidden lg:table-cell">Volume (24h)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <AnimatePresence>
                                {filteredAndSortedAssets.map(asset => <AssetRow key={asset.id} asset={asset} onClick={() => setSelectedAsset(asset)} isWatched={watchlist.includes(asset.id)} onToggleWatchlist={toggleWatchlist} />)}
                            </AnimatePresence>
                        </tbody>
                    </table>
                </Card>
            )}

            <AnimatePresence>
                {selectedAsset && <ChartModal asset={selectedAsset} onClose={() => setSelectedAsset(null)} />}
            </AnimatePresence>
        </div>
    );
};

export default MarketMosaicScreen;