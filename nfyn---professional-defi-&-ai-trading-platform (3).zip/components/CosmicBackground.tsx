import React, { useRef, useEffect } from 'react';

const CosmicBackground: React.FC = () => {
    const canvasRef = useRef<HTMLCanvasElement>(null);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        let width = canvas.width = window.innerWidth;
        let height = canvas.height = window.innerHeight;
        let stars: Star[] = [];
        let shootingStars: ShootingStar[] = [];

        const handleResize = () => {
            width = canvas.width = window.innerWidth;
            height = canvas.height = window.innerHeight;
            stars = createStars(Math.floor(width * height / 4000));
        };
        
        window.addEventListener('resize', handleResize);

        interface Star {
            x: number;
            y: number;
            radius: number;
            alpha: number;
            vx: number;
            vy: number;
        }
        
        interface ShootingStar {
            x: number;
            y: number;
            len: number;
            angle: number;
            speed: number;
            opacity: number;
        }

        const createStars = (count: number): Star[] => {
            const newStars: Star[] = [];
            for (let i = 0; i < count; i++) {
                newStars.push({
                    x: Math.random() * width,
                    y: Math.random() * height,
                    radius: Math.random() * 1.2 + 0.3,
                    alpha: Math.random() * 0.5 + 0.5,
                    vx: (Math.random() - 0.5) * 0.05,
                    vy: (Math.random() - 0.5) * 0.05,
                });
            }
            return newStars;
        };
        
        const createShootingStar = () => {
            shootingStars.push({
                x: Math.random() * width,
                y: Math.random() * height,
                len: Math.random() * 80 + 10,
                angle: Math.random() * Math.PI * 2,
                speed: Math.random() * 5 + 3,
                opacity: 1,
            });
        }

        stars = createStars(Math.floor(width * height / 4000));
        let animationFrameId: number;

        const animate = () => {
            ctx.clearRect(0, 0, width, height);
            
            // Draw stars
            stars.forEach(star => {
                star.x += star.vx;
                star.y += star.vy;

                if (star.x < 0) star.x = width;
                if (star.x > width) star.x = 0;
                if (star.y < 0) star.y = height;
                if (star.y > height) star.y = 0;
                
                const twinkle = Math.random() > 0.995;
                ctx.fillStyle = `rgba(255, 255, 255, ${twinkle ? Math.random() * 0.7 + 0.3 : star.alpha})`;
                
                ctx.beginPath();
                ctx.arc(star.x, star.y, Math.max(0.1, star.radius), 0, Math.PI * 2);
                ctx.fill();
            });
            
            // Draw and update shooting stars
            if (Math.random() < 0.01 && shootingStars.length < 3) {
                createShootingStar();
            }

            shootingStars.forEach((star, index) => {
                star.x += Math.cos(star.angle) * star.speed;
                star.y += Math.sin(star.angle) * star.speed;
                star.opacity -= 0.01;

                if (star.opacity <= 0) {
                    shootingStars.splice(index, 1);
                } else {
                    ctx.beginPath();
                    ctx.moveTo(star.x, star.y);
                    ctx.lineTo(star.x - Math.cos(star.angle) * star.len, star.y - Math.sin(star.angle) * star.len);
                    ctx.strokeStyle = `rgba(0, 240, 255, ${star.opacity})`;
                    ctx.lineWidth = 1.5;
                    ctx.stroke();
                }
            });

            animationFrameId = requestAnimationFrame(animate);
        };

        animate();

        return () => {
            cancelAnimationFrame(animationFrameId);
            window.removeEventListener('resize', handleResize);
        };
    }, []);

    return <canvas ref={canvasRef} className="fixed top-0 left-0 -z-10" />;
};

export default CosmicBackground;