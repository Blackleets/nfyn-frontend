import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AppNotification } from '../types';
import { useTranslation } from '../LanguageContext';
import { X, Bell, Trash2 } from 'lucide-react';

interface NotificationPanelProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: AppNotification[];
  onClear: () => void;
}

const NotificationPanel: React.FC<NotificationPanelProps> = ({ isOpen, onClose, notifications, onClear }) => {
  const { t } = useTranslation();

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 z-40"
          />
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            className="fixed top-0 right-0 h-full w-full max-w-md bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl border-l border-slate-200 dark:border-slate-700 z-50 flex flex-col"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-700 flex-shrink-0">
              <h2 className="text-xl font-bold text-slate-900 dark:text-slate-50 flex items-center gap-2">
                <Bell /> {t('notifications')}
              </h2>
              <button onClick={onClose} className="p-2 rounded-full text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700">
                <X size={20} />
              </button>
            </div>
            
            {/* Body */}
            <div className="flex-grow overflow-y-auto">
              {notifications.length > 0 ? (
                <div className="divide-y divide-slate-200 dark:divide-slate-700">
                  {notifications.map(n => (
                    <div key={n.id} className="p-4">
                      <p className="text-sm text-slate-800 dark:text-slate-200">{n.message}</p>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">{new Date(n.id).toLocaleString()}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-full text-center p-4">
                   <Bell size={48} className="text-slate-300 dark:text-slate-600 mb-4" />
                   <h3 className="font-semibold text-slate-800 dark:text-slate-50">{t('noNotifications')}</h3>
                </div>
              )}
            </div>
            
            {/* Footer */}
            {notifications.length > 0 && (
                 <div className="p-4 border-t border-slate-200 dark:border-slate-700 flex-shrink-0">
                    <button 
                        onClick={onClear} 
                        className="w-full flex items-center justify-center gap-2 bg-red-500/10 hover:bg-red-500/20 text-red-500 font-semibold py-2 px-4 rounded-lg transition-colors"
                    >
                        <Trash2 size={16} />
                        <span>{t('clearAll')}</span>
                    </button>
                 </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default NotificationPanel;
