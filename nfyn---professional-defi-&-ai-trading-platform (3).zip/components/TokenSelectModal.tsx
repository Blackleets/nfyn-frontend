import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { LiveCoin } from '../types';
import { X, Search } from 'lucide-react';
import { useTranslation } from '../LanguageContext';

interface TokenSelectModalProps {
  liveCoinData: LiveCoin[];
  onSelect: (token: LiveCoin) => void;
  onClose: () => void;
}

const TokenSelectModal: React.FC<TokenSelectModalProps> = ({ liveCoinData, onSelect, onClose }) => {
  const { t } = useTranslation();
  const [searchTerm, setSearchTerm] = useState('');

  const filteredCoins = useMemo(() => {
    return liveCoinData.filter(coin =>
      coin.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      coin.symbol.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [liveCoinData, searchTerm]);

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4" onClick={onClose}>
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        transition={{ type: 'spring', stiffness: 400, damping: 30 }}
        onClick={e => e.stopPropagation()}
        className="w-full max-w-md bg-dark-card border border-slate-700 rounded-2xl shadow-lg flex flex-col h-[70vh]"
      >
        <header className="p-4 border-b border-slate-800 flex items-center justify-between flex-shrink-0">
          <h2 className="text-lg font-bold text-white">{t('swap.selectToken')}</h2>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-white rounded-full transition-colors"><X size={20} /></button>
        </header>

        <div className="p-4 flex-shrink-0">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder={t('swap.searchToken')}
              className="w-full bg-slate-800 border-2 border-slate-700 focus:border-accent-purple focus:ring-0 rounded-lg pl-10 pr-4 py-2.5 text-sm"
            />
          </div>
        </div>

        <div className="flex-grow overflow-y-auto px-2 pb-2">
          {filteredCoins.map(coin => (
            <button
              key={coin.id}
              onClick={() => onSelect(coin)}
              className="w-full flex items-center gap-4 p-3 hover:bg-slate-800/50 rounded-lg transition-colors text-left"
            >
              <img src={coin.logoUrl} alt={coin.name} className="w-10 h-10 rounded-full" />
              <div>
                <p className="font-bold text-white">{coin.symbol}</p>
                <p className="text-sm text-slate-400">{coin.name}</p>
              </div>
            </button>
          ))}
        </div>
      </motion.div>
    </div>
  );
};

export default TokenSelectModal;