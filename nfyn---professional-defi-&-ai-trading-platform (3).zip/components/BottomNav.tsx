import React from 'react';
import { Screen } from '../types';
import { useTranslation } from '../LanguageContext';
import { FaHome, FaRobot, FaUsers } from 'react-icons/fa';
import { MdShowChart } from 'react-icons/md';
import { LayoutGrid } from 'lucide-react';
import { motion } from 'framer-motion';

interface BottomNavProps {
  activeScreen: Screen;
  setActiveScreen: (screen: Screen) => void;
}

const NavItem: React.FC<{
  label: Screen;
  displayText: string;
  icon: React.ReactElement<{ className?: string }>;
  isActive: boolean;
  onClick: () => void;
}> = ({ label, displayText, icon, isActive, onClick }) => (
  <motion.button
    onClick={onClick}
    whileTap={{ scale: 0.9 }}
    transition={{ type: 'spring', stiffness: 400, damping: 15 }}
    className={`flex flex-col items-center justify-center w-full pt-2 pb-1 transition-all duration-200 group focus:outline-none ${
      isActive ? 'text-accent-cyan' : 'text-slate-400 hover:text-white'
    }`}
  >
    <div className={`transition-all duration-200 ${isActive ? '[filter:drop-shadow(0_0_4px_theme(colors.accent-cyan))]' : 'group-hover:scale-110'}`}>
      {React.cloneElement(icon, { className: 'w-6 h-6' })}
    </div>
    <span className={`text-xs mt-1 transition-all duration-200 ${isActive ? 'font-bold' : 'font-normal'}`}>
      {displayText}
    </span>
  </motion.button>
);

const BottomNav: React.FC<BottomNavProps> = ({ activeScreen, setActiveScreen }) => {
  const { t } = useTranslation();

  const navItems: { label: Screen; displayText: string; icon: React.ReactElement<{ className?: string }> }[] = [
    { label: 'Dashboard', displayText: t('Home'), icon: <FaHome /> },
    { label: 'Trade', displayText: t('Trade'), icon: <MdShowChart /> },
    { label: 'Automate', displayText: t('Bot'), icon: <FaRobot /> },
    { label: 'Market', displayText: t('Market'), icon: <LayoutGrid /> },
    { label: 'Community', displayText: t('Community'), icon: <FaUsers /> },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 h-16 bg-dark-card/80 backdrop-blur-lg border-t border-slate-800 shadow-lg md:hidden z-20 transition-colors duration-300">
      <div className="flex justify-around items-center h-full max-w-lg mx-auto">
        {navItems.map((item) => (
          <NavItem
            key={item.label}
            label={item.label}
            displayText={item.displayText}
            icon={item.icon}
            isActive={activeScreen === item.label}
            onClick={() => setActiveScreen(item.label)}
          />
        ))}
      </div>
    </nav>
  );
};

export default BottomNav;