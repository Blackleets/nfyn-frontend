import React from 'react';
import Card from './Card';
import { useTranslation } from '../LanguageContext';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  children: React.ReactNode;
  confirmText?: string;
  cancelText?: string;
  confirmColor?: 'green' | 'red' | 'cyan';
  confirmDisabled?: boolean;
}

const Modal: React.FC<ModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
  title,
  children,
  confirmText,
  cancelText,
  confirmColor = 'cyan',
  confirmDisabled = false,
}) => {
  const { t } = useTranslation();
  if (!isOpen) return null;
  
  const colorClasses = {
      green: 'bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white',
      red: 'bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white',
      cyan: 'bg-accent-cyan hover:opacity-90 text-slate-900'
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm animate-fade-in"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
    >
      <Card 
        className="w-full max-w-md m-4 !p-0 z-50"
        onClick={(e: React.MouseEvent) => e.stopPropagation()}
      >
        <div className="p-6">
          <h2 id="modal-title" className="text-xl font-bold text-slate-50">{title}</h2>
          <div className="mt-2">
            {children}
          </div>
        </div>
        <div className="bg-slate-800/50 px-6 py-4 flex justify-end space-x-3 rounded-b-2xl">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg text-sm font-semibold bg-slate-700 text-slate-50 hover:bg-slate-600 transition-colors"
          >
            {cancelText || t('modal.cancel')}
          </button>
          <button
            onClick={onConfirm}
            disabled={confirmDisabled}
            className={`px-4 py-2 rounded-lg text-sm font-bold shadow-md transition-all transform hover:scale-105 ${colorClasses[confirmColor]} ${confirmDisabled ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            {confirmText || t('modal.confirm')}
          </button>
        </div>
      </Card>
    </div>
  );
};

export default Modal;