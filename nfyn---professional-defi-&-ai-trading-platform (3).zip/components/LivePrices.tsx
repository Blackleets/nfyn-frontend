/**
 * LivePrices.tsx
 *
 * Componente independiente y autocontenido que muestra una lista de precios de criptomonedas en tiempo real.
 *
 * Funcionalidades:
 * 1.  Carga inicial de datos (nombre, símbolo, logo) desde la API de CoinGecko.
 * 2.  Muestra un estado de carga "skeleton" con el estilo de la interfaz final para una mejor UX.
 * 3.  Establece una conexión WebSocket con la API de CoinCap para recibir actualizaciones de precios en tiempo real.
 * 4.  Muestra los precios actualizados con una animación de destello (verde si sube, rojo si baja).
 * 5.  Diseño inspirado en la estética de Glovo (fuente Poppins, bordes redondeados, colores suaves).
 * 6.  Manejo de errores para la carga inicial y la conexión WebSocket.
 * 7.  Animaciones de entrada escalonadas para la lista de monedas usando framer-motion.
 */
import React, { useState, useEffect, useRef } from 'react';
import Card from './Card';
import { LiveCoin } from '../types';
import { motion } from 'framer-motion';
import SkeletonLoader from './SkeletonLoader';
import { useTranslation } from '../LanguageContext';

// --- Subcomponentes y Helpers ---

/**
 * Componente para el esqueleto de carga de una fila de moneda.
 * Proporciona una vista previa visual de la estructura del contenido mientras se cargan los datos.
 */
const CoinRowSkeleton: React.FC = () => (
    <div className="flex items-center justify-between p-3">
        <div className="flex items-center gap-4">
            <SkeletonLoader className="w-10 h-10 rounded-full" />
            <div>
                <SkeletonLoader className="h-4 w-12 mb-2 rounded" />
                <SkeletonLoader className="h-3 w-20 rounded" />
            </div>
        </div>
        <div className="text-right">
            <SkeletonLoader className="h-5 w-24 rounded" />
        </div>
    </div>
);

// Mapeo de IDs de CoinGecko a CoinCap.
const COIN_CAP_ID_MAP: Record<string, string> = {
    'bitcoin': 'bitcoin',
    'ethereum': 'ethereum',
    'solana': 'solana',
    'binancecoin': 'binance-coin',
    'dogecoin': 'dogecoin',
    'tether': 'tether',
    'xrp': 'xrp',
    'cardano': 'cardano',
    'polygon': 'polygon',
};

// Variantes para las animaciones de la lista con framer-motion.
const listVariants = {
    hidden: { opacity: 0 },
    show: {
        opacity: 1,
        transition: {
            staggerChildren: 0.07,
        }
    }
};

const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
};

// --- Componente Principal: LivePrices ---

interface LivePricesProps {
    coins: LiveCoin[];
}

const LivePrices: React.FC<LivePricesProps> = ({ coins }) => {
    const { t } = useTranslation();
    const [displayCoins, setDisplayCoins] = useState<LiveCoin[]>(coins);
    const [error, setError] = useState<string | null>(null);
    const [animationState, setAnimationState] = useState<Record<string, string>>({});
    const previousPrices = useRef<Record<string, number>>({});

    // Sincroniza el estado interno con las props que vienen del padre.
    useEffect(() => {
        setDisplayCoins(coins);
        coins.forEach(coin => {
            // Actualiza el ref de precios previos para la lógica de animación del WebSocket.
            if (!previousPrices.current[coin.id]) {
                previousPrices.current[coin.id] = coin.price;
            }
        });
    }, [coins]);
    
    // Efecto para establecer la conexión WebSocket.
    useEffect(() => {
        if (coins.length === 0) return;

        const coinCapIds = coins.map(c => COIN_CAP_ID_MAP[c.id]).filter(Boolean);
        if (coinCapIds.length === 0) return;

        const socket = new WebSocket(`wss://ws.coincap.io/prices?assets=${coinCapIds.join(',')}`);

        socket.onmessage = (event) => {
            const priceUpdates = JSON.parse(event.data);
            const newAnimations: Record<string, string> = {};
            
            setDisplayCoins(prevCoins => {
                return prevCoins.map(coin => {
                    const coinCapId = COIN_CAP_ID_MAP[coin.id];
                    if (priceUpdates[coinCapId]) {
                        const newPrice = parseFloat(priceUpdates[coinCapId]);
                        const oldPrice = previousPrices.current[coin.id] || newPrice;
                        
                        if (newPrice !== oldPrice) {
                            newAnimations[coin.id] = newPrice > oldPrice ? 'animate-flash-green' : 'animate-flash-red';
                        }
                        
                        previousPrices.current[coin.id] = newPrice;
                        return { ...coin, price: newPrice };
                    }
                    return coin;
                });
            });

            if (Object.keys(newAnimations).length > 0) {
                setAnimationState(current => ({ ...current, ...newAnimations }));
                setTimeout(() => {
                    setAnimationState(current => {
                        const next = { ...current };
                        Object.keys(newAnimations).forEach(k => delete next[k]);
                        return next;
                    });
                }, 700);
            }
        };

        socket.onerror = (errorEvent) => {
            console.error("WebSocket Error:", errorEvent);
            setError("Live connection failed. Displaying last known prices.");
        };

        return () => {
            if (socket.readyState === WebSocket.OPEN) {
                socket.close();
            }
        };
    }, [coins]);

    const formatPrice = (price: number) => {
        return price.toLocaleString('en-US', {
            minimumFractionDigits: 2,
            maximumFractionDigits: price > 1 ? 2 : 6,
        });
    };

    const renderContent = () => {
        if (coins.length === 0) {
            return (
                <div className="space-y-2">
                    {[...Array(6)].map((_, i) => <CoinRowSkeleton key={i} />)}
                </div>
            );
        }
        return (
            <motion.div
                className="space-y-1"
                variants={listVariants}
                initial="hidden"
                animate="show"
            >
                {displayCoins.map((coin) => (
                    <motion.div
                        key={coin.id}
                        variants={itemVariants}
                        className={`flex items-center justify-between p-3 rounded-xl transition-colors duration-700 ${animationState[coin.id] || ''}`}
                    >
                        <div className="flex items-center gap-4">
                            <img src={coin.logoUrl} alt={`${coin.name} logo`} className="w-10 h-10" />
                            <div>
                                <p className="font-bold text-base text-slate-800 dark:text-slate-50">{coin.symbol}</p>
                                <p className="text-sm text-slate-500 dark:text-slate-400">{coin.name}</p>
                            </div>
                        </div>
                        <div className="text-right">
                            <p className="font-semibold text-lg text-slate-800 dark:text-slate-50 font-mono">${formatPrice(coin.price)}</p>
                        </div>
                    </motion.div>
                ))}
            </motion.div>
        );
    };

    return (
        <Card className="font-poppins">
            <div className="p-4">
                <h3 className="text-xl font-bold text-slate-800 dark:text-slate-50">Live Prices</h3>
                <p className="text-sm text-slate-500 dark:text-slate-400">
                    {error ? 'Connection issues, data may be stale.' : 'Real-time market data'}
                </p>
            </div>
            <div className="p-2">
                {renderContent()}
            </div>
            <div className="text-center p-3 border-t border-slate-200 dark:border-slate-700">
                <p className="text-xs text-slate-400 dark:text-slate-500">
                    Powered by <span className="font-semibold text-glovo-green">CoinGecko</span> & <span className="font-semibold text-glovo-yellow">CoinCap</span>
                </p>
            </div>
        </Card>
    );
};

export default LivePrices;