import React from 'react';
import { motion } from 'framer-motion';
import { FaUserCircle } from 'react-icons/fa';
import { ProfileData } from '../types';
import { Wallet, Star } from 'lucide-react';

interface ProfileHoverCardProps {
    profileData: ProfileData;
    totalCapital: number;
    xp: number;
}

const ProfileHoverCard: React.FC<ProfileHoverCardProps> = ({ profileData, totalCapital, xp }) => {
    return (
        <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2 }}
            className="w-64 bg-dark-card/90 backdrop-blur-md border border-slate-700 rounded-2xl shadow-2xl shadow-black/40 overflow-hidden"
        >
            <div className="p-4">
                <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full border-2 border-accent-purple shadow-glow-purple flex items-center justify-center bg-slate-700 flex-shrink-0">
                        {profileData.avatar ? (
                            <img src={profileData.avatar} alt="User Avatar" className="w-full h-full object-cover rounded-full" />
                        ) : (
                            <FaUserCircle className="w-10 h-10 text-slate-500" />
                        )}
                    </div>
                    <div>
                        <p className="font-bold text-white truncate">{profileData.displayName}</p>
                        <p className="text-xs text-slate-400">@{profileData.username}</p>
                    </div>
                </div>
                <div className="mt-4 space-y-3">
                    <div className="flex items-center justify-between text-sm">
                        <span className="flex items-center gap-2 text-slate-400"><Wallet size={16}/> Balance</span>
                        <span className="font-mono font-semibold text-white">{totalCapital.toLocaleString('en-US', { style: 'currency', currency: 'USD' })}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                        <span className="flex items-center gap-2 text-slate-400"><Star size={16}/> Experience</span>
                        <span className="font-mono font-semibold text-accent-cyan">{xp.toLocaleString()} XP</span>
                    </div>
                </div>
            </div>
        </motion.div>
    );
};

export default ProfileHoverCard;
