
import React, { useState, useEffect, useCallback } from 'react';
import Card from './Card';
import { GeminiService } from '../services/geminiService';
import { useTranslation } from '../LanguageContext';
import SkeletonLoader from './SkeletonLoader';
import { BrainCircuit, Shield, AlertTriangle, ChevronsDown, RefreshCw, Clock } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { AIPortfolioAnalysis, ModuleState } from '../types';
import { formatDistanceToNow } from 'date-fns';

interface AIPortfolioInsightsProps {
    totalCapital: number;
    totalPnl: number;
    initialCapital: number;
    modules: ModuleState[];
}

const RiskGauge: React.FC<{ score: number; level: string }> = ({ score, level }) => {
    const percentage = score / 100;
    const angle = -90 + (percentage * 180);
    const colorMap = {
        Low: '#39FF14',
        Medium: '#FFC244',
        High: '#EF4444'
    };
    const color = colorMap[level as keyof typeof colorMap] || '#FFC244';

    return (
        <div className="relative w-full max-w-[150px] mx-auto group">
            <svg viewBox="0 0 120 70" className="w-full overflow-visible">
                 <defs>
                    <linearGradient id="gaugeGradientInsights" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="#39FF14" />
                        <stop offset="50%" stopColor="#FFC244" />
                        <stop offset="100%" stopColor="#EF4444" />
                    </linearGradient>
                    <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
                        <feGaussianBlur stdDeviation="2" result="blur" />
                        <feComposite in="SourceGraphic" in2="blur" operator="over" />
                    </filter>
                </defs>
                <path d="M10 60 A 50 50 0 0 1 110 60" stroke="currentColor" className="text-slate-800" strokeWidth="12" strokeLinecap="round" fill="none" />
                <motion.path
                    d="M10 60 A 50 50 0 0 1 110 60"
                    stroke="url(#gaugeGradientInsights)"
                    strokeWidth="12"
                    strokeLinecap="round"
                    fill="none"
                    filter="url(#glow)"
                    style={{ pathLength: 0.5 }} // Semicircle
                    initial={{ strokeDashoffset: 0.5 }}
                    animate={{ strokeDashoffset: 0.5 - (percentage * 0.5) }}
                    transition={{ duration: 1, ease: "easeOut" }}
                />
                <motion.g
                    style={{ transformOrigin: '60px 60px' }}
                    initial={{ rotate: -90 }}
                    animate={{ rotate: angle }}
                    transition={{ duration: 1, ease: [0.22, 1, 0.36, 1], delay: 0.2 }}
                >
                    <path d="M60 60 L60 20" stroke="white" strokeWidth="3" strokeLinecap="round" />
                    <circle cx="60" cy="60" r="5" fill="white" stroke="#1a1a1f" strokeWidth="2" />
                </motion.g>
            </svg>
             <div className="absolute bottom-0 text-center w-full">
                <motion.p 
                    initial={{ scale: 0.5, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="text-3xl font-bold text-white -mb-1 font-orbitron"
                >
                    {score}
                </motion.p>
                <p className="font-semibold text-sm uppercase tracking-wider" style={{ color }}>{level}</p>
            </div>
        </div>
    );
};


const AIPortfolioInsights: React.FC<AIPortfolioInsightsProps> = ({ totalCapital, totalPnl, initialCapital, modules }) => {
    const { t } = useTranslation();
    const [analysis, setAnalysis] = useState<AIPortfolioAnalysis | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [isExpanded, setIsExpanded] = useState(false);
    const [lastUpdated, setLastUpdated] = useState<number>(Date.now());

    const fetchAnalysis = useCallback(async () => {
        setIsLoading(true);
        try {
            const result = await GeminiService.getAIPortfolioAnalysis({ totalCapital, totalPnl, initialCapital, modules });
            setAnalysis(result);
            setLastUpdated(Date.now());
        } catch (e) {
            console.error(e);
        } finally {
            setIsLoading(false);
        }
    }, [totalCapital, totalPnl, initialCapital, modules]);

    useEffect(() => {
        // Initial fetch
        fetchAnalysis();
        // We purposely disable the dependency array for auto-fetching to prevent excessive API calls 
        // when portfolio values fluctuate rapidly (e.g. during simulation).
        // Users can manually refresh.
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const renderContent = () => {
        if (isLoading) {
            return (
                 <div className="p-4 md:p-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
                        <div className="md:col-span-1 flex flex-col items-center text-center">
                            <SkeletonLoader className="h-5 w-24 mb-2 rounded" />
                            <SkeletonLoader className="w-36 h-20 rounded-lg" />
                        </div>
                        <div className="md:col-span-2 space-y-2">
                            <SkeletonLoader className="h-5 w-32 mb-2 rounded" />
                            <SkeletonLoader className="h-20 w-full rounded-lg" />
                        </div>
                    </div>
                    <div className="mt-4">
                        <SkeletonLoader className="h-4 w-28 rounded" />
                    </div>
                </div>
            );
        }
        if (!analysis) {
            return (
                 <div className="p-6 text-center text-red-400 bg-red-500/10 rounded-b-xl">
                    <AlertTriangle className="mx-auto mb-2" />
                    <p className="font-semibold">{t('gemini.error.analysis')}</p>
                    <p className="text-sm text-red-400/80">{t('gemini.error.analysisReasoning')}</p>
                    <button onClick={fetchAnalysis} className="mt-4 text-sm font-semibold underline hover:text-red-300">Try Again</button>
                </div>
            );
        }

        const riskIcon = analysis.riskLevel === 'Low' ? <Shield size={20} className="text-green-400"/> :
                         analysis.riskLevel === 'Medium' ? <AlertTriangle size={20} className="text-yellow-400"/> :
                         <AlertTriangle size={20} className="text-red-400"/>;

        return (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5 }}>
                <div className="p-4 md:p-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
                        <div className="md:col-span-1 flex flex-col items-center text-center border-b md:border-b-0 md:border-r border-slate-800 pb-6 md:pb-0 md:pr-6">
                            <h4 className="font-bold text-slate-400 mb-4 flex items-center gap-2 uppercase text-xs tracking-widest">{riskIcon} {t('aiPortfolio.riskScore')}</h4>
                            <RiskGauge score={analysis.riskScore} level={analysis.riskLevel} />
                        </div>
                        <div className="md:col-span-2">
                            <h4 className="font-bold text-slate-400 mb-2 uppercase text-xs tracking-widest">{t('aiPortfolio.recommendation')}</h4>
                            <div className="text-lg font-medium text-white p-4 bg-gradient-to-r from-slate-800 to-slate-900 rounded-xl border border-slate-700 shadow-inner">
                                {analysis.recommendation}
                            </div>
                            
                            <div className="mt-4">
                                <button 
                                    onClick={() => setIsExpanded(!isExpanded)} 
                                    className="text-sm text-accent-cyan font-semibold flex items-center gap-1 hover:text-accent-cyan/80 transition-colors"
                                >
                                    <span>{isExpanded ? t('showLess') : t('aiPortfolio.analysis')}</span>
                                    <motion.div animate={{ rotate: isExpanded ? 180 : 0 }}><ChevronsDown size={16} /></motion.div>
                                </button>
                                <AnimatePresence>
                                    {isExpanded && (
                                        <motion.div
                                            initial={{ height: 0, opacity: 0 }}
                                            animate={{ height: 'auto', opacity: 1, marginTop: '1rem' }}
                                            exit={{ height: 0, opacity: 0, marginTop: '0rem' }}
                                            className="overflow-hidden"
                                        >
                                            <p className="text-sm text-slate-300 whitespace-pre-wrap leading-relaxed border-l-2 border-accent-purple pl-4">{analysis.analysis}</p>
                                        </motion.div>
                                    )}
                                </AnimatePresence>
                            </div>
                        </div>
                    </div>
                    
                    <div className="mt-6 pt-4 border-t border-slate-800 flex justify-between items-center text-xs text-slate-500">
                        <div className="flex items-center gap-1">
                            <Clock size={12} />
                            <span>Updated {formatDistanceToNow(lastUpdated, { addSuffix: true })}</span>
                        </div>
                        <button onClick={fetchAnalysis} disabled={isLoading} className="flex items-center gap-1 hover:text-white transition-colors disabled:opacity-50">
                            <RefreshCw size={12} className={isLoading ? 'animate-spin' : ''} />
                            Refresh
                        </button>
                    </div>
                </div>
            </motion.div>
        );
    };

    return (
        <Card>
            <div className="p-4 border-b border-slate-800 flex justify-between items-center bg-slate-900/30">
                <h3 className="font-bold text-lg text-white flex items-center gap-2 font-orbitron">
                    <BrainCircuit className="text-accent-purple" /> 
                    <span>{t('dashboard.aiPortfolioInsights')}</span>
                </h3>
                <button 
                    onClick={fetchAnalysis} 
                    disabled={isLoading}
                    className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-accent-cyan transition-colors disabled:opacity-50"
                    title="Refresh Analysis"
                >
                    <RefreshCw size={18} className={isLoading ? 'animate-spin' : ''} />
                </button>
            </div>
            {renderContent()}
        </Card>
    );
};

export default AIPortfolioInsights;
        