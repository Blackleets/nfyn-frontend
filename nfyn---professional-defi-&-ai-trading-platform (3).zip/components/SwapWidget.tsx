import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { LiveCoin } from '../types';
import Card from './Card';
import { useTranslation } from '../LanguageContext';
import { ArrowDown, ChevronDown, Settings, Zap, CheckCircle, XCircle, Loader } from 'lucide-react';
import TokenSelectModal from './TokenSelectModal';
import { generateHistoricalData } from '../utils/mockData';
import { AreaChart, Area, ResponsiveContainer } from 'recharts';


// --- SUB-COMPONENTS & HELPERS ---

const formatNumber = (num: number, decimals: number = 6) => {
    if (num === 0) return '0.00';
    if (num < 1e-6) return num.toExponential(2);
    return num.toLocaleString('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: decimals,
    });
};

const SwapInput: React.FC<{
    label: string;
    token: LiveCoin | null;
    onTokenSelect: () => void;
    amount: string;
    onAmountChange: (value: string) => void;
    balance: number | null;
    onMaxClick: () => void;
    isInputDisabled?: boolean;
}> = ({ label, token, onTokenSelect, amount, onAmountChange, balance, onMaxClick, isInputDisabled = false }) => {
    const { t } = useTranslation();

    return (
        <div className="bg-slate-800 p-4 rounded-xl border-2 border-slate-700 focus-within:border-accent-cyan transition-colors">
            <div className="flex justify-between items-center text-xs text-slate-400 mb-2">
                <span>{label}</span>
                {balance !== null && <span>{t('swap.balance', { amount: formatNumber(balance, 4) })}</span>}
            </div>
            <div className="flex justify-between items-center gap-4">
                <input
                    type="number"
                    value={amount}
                    onChange={e => onAmountChange(e.target.value)}
                    placeholder="0.0"
                    disabled={isInputDisabled}
                    className="w-full bg-transparent text-2xl font-mono text-white outline-none"
                />
                <button
                    onClick={onTokenSelect}
                    className="flex items-center gap-2 bg-slate-900 hover:bg-slate-700 p-2 rounded-lg font-semibold text-white transition-colors flex-shrink-0"
                >
                    {token ? (
                        <>
                            <img src={token.logoUrl} alt={token.name} className="w-6 h-6 rounded-full" />
                            <span>{token.symbol}</span>
                        </>
                    ) : (
                        <span>{t('swap.selectToken')}</span>
                    )}
                    <ChevronDown size={16} />
                </button>
            </div>
            {balance !== null && !isInputDisabled && (
                <div className="text-right mt-1">
                    <button onClick={onMaxClick} className="text-xs font-semibold text-accent-cyan hover:underline">{t('swap.max')}</button>
                </div>
            )}
        </div>
    );
};

const PairChart: React.FC<{ fromToken: LiveCoin; toToken: LiveCoin }> = ({ fromToken, toToken }) => {
    const chartData = useMemo(() => {
        const fromData = generateHistoricalData(fromToken.price, '1D');
        const toData = generateHistoricalData(toToken.price, '1D');
        return fromData.map((d, i) => ({
            time: d.time,
            value: d.price / (toData[i]?.price || 1)
        }));
    }, [fromToken, toToken]);

    const isPositive = (chartData[chartData.length - 1]?.value || 0) >= (chartData[0]?.value || 0);

    return (
        <div className="h-20 -mx-4">
            <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                    <defs>
                        <linearGradient id="pairGradient" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor={isPositive ? '#8cff00' : '#EF4444'} stopOpacity={0.3} />
                            <stop offset="95%" stopColor={isPositive ? '#8cff00' : '#EF4444'} stopOpacity={0} />
                        </linearGradient>
                    </defs>
                    <Area type="monotone" dataKey="value" stroke={isPositive ? '#8cff00' : '#EF4444'} strokeWidth={2} fill="url(#pairGradient)" />
                </AreaChart>
            </ResponsiveContainer>
        </div>
    );
};


// --- MAIN SWAP WIDGET ---

interface SwapWidgetProps {
    liveCoinData: LiveCoin[];
    isWalletConnected: boolean;
    handleWalletConnect: () => void;
}

const SwapWidget: React.FC<SwapWidgetProps> = ({ liveCoinData, isWalletConnected, handleWalletConnect }) => {
    const { t } = useTranslation();

    const [fromToken, setFromToken] = useState<LiveCoin | null>(null);
    const [toToken, setToToken] = useState<LiveCoin | null>(null);
    const [fromAmount, setFromAmount] = useState('');
    const [toAmount, setToAmount] = useState('');

    const [balances, setBalances] = useState<Map<string, number>>(new Map());
    const [isSelecting, setIsSelecting] = useState<'from' | 'to' | null>(null);
    const [slippage, setSlippage] = useState('0.5');

    const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);
    const [swapState, setSwapState] = useState<'idle' | 'processing' | 'success' | 'error' | 'limit_placed'>('idle');
    const [errorMsg, setErrorMsg] = useState('');

    const [orderType, setOrderType] = useState<'market' | 'limit'>('market');
    const [limitPrice, setLimitPrice] = useState('');
    
    // Set default tokens on load
    useEffect(() => {
        if (liveCoinData.length > 1) {
            setFromToken(liveCoinData.find(c => c.id === 'ethereum') || liveCoinData[0]);
            setToToken(liveCoinData.find(c => c.id === 'tether') || liveCoinData[1]);
        }
    }, [liveCoinData]);
    
    // Simulate balance fetching on wallet connect
    useEffect(() => {
        if (isWalletConnected && liveCoinData.length > 0) {
            const newBalances = new Map<string, number>();
            liveCoinData.forEach(coin => {
                // Simulate some balances
                if (coin.id === 'bitcoin') newBalances.set(coin.id, 0.5);
                else if (coin.id === 'ethereum') newBalances.set(coin.id, 10);
                else if (coin.id === 'tether') newBalances.set(coin.id, 5000);
                else newBalances.set(coin.id, Math.random() * 1000);
            });
            setBalances(newBalances);
        }
    }, [isWalletConnected, liveCoinData]);
    
    const fromBalance = fromToken ? balances.get(fromToken.id) ?? 0 : 0;
    const toBalance = toToken ? balances.get(toToken.id) ?? 0 : 0;
    
    const price = useMemo(() => {
        if (!fromToken || !toToken || toToken.price === 0) return 0;
        return fromToken.price / toToken.price;
    }, [fromToken, toToken]);
    
    // Calculate output amount when input changes
    useEffect(() => {
        if (orderType === 'market') {
            const amount = parseFloat(fromAmount);
            if (!isNaN(amount) && amount > 0 && price > 0) {
                const output = amount * price;
                setToAmount(output.toString());
            } else {
                setToAmount('');
            }
        }
    }, [fromAmount, price, orderType]);

     // Calculate input amount when limit price or output changes
    useEffect(() => {
        if (orderType === 'limit') {
            const limit = parseFloat(limitPrice);
            const amount = parseFloat(fromAmount);
            if (!isNaN(amount) && amount > 0 && !isNaN(limit) && limit > 0) {
                setToAmount((amount * limit).toString());
            } else {
                setToAmount('');
            }
        }
    }, [fromAmount, limitPrice, orderType]);

    const handleSelectToken = (token: LiveCoin) => {
        if (isSelecting) {
            if (isSelecting === 'from') {
                if (toToken?.id === token.id) { // If new from is same as to, swap them
                    setToToken(fromToken);
                }
                setFromToken(token);
            } else {
                 if (fromToken?.id === token.id) { // If new to is same as from, swap them
                    setFromToken(toToken);
                }
                setToToken(token);
            }
        }
        setIsSelecting(null);
    };

    const handleSwapTokens = () => {
        setFromToken(toToken);
        setToToken(fromToken);
    };
    
    const handleMax = () => {
        if (fromBalance) {
            setFromAmount(fromBalance.toString());
        }
    }
    
    const estimatedOutput = parseFloat(toAmount) * (1 - 0.003); // 0.3% LP fee
    const minReceived = estimatedOutput * (1 - parseFloat(slippage)/100);
    
    const handleSwap = () => {
        if (parseFloat(fromAmount) > fromBalance) {
            setErrorMsg(t('swap.button.insufficientBalance', { symbol: fromToken?.symbol || '' }));
            return;
        }
        setErrorMsg('');
        setIsConfirmModalOpen(true);
        setSwapState('idle');
    };
    
    const handleConfirmSwap = () => {
        setSwapState('processing');
        setTimeout(() => { // Simulate transaction
            if (orderType === 'market') {
                setSwapState('success');
                // Update balances
                if(fromToken && toToken) {
                    const newBalances = new Map(balances);
                    newBalances.set(fromToken.id, fromBalance - parseFloat(fromAmount));
                    newBalances.set(toToken.id, toBalance + minReceived);
                    setBalances(newBalances);
                }
            } else {
                setSwapState('limit_placed');
            }
            
            // Reset amounts after a bit
            setTimeout(() => {
                setFromAmount('');
                setToAmount('');
                if (orderType === 'limit') setLimitPrice('');
            }, 2000);

        }, 2500);
    }

    const swapButtonContent = () => {
        if (!isWalletConnected) return t('swap.button.connectWallet');
        if (!fromAmount || parseFloat(fromAmount) <= 0) return t('swap.button.enterAmount');
        if (parseFloat(fromAmount) > fromBalance) return t('swap.button.insufficientBalance', { symbol: fromToken?.symbol || '' });
        if (orderType === 'limit' && (!limitPrice || parseFloat(limitPrice) <= 0)) return t('swap.button.enterLimitPrice');
        return orderType === 'market' ? t('swap.button.swap') : t('swap.button.placeLimitOrder');
    };
    const isSwapDisabled = !isWalletConnected || !fromAmount || parseFloat(fromAmount) <= 0 || parseFloat(fromAmount) > fromBalance || (orderType === 'limit' && (!limitPrice || parseFloat(limitPrice) <= 0));

    return (
        <Card className="p-4 md:p-6" highlight="cyan">
            <h2 className="text-xl font-bold font-orbitron mb-4 text-center">{t('swap.title')}</h2>
            
            <div className="flex space-x-1 p-1 bg-slate-900 rounded-lg mb-4">
                <button onClick={() => setOrderType('market')} className={`w-full py-2 text-sm font-semibold rounded-md transition-colors ${orderType === 'market' ? 'bg-slate-700 text-white' : 'text-slate-400'}`}>
                    {t('swap.market')}
                </button>
                <button onClick={() => setOrderType('limit')} className={`w-full py-2 text-sm font-semibold rounded-md transition-colors ${orderType === 'limit' ? 'bg-slate-700 text-white' : 'text-slate-400'}`}>
                    {t('swap.limit')}
                </button>
            </div>

            <div className="space-y-2 relative">
                <SwapInput label={t('swap.from')} token={fromToken} onTokenSelect={() => setIsSelecting('from')} amount={fromAmount} onAmountChange={setFromAmount} balance={isWalletConnected ? fromBalance : null} onMaxClick={handleMax} />
                <button onClick={handleSwapTokens} className="absolute left-1/2 -translate-x-1/2 top-1/2 -translate-y-1/2 z-10 w-10 h-10 bg-slate-900 border-4 border-dark-card rounded-full flex items-center justify-center text-slate-400 hover:text-white hover:rotate-180 transition-transform duration-300">
                    <ArrowDown size={20} />
                </button>
                <SwapInput label={t('swap.to')} token={toToken} onTokenSelect={() => setIsSelecting('to')} amount={toAmount} onAmountChange={() => {}} balance={isWalletConnected ? toBalance : null} onMaxClick={() => {}} isInputDisabled={true} />
            </div>

            <AnimatePresence>
                {orderType === 'limit' && fromToken && toToken && (
                    <motion.div
                        initial={{ height: 0, opacity: 0, marginTop: 0 }}
                        animate={{ height: 'auto', opacity: 1, marginTop: '0.75rem' }}
                        exit={{ height: 0, opacity: 0, marginTop: 0 }}
                        className="overflow-hidden"
                    >
                        <div className="bg-slate-800 p-4 rounded-xl border-2 border-slate-700 focus-within:border-accent-purple transition-colors">
                            <div className="flex justify-between items-center text-xs text-slate-400 mb-2">
                                <span>{t('swap.limitPrice')}</span>
                                <span>Price of 1 {fromToken.symbol}</span>
                            </div>
                            <div className="flex justify-between items-center gap-4">
                                <input
                                    type="number"
                                    value={limitPrice}
                                    onChange={e => setLimitPrice(e.target.value)}
                                    placeholder={price > 0 ? price.toFixed(4) : "0.0"}
                                    className="w-full bg-transparent text-2xl font-mono text-white outline-none"
                                />
                                <span className="font-semibold text-white flex-shrink-0">{toToken.symbol}</span>
                            </div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
            
            {fromToken && toToken && orderType === 'market' && (
                <>
                <div className="text-sm text-slate-400 my-4 text-center">
                    {t('swap.price')}: 1 {fromToken.symbol} ≈ {formatNumber(price, 4)} {toToken.symbol}
                </div>
                <PairChart fromToken={fromToken} toToken={toToken} />
                </>
            )}

            <div className="mt-4 p-3 bg-slate-800/50 rounded-lg space-y-2 text-sm">
                <div className="flex justify-between items-center">
                    <span className="text-slate-400">{t('swap.slippage')}</span>
                     <div className="flex items-center gap-1 p-0.5 bg-slate-900 rounded-md">
                        {['0.5', '1.0'].map(val => <button key={val} onClick={() => setSlippage(val)} className={`px-2 py-0.5 text-xs font-semibold rounded ${slippage === val ? 'bg-slate-700' : ''}`}>{val}%</button>)}
                    </div>
                </div>
                <div className="flex justify-between items-center">
                    <span className="text-slate-400">{t('swap.estimatedOutput')}</span>
                    <span className="font-mono text-white">{formatNumber(estimatedOutput)} {toToken?.symbol}</span>
                </div>
                 <div className="flex justify-between items-center">
                    <span className="text-slate-400">{t('swap.fee')}</span>
                    <span className="font-mono text-white">{formatNumber(parseFloat(fromAmount) * price * 0.003)} {toToken?.symbol}</span>
                </div>
            </div>

            <div className="mt-4">
                <button onClick={isWalletConnected ? handleSwap : handleWalletConnect} disabled={isSwapDisabled} className="w-full bg-accent-cyan text-slate-900 font-bold py-4 rounded-lg text-lg hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2">
                    <Zap size={20} />
                    <span>{swapButtonContent()}</span>
                </button>
            </div>
            
            <AnimatePresence>
                {isSelecting && <TokenSelectModal liveCoinData={liveCoinData} onSelect={handleSelectToken} onClose={() => setIsSelecting(null)} />}
            </AnimatePresence>
            
            <AnimatePresence>
            {isConfirmModalOpen && (
                <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center" onClick={() => setIsConfirmModalOpen(false)}>
                    <motion.div
                        initial={{ scale: 0.9, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        exit={{ scale: 0.9, opacity: 0 }}
                        onClick={e => e.stopPropagation()}
                        className="w-full max-w-sm"
                    >
                    <Card className="p-6">
                        {swapState === 'idle' && <>
                            <h3 className="text-xl font-bold text-center mb-4">{orderType === 'market' ? t('swap.modal.title') : t('swap.modal.titleLimit')}</h3>
                            <div className="flex items-center justify-between p-3 bg-slate-800 rounded-lg">
                                <div><p className="text-2xl font-bold">{formatNumber(parseFloat(fromAmount), 4)}</p><p className="text-sm text-slate-400">{fromToken?.symbol}</p></div>
                                <img src={fromToken?.logoUrl} alt="" className="w-10 h-10 rounded-full" />
                            </div>
                            <div className="my-2 flex justify-center"><ArrowDown className="text-slate-500"/></div>
                             <div className="flex items-center justify-between p-3 bg-slate-800 rounded-lg">
                                <div><p className="text-2xl font-bold">{formatNumber(estimatedOutput, 4)}</p><p className="text-sm text-slate-400">{toToken?.symbol}</p></div>
                                <img src={toToken?.logoUrl} alt="" className="w-10 h-10 rounded-full" />
                            </div>
                            {orderType === 'limit' && (
                                <div className="text-sm text-slate-400 mt-4 text-center">
                                    {t('swap.modal.limitPrice')} <span className="font-mono text-white">{limitPrice} {toToken?.symbol} per {fromToken?.symbol}</span>
                                </div>
                            )}
                            <p className="text-xs text-slate-400 mt-4">{t('swap.modal.outputMin')} <span className="font-mono text-white">{formatNumber(minReceived, 4)} {toToken?.symbol}</span></p>
                            <button onClick={handleConfirmSwap} className="w-full mt-4 bg-accent-cyan text-slate-900 font-bold py-3 rounded-lg">{orderType === 'market' ? t('swap.modal.confirm') : t('swap.modal.confirmLimit')}</button>
                        </>}
                        {swapState === 'processing' && <div className="text-center p-8">
                            <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }} className="w-12 h-12 border-4 border-t-accent-cyan border-slate-700 rounded-full mx-auto" />
                            <p className="font-semibold mt-4">{t('swap.modal.processing')}</p>
                        </div>}
                        {swapState === 'success' && <div className="text-center p-8">
                             <motion.div initial={{ scale: 0.5 }} animate={{ scale: 1 }} className="w-16 h-16 bg-accent-green/20 text-accent-green rounded-full mx-auto flex items-center justify-center"><CheckCircle size={32}/></motion.div>
                             <p className="font-semibold mt-4 text-xl">{t('swap.modal.success')}</p>
                             <button onClick={() => setIsConfirmModalOpen(false)} className="w-full mt-6 bg-slate-700 text-white font-bold py-3 rounded-lg">{t('swap.modal.close')}</button>
                        </div>}
                        {swapState === 'limit_placed' && <div className="text-center p-8">
                            <motion.div initial={{ scale: 0.5 }} animate={{ scale: 1 }} className="w-16 h-16 bg-accent-green/20 text-accent-green rounded-full mx-auto flex items-center justify-center"><CheckCircle size={32}/></motion.div>
                            <p className="font-semibold mt-4 text-xl">{t('swap.modal.limitPlaced')}</p>
                            <p className="text-sm text-slate-400 mt-2">{t('swap.modal.limitPlacedDescription', { fromAmount: fromAmount, fromSymbol: fromToken?.symbol, toSymbol: toToken?.symbol, limitPrice: limitPrice })}</p>
                            <button onClick={() => setIsConfirmModalOpen(false)} className="w-full mt-6 bg-slate-700 text-white font-bold py-3 rounded-lg">{t('swap.modal.close')}</button>
                        </div>}
                    </Card>
                    </motion.div>
                </div>
            )}
            </AnimatePresence>
        </Card>
    );
};

export default SwapWidget;