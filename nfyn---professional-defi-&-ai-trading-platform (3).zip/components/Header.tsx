import React, { useState, useEffect, useRef } from 'react';
import { Menu, CheckCircle2 } from 'lucide-react';
import { FaUserCircle, FaBell, FaWallet } from 'react-icons/fa';
import { motion, AnimatePresence } from 'framer-motion';
import { ProfileData } from '../types';
import ProfileHoverCard from './ProfileHoverCard';

interface HeaderProps {
  activeScreenTitle: string;
  onMenuClick: () => void;
  onProfileClick: () => void;
  onNotificationsClick: () => void;
  onWalletClick: () => void;
  unreadNotificationCount: number;
  isWalletConnected: boolean;
  profileData: ProfileData;
  totalCapital: number;
  xp: number;
  isMobile: boolean;
}

const Header: React.FC<HeaderProps> = ({ activeScreenTitle, onMenuClick, onProfileClick, onNotificationsClick, onWalletClick, unreadNotificationCount, isWalletConnected, profileData, totalCapital, xp, isMobile }) => {
  const [isProfileCardOpen, setIsProfileCardOpen] = useState(false);
  const profileRef = useRef<HTMLDivElement>(null);

  const handleProfileTap = () => {
    if (isMobile) {
      setIsProfileCardOpen(prev => !prev);
    } else {
      onProfileClick();
    }
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (profileRef.current && !profileRef.current.contains(event.target as Node)) {
        setIsProfileCardOpen(false);
      }
    };

    if (isProfileCardOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isProfileCardOpen]);


  return (
    <header className="sticky top-0 z-30 flex items-center justify-between h-16 px-4 md:px-6 bg-dark-bg/80 backdrop-blur-lg border-b border-slate-800 transition-colors duration-300">
      <div className="flex items-center space-x-4">
        <button onClick={onMenuClick} className="md:hidden p-2 -ml-2 text-slate-400 hover:text-slate-50">
          <Menu className="h-6 w-6" />
        </button>
        <h1 className="text-xl font-bold font-orbitron bg-gradient-to-r from-accent-cyan to-accent-purple text-transparent bg-clip-text">{activeScreenTitle}</h1>
      </div>
      <div className="flex items-center space-x-2 md:space-x-4">
        <motion.button 
          whileHover={{ scale: 1.1, boxShadow: '0 0 15px rgba(0, 240, 255, 0.6)' }}
          whileTap={{ scale: 0.9 }}
          onClick={onWalletClick}
          className={`relative w-10 h-10 flex items-center justify-center rounded-full bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-slate-50 transition-all ${isWalletConnected ? 'text-accent-green' : ''}`}
          aria-label="Connect Wallet"
        >
          {isWalletConnected ? <CheckCircle2 className="h-6 w-6" /> : <FaWallet className="h-5 w-5 md:h-5 md:w-5" />}
           {isWalletConnected && (
             <span className="absolute top-1 right-1 flex h-2.5 w-2.5">
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-accent-green"></span>
            </span>
          )}
        </motion.button>
        <motion.button 
          whileHover={{ scale: 1.1, boxShadow: '0 0 15px rgba(0, 240, 255, 0.6)' }}
          whileTap={{ scale: 0.9 }}
          onClick={onNotificationsClick}
          className="relative w-10 h-10 flex items-center justify-center rounded-full bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-slate-50 transition-all"
          aria-label="Notifications"
        >
          <FaBell className="h-5 w-5 md:h-6 md:w-6" />
          {unreadNotificationCount > 0 && (
             <span className="absolute top-1.5 right-1.5 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
            </span>
          )}
        </motion.button>
        <motion.div ref={profileRef} className="relative group" whileHover={!isMobile ? { z: 51 } : {}}>
          <motion.button 
            whileHover={{ scale: 1.1, boxShadow: '0 0 15px rgba(0, 240, 255, 0.6)' }}
            whileTap={{ scale: 0.9 }}
            onClick={handleProfileTap} 
            className="w-10 h-10 flex items-center justify-center rounded-full bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-slate-50 transition-all"
            aria-label="View Profile"
          >
            {profileData.avatar ? (
              <img src={profileData.avatar} alt="User Avatar" className="w-full h-full object-cover rounded-full"/>
            ) : (
              <FaUserCircle className="h-6 w-6 md:h-7 md:w-7" />
            )}
          </motion.button>
          <div className={`absolute top-full right-0 mt-2 ${!isMobile ? 'opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none group-hover:pointer-events-auto' : ''}`}>
             <AnimatePresence>
              {(isProfileCardOpen || !isMobile) && (
                <div className={isMobile ? '' : 'group-hover:block hidden'}>
                  <ProfileHoverCard profileData={profileData} totalCapital={totalCapital} xp={xp} />
                </div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      </div>
    </header>
  );
};

export default Header;