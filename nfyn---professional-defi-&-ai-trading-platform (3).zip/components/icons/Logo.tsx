import React from 'react';

export const NfynLogo: React.FC<{ className?: string }> = ({ className = "w-24 h-9" }) => {
  const particles = [
    { x: 15, y: 5, delay: '0.1s' }, { x: 30, y: 0, delay: '0.3s' },
    { x: 50, y: 2, delay: '0.2s' }, { x: 70, y: 0, delay: '0s' },
    { x: 85, y: 5, delay: '0.2s' }, { x: 10, y: 35, delay: '0.4s' },
    { x: 35, y: 40, delay: '0.1s' }, { x: 60, y: 40, delay: '0.3s' },
    { x: 90, y: 35, delay: '0.15s' },
  ];

  return (
    <div className={`group ${className}`}>
      <svg
        className="w-full h-full overflow-visible"
        viewBox="0 0 100 40"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <linearGradient id="liquid-gradient">
            <stop offset="0%" stopColor="#67e8f9" />
            <stop offset="50%" stopColor="#22D3EE" />
            <stop offset="100%" stopColor="#67e8f9" />
            <animate attributeName="x1" from="-100%" to="100%" dur="4s" repeatCount="indefinite" />
            <animate attributeName="x2" from="0%" to="200%" dur="4s" repeatCount="indefinite" />
          </linearGradient>
        </defs>

        {/* Particle Group - Renders behind text */}
        <g>
          {particles.map((p, i) => (
            <circle
              key={i}
              cx={p.x}
              cy={p.y}
              r="1.5"
              fill="#22D3EE"
              className="opacity-0 group-hover:animate-particle-burst"
              style={{ animationDelay: p.delay, transformOrigin: `${p.x}px ${p.y}px` }}
            />
          ))}
        </g>
        
        <text
          x="50%"
          y="50%"
          dy=".3em"
          textAnchor="middle"
          fontSize="38"
          fontWeight="800"
          fontFamily="Inter, sans-serif"
          letterSpacing="-2"
          fill="url(#liquid-gradient)"
          className="
            animate-subtle-glow
            transition-all duration-300 ease-in-out
            group-hover:scale-110
            group-hover:!filter group-hover:drop-shadow-[0_0_15px_rgba(34,211,238,0.9)]
          "
        >
          NFYN
        </text>
      </svg>
    </div>
  );
};