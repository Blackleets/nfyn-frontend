import React from 'react';

const iconClass = "w-8 h-8";
const smallIconClass = "w-5 h-5";

/**
 * Represents fast, short-term chart action with a lightning bolt overlay.
 */
export const ScalpingIcon: React.FC<{ small?: boolean }> = ({ small }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={small ? smallIconClass : iconClass} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5">
        <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 13.5l4.125-4.125m0 0l4.125 4.125m-4.125-4.125V3m0 10.5h4.125" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z" opacity="0.6" />
    </svg>
);

/**
 * Represents yield farming with a stack of coins and growth indicators.
 */
export const FarmingIcon: React.FC<{ small?: boolean }> = ({ small }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={small ? smallIconClass : iconClass} fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 6.375c0 2.278-3.694 4.125-8.25 4.125S3.75 8.653 3.75 6.375m16.5 0c0-2.278-3.694-4.125-8.25-4.125S3.75 4.097 3.75 6.375m16.5 0v11.25c0 2.278-3.694 4.125-8.25 4.125s-8.25-1.847-8.25-4.125V6.375m0 0l3.75 3.375M12 10.5l4.125-3.375" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 15.75c-2.071 0-4.04-1.01-5.25-2.625M12 15.75c2.071 0 4.04-1.01 5.25-2.625" opacity="0.8" />
    </svg>
);


/**
 * Represents futures trading with a candlestick chart.
 */
export const FuturesIcon: React.FC<{ small?: boolean }> = ({ small }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={small ? smallIconClass : iconClass} fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" d="M3 13.5l3-3m0 0l3 3m-3-3v8.25M9 13.5l3 3m0 0l3-3m-3 3V8.25m3 3l3-3m0 0l3 3m-3-3v8.25" />
    </svg>
);

/**
 * Represents liquidity providing with two interlocking, balanced shapes.
 */
export const LpIcon: React.FC<{ small?: boolean }> = ({ small }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={small ? smallIconClass : iconClass} fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" d="M9.75 12.75c0 .414-.168.79-.439 1.061l-2.121 2.121a1.5 1.5 0 00-2.121-2.121l2.121-2.121A1.5 1.5 0 009.75 12.75zm0 0a1.5 1.5 0 012.121-2.121l2.121-2.121a1.5 1.5 0 012.121 2.121l-2.121 2.121A1.5 1.5 0 0112.75 12.75h-3z" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M14.25 9.75c0-.414.168-.79.439-1.061l2.121-2.121a1.5 1.5 0 012.121 2.121l-2.121 2.121A1.5 1.5 0 0114.25 9.75zm0 0a1.5 1.5 0 00-2.121 2.121l-2.121 2.121a1.5 1.5 0 00-2.121-2.121l2.121-2.121A1.5 1.5 0 0011.25 9.75h3z" />
    </svg>
);
