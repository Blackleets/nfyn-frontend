import React from 'react';

const ChatWidget: React.FC = () => {
    return (
        <div>
            {/* Chat widget placeholder */}
        </div>
    );
};

export default ChatWidget;
