import React from 'react';
import { motion } from 'framer-motion';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  onClick?: (event: React.MouseEvent<HTMLDivElement>) => void;
  highlight?: 'cyan' | 'purple' | 'green' | 'red';
}

const Card: React.FC<CardProps> = ({ children, className = '', onClick, highlight }) => {
  const highlightClasses = {
    cyan: 'border-t-accent-cyan',
    purple: 'border-t-accent-purple',
    green: 'border-t-accent-green',
    red: 'border-t-accent-red',
  };
  
  const shadowStyles = {
    cyan: '0 0 15px rgba(0, 240, 255, 0.6), 0 0 5px rgba(0, 240, 255, 0.8)',
    purple: '0 0 15px rgba(191, 0, 255, 0.6), 0 0 5px rgba(191, 0, 255, 0.8)',
    green: '0 0 15px rgba(57, 255, 20, 0.6), 0 0 5px rgba(57, 255, 20, 0.8)',
    red: '0 0 15px rgba(239, 68, 68, 0.6), 0 0 5px rgba(239, 68, 68, 0.8)',
  };
  
  const highlightClass = highlight ? `${highlightClasses[highlight]} border-t-2` : 'border-t-transparent';

  const cardClasses = `
    bg-dark-card/70 backdrop-blur-sm
    border border-slate-800
    rounded-2xl shadow-lg shadow-black/20
    transition-all duration-300
    ${highlightClass}
    ${onClick ? 'cursor-pointer' : ''}
    ${className}
  `;
  
  const hoverEffect = onClick ? { 
    y: -4, 
    boxShadow: highlight ? shadowStyles[highlight] : '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1)',
    transition: { duration: 0.2 } 
  } : {};


  return (
    <motion.div 
      className={cardClasses} 
      onClick={onClick}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, ease: "easeOut" }}
      whileHover={hoverEffect}
    >
      {children}
    </motion.div>
  );
};

export default Card;