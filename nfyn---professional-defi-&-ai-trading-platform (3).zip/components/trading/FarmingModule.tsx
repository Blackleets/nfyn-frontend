import React, { useState } from 'react';
import Card from '../Card';
import { ModuleState, FarmingPool, YieldFarmingOpportunity } from '../../types';
import { useTranslation } from '../../LanguageContext';
import { DatabaseZap, BrainCircuit, Plus, Minus, Info } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { GeminiService } from '../../services/geminiService';
import SkeletonLoader from '../SkeletonLoader';

interface FarmingModuleProps {
    module: ModuleState;
    isBotRunning: boolean;
    onUpdateModule: (updatedModule: ModuleState) => void;
}

const formatCurrency = (value: number) => {
    return value.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
};

const PnlText: React.FC<{ value: number, className?: string }> = ({ value, className }) => {
    const isProfit = value >= 0;
    return (
        <span className={`font-bold ${isProfit ? 'text-accent-green' : 'text-accent-red'} ${className ?? ''}`}>
            {isProfit ? '+' : ''}${formatCurrency(value)}
        </span>
    );
};

const FarmingModule: React.FC<FarmingModuleProps> = ({ module, isBotRunning, onUpdateModule }) => {
    const { t } = useTranslation();
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const [aiOpportunities, setAiOpportunities] = useState<YieldFarmingOpportunity[] | null>(null);

    const currentPool = module.farmingPools?.[0]; // Assuming one pool for simplicity

    const handleStake = () => {
        if (!currentPool) return;
        const stakeAmount = module.capital * 0.5; // Example: stake 50%
        if (module.capital >= stakeAmount) {
            onUpdateModule({
                ...module,
                capital: module.capital - stakeAmount,
                farmingPools: [{
                    ...currentPool,
                    stakedAmount: (currentPool.stakedAmount ?? 0) + stakeAmount,
                }],
            });
        }
    };

    const handleUnstakeAndClaim = () => {
        if (!currentPool) return;
        const totalAmount = (currentPool.stakedAmount ?? 0) + (currentPool.rewardsEarned ?? 0);
        onUpdateModule({
            ...module,
            capital: module.capital + totalAmount,
            pnl: module.pnl + (currentPool.rewardsEarned ?? 0),
            farmingPools: [{
                ...currentPool,
                stakedAmount: 0,
                rewardsEarned: 0,
            }],
        });
    };

    const handleFindOpportunities = async () => {
        setIsAnalyzing(true);
        setAiOpportunities(null);
        try {
            const marketSummary = await GeminiService.getMarketSummary(); // Use market summary for context
            const result = await GeminiService.findYieldFarmingOpportunities(marketSummary, module.minApyThreshold);
            setAiOpportunities(result);
        } catch (error) {
            console.error("Failed to get AI farming opportunities:", error);
            setAiOpportunities([{
                protocol: "FallbackFarm",
                pair: "USDT-USDC",
                apy: 8,
                risk: "Low",
                reasoning: t('gemini.error.analysisReasoning'),
            }]);
        } finally {
            setIsAnalyzing(false);
        }
    };


    return (
        <Card highlight="green" className="p-4 flex flex-col h-full">
            <div className="flex items-center gap-3 mb-4">
                <DatabaseZap size={24} className="text-accent-green" />
                <h3 className="text-xl font-bold text-accent-green">{t('farming')}</h3>
            </div>

            <div className="space-y-3 text-sm flex-grow">
                <div className="flex justify-between items-center">
                    <span className="text-slate-400">{t('moduleCapital')}</span>
                    <span className="font-mono text-white">${formatCurrency(module.capital)}</span>
                </div>
                <div className="flex justify-between items-center">
                    <span className="text-slate-400">{t('moduleTotalPnl')}</span>
                    <PnlText value={module.pnl} />
                </div>
                
                {currentPool && (
                    <>
                        <div className="border-t border-slate-800 pt-3 mt-3">
                            <h4 className="font-bold text-md text-white mb-2">Current Pool: {currentPool.protocol} ({currentPool.pair})</h4>
                            <div className="flex justify-between items-center">
                                <span className="text-slate-400">{t('moduleStaked')}</span>
                                <span className="font-mono text-white">${formatCurrency(currentPool.stakedAmount ?? 0)}</span>
                            </div>
                            <div className="flex justify-between items-center">
                                <span className="text-slate-400">{t('moduleRewards')}</span>
                                <PnlText value={currentPool.rewardsEarned ?? 0} />
                            </div>
                            <div className="flex justify-between items-center">
                                <span className="text-slate-400">{t('moduleEstApy')}</span>
                                <span className="font-mono text-accent-green">{currentPool.apy.toFixed(1)}%</span>
                            </div>
                        </div>

                        <div className="mt-4 flex flex-col gap-2">
                            <button onClick={handleStake} disabled={isBotRunning || module.capital === 0} className="w-full bg-slate-700/50 hover:bg-slate-700 text-white font-semibold py-2 rounded-lg transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed">
                                <Plus size={16} /> {t('moduleStakeUsdt', { available: formatCurrency(module.capital) })}
                            </button>
                            <button onClick={handleUnstakeAndClaim} disabled={isBotRunning || (currentPool.stakedAmount ?? 0) === 0} className="w-full bg-slate-700/50 hover:bg-slate-700 text-white font-semibold py-2 rounded-lg transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed">
                                <Minus size={16} /> {t('moduleUnstakeAndClaim')}
                            </button>
                        </div>
                    </>
                )}
            </div>

            <div className="mt-6 border-t border-slate-800 pt-4 flex-shrink-0">
                <h4 className="text-lg font-bold text-white mb-2 flex items-center gap-2"><BrainCircuit size={20} className="text-accent-purple"/> AI Opportunities</h4>
                <motion.button
                    onClick={handleFindOpportunities}
                    disabled={isAnalyzing || isBotRunning}
                    className="w-full bg-slate-700/50 hover:bg-slate-700 text-accent-cyan font-semibold py-2 rounded-lg transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    {isAnalyzing ? (
                        <>
                            <motion.span animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }}><BrainCircuit size={16} /></motion.span>
                            <span>{t('analyzingOpportunities')}</span>
                        </>
                    ) : (
                        <>
                            <BrainCircuit size={16} />
                            <span>{t('findOpportunities')}</span>
                        </>
                    )}
                </motion.button>

                <AnimatePresence mode="wait">
                    {aiOpportunities && aiOpportunities.length > 0 && (
                        <motion.div
                            key="ai-opportunities"
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            transition={{ duration: 0.3 }}
                            className="mt-3 bg-slate-800 p-3 rounded-lg text-sm space-y-2"
                        >
                            <h5 className="font-semibold text-white">{t('aiSuggestedFarms')}</h5>
                            {aiOpportunities.map((opp, index) => (
                                <div key={index} className="border-b border-slate-700/50 pb-2 last:border-b-0 last:pb-0">
                                    <p className="font-bold text-white">{opp.protocol} - {opp.pair}</p>
                                    <p className="text-slate-400">APY: <span className="text-accent-green">{opp.apy.toFixed(1)}%</span> | Risk: {opp.risk}</p>
                                    <p className="text-xs text-slate-500 italic mt-1">{t('reasoning')}: {opp.reasoning}</p>
                                </div>
                            ))}
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>
        </Card>
    );
};

export default FarmingModule;