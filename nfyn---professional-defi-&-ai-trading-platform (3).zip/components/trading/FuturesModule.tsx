import React, { useState } from 'react';
import Card from '../Card';
import { ModuleState, FuturesPosition, FuturesFundingAnalysis, LiveCoin } from '../../types';
import { useTranslation } from '../../LanguageContext';
import { Zap, BrainCircuit, TrendingUp, TrendingDown, DollarSign } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { GeminiService } from '../../services/geminiService';
import SkeletonLoader from '../SkeletonLoader';

interface FuturesModuleProps {
    module: ModuleState;
    isBotRunning: boolean;
    onUpdateModule: (updatedModule: ModuleState) => void;
    liveCoinData: LiveCoin[];
}

const formatCurrency = (value: number) => {
    return value.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
};

const PnlText: React.FC<{ value: number, className?: string }> = ({ value, className }) => {
    const isProfit = value >= 0;
    return (
        <span className={`font-bold ${isProfit ? 'text-accent-green' : 'text-accent-red'} ${className ?? ''}`}>
            {isProfit ? '+' : ''}${formatCurrency(value)}
        </span>
    );
};

const FuturesModule: React.FC<FuturesModuleProps> = ({ module, isBotRunning, onUpdateModule, liveCoinData }) => {
    const { t } = useTranslation();
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const [aiAnalysis, setAiAnalysis] = useState<FuturesFundingAnalysis | null>(null);

    const btcLivePrice = liveCoinData.find(c => c.symbol === 'BTC')?.price || 0;
    const currentPosition = module.futuresPositions?.[0]; // Assuming one futures position for simplicity

    const handleOpenPosition = (side: 'Long' | 'Short') => {
        if (isBotRunning) return; // Cannot manually open if bot is running
        if (module.capital === 0 || btcLivePrice === 0) return;

        const size = module.capital * ((module.positionSizePercent ?? 10) / 100);

        onUpdateModule({
            ...module,
            futuresPositions: [{
                id: `fut-${Date.now()}`,
                symbol: 'BTC',
                leverage: module.maxLeverage ?? 20,
                entry: btcLivePrice,
                pnl: 0,
                side: side,
                size: size,
                currentPrice: btcLivePrice,
            }],
            capital: module.capital - size // Deduct initial margin (simplified)
        });
    };

    const handleClosePosition = () => {
        if (!currentPosition || isBotRunning) return;
        
        const currentPnl = (btcLivePrice - currentPosition.entry) * (currentPosition.size / currentPosition.entry) * currentPosition.leverage;
        
        onUpdateModule({
            ...module,
            capital: module.capital + currentPosition.size + currentPnl, // Return initial margin + PnL
            pnl: module.pnl + currentPnl,
            futuresPositions: [],
        });
    };

    const handleAnalyzeFunding = async () => {
        setIsAnalyzing(true);
        setAiAnalysis(null);
        try {
            const result = await GeminiService.analyzeFuturesFundingRates('BTC');
            setAiAnalysis(result);
        } catch (error) {
            console.error("Failed to get AI funding analysis:", error);
            setAiAnalysis({
                prediction: 'Neutral',
                reasoning: t('gemini.error.analysisReasoning'),
                optimalLeverage: 10,
            });
        } finally {
            setIsAnalyzing(false);
        }
    };

    const currentFloatingPnl = currentPosition ? (btcLivePrice - currentPosition.entry) * (currentPosition.size / currentPosition.entry) * currentPosition.leverage : 0;

    return (
        <Card highlight="red" className="p-4 flex flex-col h-full">
            <div className="flex items-center gap-3 mb-4">
                <Zap size={24} className="text-accent-red" />
                <h3 className="text-xl font-bold text-accent-red">{t('futures')}</h3>
            </div>

            <div className="space-y-3 text-sm flex-grow">
                <div className="flex justify-between items-center">
                    <span className="text-slate-400">{t('moduleCapital')}</span>
                    <span className="font-mono text-white">${formatCurrency(module.capital)}</span>
                </div>
                <div className="flex justify-between items-center">
                    <span className="text-slate-400">{t('moduleTotalPnl')}</span>
                    <PnlText value={module.pnl} />
                </div>
                
                <div className="border-t border-slate-800 pt-3 mt-3">
                    <p className="text-slate-400">{t('leverage')}: <span className="font-mono text-white">{module.maxLeverage ?? 20}x</span></p>
                    <p className="text-slate-400">{t('positionSize')}: <span className="font-mono text-white">{module.positionSizePercent ?? 10}%</span></p>
                    <p className="text-slate-400">{t('stopLoss')}: <span className="font-mono text-white">{module.stopLossPercent ?? 0}%</span></p>
                </div>

                {currentPosition ? (
                    <div className="mt-4 bg-slate-800/50 p-3 rounded-lg">
                        <h4 className="font-bold text-md text-white mb-2">{t('moduleOpenPosition')}: {currentPosition.symbol} ({currentPosition.side})</h4>
                        <div className="flex justify-between items-center mb-1">
                            <span className="text-slate-400">Entry:</span>
                            <span className="font-mono text-white">${formatCurrency(currentPosition.entry)}</span>
                        </div>
                        <div className="flex justify-between items-center mb-1">
                            <span className="text-slate-400">Current:</span>
                            <span className="font-mono text-white">${formatCurrency(btcLivePrice)}</span>
                        </div>
                        <div className="flex justify-between items-center mb-1">
                            <span className="text-slate-400">Size:</span>
                            <span className="font-mono text-white">${formatCurrency(currentPosition.size)}</span>
                        </div>
                        <div className="flex justify-between items-center">
                            <span className="text-slate-400">Floating P&L:</span>
                            <PnlText value={currentFloatingPnl} />
                        </div>
                        <button onClick={handleClosePosition} disabled={isBotRunning} className="w-full bg-accent-red/80 hover:bg-accent-red text-white font-bold py-2 rounded-lg mt-3 transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
                            {t('closePosition')}
                        </button>
                    </div>
                ) : (
                    <div className="mt-4 text-center text-slate-400">
                        <p>{t('noOpenPosition')}</p>
                        <div className="flex gap-2 mt-2">
                             <button onClick={() => handleOpenPosition('Long')} disabled={isBotRunning || module.capital === 0 || btcLivePrice === 0} className="w-full bg-accent-green/80 hover:bg-accent-green text-white font-bold py-2 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
                                <TrendingUp size={16} className="inline-block mr-1"/> {t('openLong')}
                            </button>
                            <button onClick={() => handleOpenPosition('Short')} disabled={isBotRunning || module.capital === 0 || btcLivePrice === 0} className="w-full bg-accent-red/80 hover:bg-accent-red text-white font-bold py-2 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
                                <TrendingDown size={16} className="inline-block mr-1"/> {t('openShort')}
                            </button>
                        </div>
                    </div>
                )}
            </div>

            <div className="mt-6 border-t border-slate-800 pt-4 flex-shrink-0">
                <h4 className="text-lg font-bold text-white mb-2 flex items-center gap-2"><BrainCircuit size={20} className="text-accent-purple"/> AI Futures Analysis</h4>
                <motion.button
                    onClick={handleAnalyzeFunding}
                    disabled={isAnalyzing || isBotRunning}
                    className="w-full bg-slate-700/50 hover:bg-slate-700 text-accent-cyan font-semibold py-2 rounded-lg transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    {isAnalyzing ? (
                        <>
                            <motion.span animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }}><BrainCircuit size={16} /></motion.span>
                            <span>{t('analyzingFundingRates')}</span>
                        </>
                    ) : (
                        <>
                            <BrainCircuit size={16} />
                            <span>{t('analyzeFundingRates')}</span>
                        </>
                    )}
                </motion.button>

                <AnimatePresence mode="wait">
                    {aiAnalysis && (
                        <motion.div
                            key="futures-analysis-result"
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            transition={{ duration: 0.3 }}
                            className="mt-3 bg-slate-800 p-3 rounded-lg text-sm"
                        >
                            <div className="flex items-center justify-between text-slate-300 mb-1">
                                <span className="font-semibold">{t('aiPrediction')}:</span>
                                <span className={`font-bold ${aiAnalysis.prediction === 'LongBias' ? 'text-accent-green' : aiAnalysis.prediction === 'ShortBias' ? 'text-accent-red' : 'text-slate-400'}`}>
                                    {aiAnalysis.prediction}
                                </span>
                            </div>
                            <p className="text-slate-400">Suggested Leverage: <span className="font-mono text-accent-cyan">{aiAnalysis.optimalLeverage}x</span></p>
                            <p className="text-xs text-slate-500 italic mt-2">{t('reasoning')}: {aiAnalysis.reasoning}</p>
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>
        </Card>
    );
};

export default FuturesModule;
