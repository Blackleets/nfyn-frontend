import React, { useState, useMemo, useEffect } from 'react';
import { LiveCoin } from '../../types';
import { fetchHistoricalData } from '../../services/coingeckoService';
import Card from '../Card';
import { useTranslation } from '../../LanguageContext';
import { motion } from 'framer-motion';
import { ArrowUp, ArrowDown, BarChart } from 'lucide-react';

type Timeframe = '1D' | '7D' | '1M';
type AssetSymbol = 'BTC' | 'ETH' | 'SOL';

const ASSET_ID_MAP: Record<AssetSymbol, string> = {
    BTC: 'bitcoin',
    ETH: 'ethereum',
    SOL: 'solana',
};

const PriceChart: React.FC<{ liveCoinData: LiveCoin[], showControls?: boolean }> = ({ liveCoinData, showControls = true }) => {
    const { t } = useTranslation();
    const [selectedAsset, setSelectedAsset] = useState<AssetSymbol>('BTC');
    const [selectedTimeframe, setSelectedTimeframe] = useState<Timeframe>('1M');
    const [isLoading, setIsLoading] = useState(true);

    const assetData = useMemo(() => {
        return liveCoinData.find(c => c.symbol === selectedAsset);
    }, [liveCoinData, selectedAsset]);

    // Keep this effect to know when loading is finished, but we don't need the data itself for the placeholder.
    useEffect(() => {
        const assetId = ASSET_ID_MAP[selectedAsset];
        if (!assetId) return;

        const loadChartData = async () => {
            setIsLoading(true);
            const days = selectedTimeframe === '1D' ? 1 : selectedTimeframe === '7D' ? 7 : 30;
            // We still fetch to simulate loading and ensure the header has data,
            // but we won't use the chart data itself.
            await fetchHistoricalData(assetId, days);
            setIsLoading(false);
        };

        loadChartData();
    }, [selectedAsset, selectedTimeframe]);

    if (!assetData) {
        return <Card className="h-[500px] flex items-center justify-center"><p className="text-slate-400">Loading chart data...</p></Card>;
    }

    const isPositive = assetData.change24h >= 0;

    const timeframes: { label: Timeframe, text: string }[] = [{ label: '1D', text: '1D' }, { label: '7D', text: '7D' }, { label: '1M', text: '1M' }];
    const assets: AssetSymbol[] = ['BTC', 'ETH', 'SOL'];

    return (
        <Card className="h-auto md:h-[550px] p-0 flex flex-col relative overflow-hidden">
            {/* The header part remains the same */}
            <div className="p-4 border-b border-slate-800">
                <div className="flex flex-wrap justify-between items-center gap-4">
                    <div className="flex items-center gap-4">
                        <div className="flex items-center gap-2">
                             <div className="flex space-x-1 p-0.5 bg-slate-800 rounded-md">
                                {assets.map((asset) => (
                                    <button key={asset} onClick={() => setSelectedAsset(asset)} className={`px-3 py-1 text-sm font-semibold rounded transition-colors ${selectedAsset === asset ? 'bg-slate-700 shadow text-white' : 'text-slate-400 hover:bg-slate-700/50'}`}>
                                        {asset}
                                    </button>
                                ))}
                            </div>
                        </div>
                        <div>
                            <p className="text-2xl font-bold text-white">${assetData.price.toLocaleString()}</p>
                            <div className={`flex items-center gap-1 text-sm font-bold ${isPositive ? 'text-accent-green' : 'text-accent-red'}`}>
                                {isPositive ? <ArrowUp size={14} /> : <ArrowDown size={14} />} {assetData.change24h.toFixed(2)}%
                            </div>
                        </div>
                    </div>
                    {showControls && (
                        <div className="flex space-x-2 p-1 bg-slate-800 rounded-lg">
                            {timeframes.map(tf => (
                                <button key={tf.label} onClick={() => setSelectedTimeframe(tf.label)}
                                    className={`w-full px-4 py-2 text-sm font-semibold rounded-md transition-colors duration-200 focus:outline-none ${
                                    selectedTimeframe === tf.label ? 'bg-slate-700 text-white shadow' : 'text-slate-400 hover:bg-slate-700/50'}`}>
                                    {tf.text}
                                </button>
                            ))}
                        </div>
                    )}
                </div>
            </div>

            {/* The chart area is replaced with a placeholder */}
            <div className="flex-grow relative h-[400px] flex items-center justify-center">
                {isLoading ? (
                    <div className="text-center">
                         <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }} className="w-8 h-8 border-2 border-t-accent-cyan border-slate-700 rounded-full mx-auto" />
                         <p className="text-slate-400 mt-2 text-sm">Loading Chart...</p>
                    </div>
                ) : (
                    <div className="text-center text-slate-400 p-4">
                        <BarChart size={48} className="mx-auto text-slate-600 mb-4" />
                        <h3 className="font-semibold text-lg text-slate-300">Chart Temporarily Unavailable</h3>
                        <p className="text-sm mt-1">Our charting service is currently under maintenance. We are working to restore it as soon as possible.</p>
                    </div>
                )}
            </div>
        </Card>
    );
};

export default PriceChart;
