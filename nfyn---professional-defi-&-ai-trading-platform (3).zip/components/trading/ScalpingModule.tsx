import React, { useState, useEffect } from 'react';
import Card from '../Card';
import { ModuleState, BotTrade, TrendAnalysisResult, LiveCoin, HistoricalOHLCData } from '../../types';
import { useTranslation } from '../../LanguageContext';
import { BarChartHorizontal, BrainCircuit, Info, DollarSign, TrendingUp, TrendingDown } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { GeminiService } from '../../services/geminiService';
import SkeletonLoader from '../SkeletonLoader';
import { fetchHistoricalData } from '../../services/coingeckoService';
import { ChartData } from 'recharts'; // Used for fetching historical data

interface ScalpingModuleProps {
    module: ModuleState;
    isBotRunning: boolean;
    onUpdateModule: (updatedModule: ModuleState) => void;
    liveCoinData: LiveCoin[];
}

const formatCurrency = (value: number) => {
    return value.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
};

const PnlText: React.FC<{ value: number, className?: string }> = ({ value, className }) => {
    const isProfit = value >= 0;
    return (
        <span className={`font-bold ${isProfit ? 'text-accent-green' : 'text-accent-red'} ${className ?? ''}`}>
            {isProfit ? '+' : ''}${formatCurrency(value)}
        </span>
    );
};

const ScalpingModule: React.FC<ScalpingModuleProps> = ({ module, isBotRunning, onUpdateModule, liveCoinData }) => {
    const { t } = useTranslation();
    const [aiAnalysis, setAiAnalysis] = useState<TrendAnalysisResult | null>(null);
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const [historicalData, setHistoricalData] = useState<HistoricalOHLCData[]>([]);

    const btcLivePrice = liveCoinData.find(c => c.symbol === 'BTC')?.price || 0;
    const ethLivePrice = liveCoinData.find(c => c.symbol === 'ETH')?.price || 0;
    
    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        const numValue = parseFloat(value);
        if (!isNaN(numValue) && numValue >= 0) {
            onUpdateModule({
                ...module,
                [name]: numValue,
            });
        } else if (value === '') {
             onUpdateModule({
                ...module,
                [name]: 0,
            });
        }
    };

    const SettingInput: React.FC<{ label: string; value: any; onChange: (e: React.ChangeEvent<HTMLInputElement>) => void; name: string; disabled: boolean; unit?: string; min?: number; step?: number; }> = ({ label, value, onChange, name, disabled, unit, min, step }) => (
        <div>
            <label htmlFor={`${name}-${module.name}`} className="flex justify-between items-center text-sm font-medium text-slate-400 mb-1">
                <span>{label}</span>
                 {disabled && <Info size={12} className="text-yellow-400" title={t('riskChangeWarning')} />}
            </label>
            <div className="relative">
                <input
                    type="number"
                    id={`${name}-${module.name}`}
                    name={name}
                    value={value || ''}
                    onChange={onChange}
                    disabled={disabled}
                    min={min || 0}
                    step={step || 0.1}
                    className="w-full bg-slate-900 border border-slate-700 rounded-md px-3 py-2 text-sm disabled:opacity-50 appearance-none [-moz-appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                />
                {unit && <span className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none">{unit}</span>}
            </div>
        </div>
    );

    // Fetch historical data once for AI analysis
    useEffect(() => {
        const loadHistoricalData = async () => {
            const btcHistorical = await fetchHistoricalData('bitcoin', 90); // 90 days for trend analysis
            if (btcHistorical?.ohlcData) {
                setHistoricalData(btcHistorical.ohlcData);
            }
        };
        loadHistoricalData();
    }, []);

    const handleAnalyzeTrends = async () => {
        setIsAnalyzing(true);
        setAiAnalysis(null);
        try {
            if (historicalData.length === 0) {
                throw new Error("Historical data not available for analysis.");
            }
            const result = await GeminiService.analyzeMarketTrends('BTC', historicalData);
            setAiAnalysis(result);
        } catch (error) {
            console.error("Failed to get AI trend analysis:", error);
            setAiAnalysis({
                direction: 'Neutral',
                entrySuggestion: t('gemini.error.analysis'),
                exitSuggestion: t('gemini.error.analysis'),
                confidence: 0,
                reasoning: t('gemini.error.analysisReasoning'),
            });
        } finally {
            setIsAnalyzing(false);
        }
    };

    return (
        <Card highlight="cyan" className="p-4 flex flex-col h-full">
            <div className="flex items-center gap-3 mb-4">
                <BarChartHorizontal size={24} className="text-accent-cyan" />
                <h3 className="text-xl font-bold text-accent-cyan">{t('scalping')}</h3>
            </div>

            <div className="space-y-3 text-sm flex-grow">
                <div className="flex justify-between items-center">
                    <span className="text-slate-400">{t('moduleCapital')}</span>
                    <span className="font-mono text-white">${formatCurrency(module.capital)}</span>
                </div>
                <div className="flex justify-between items-center">
                    <span className="text-slate-400">{t('moduleTotalPnl')}</span>
                    <PnlText value={module.pnl} />
                </div>
                <div className="flex justify-between items-center">
                    <span className="text-slate-400">{t('moduleTotalTrades')}</span>
                    <span className="font-mono text-white">{module.totalTrades ?? 0}</span>
                </div>
                <div className="flex justify-between items-center">
                    <span className="text-slate-400">{t('moduleWinRate')}</span>
                    <span className="font-mono text-white">{(module.winRate ?? 0).toFixed(1)}%</span>
                </div>
                
                <div className="border-t border-slate-800 pt-3 mt-3 space-y-3">
                     <h4 className="text-md font-bold text-white">Configuration</h4>
                     <SettingInput
                        label={t('positionSize')}
                        name="positionSizePercent"
                        value={module.positionSizePercent}
                        onChange={handleChange}
                        disabled={isBotRunning}
                        unit="%"
                        min={1}
                        step={1}
                     />
                      <SettingInput
                        label={t('takeProfit')}
                        name="takeProfitPercent"
                        value={module.takeProfitPercent}
                        onChange={handleChange}
                        disabled={isBotRunning}
                        unit="%"
                        min={0.1}
                        step={0.1}
                     />
                      <SettingInput
                        label={t('stopLoss')}
                        name="stopLossPercent"
                        value={module.stopLossPercent}
                        onChange={handleChange}
                        disabled={isBotRunning}
                        unit="%"
                        min={0.1}
                        step={0.1}
                     />
                </div>
            </div>

            <div className="mt-6 border-t border-slate-800 pt-4 flex-shrink-0">
                <h4 className="text-lg font-bold text-white mb-2 flex items-center gap-2"><BrainCircuit size={20} className="text-accent-purple"/> AI Trend Analysis</h4>
                <motion.button
                    onClick={handleAnalyzeTrends}
                    disabled={isAnalyzing || isBotRunning}
                    className="w-full bg-slate-700/50 hover:bg-slate-700 text-accent-cyan font-semibold py-2 rounded-lg transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    {isAnalyzing ? (
                        <>
                            <motion.span animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }}><BrainCircuit size={16} /></motion.span>
                            <span>{t('analyzingTrends')}</span>
                        </>
                    ) : (
                        <>
                            <BrainCircuit size={16} />
                            <span>{t('analyzeTrends')}</span>
                        </>
                    )}
                </motion.button>
                
                 <AnimatePresence mode="wait">
                    {aiAnalysis && (
                        <motion.div
                            key="analysis-result"
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -10 }}
                            transition={{ duration: 0.3 }}
                            className="mt-4 space-y-3"
                        >
                            <div className="text-center bg-slate-800/50 p-2 rounded-lg">
                                <p className="text-sm font-semibold text-slate-400">{t('aiDirection')}</p>
                                <p className={`text-xl font-bold ${aiAnalysis.direction === 'Bullish' ? 'text-accent-green' : aiAnalysis.direction === 'Bearish' ? 'text-accent-red' : 'text-slate-300'}`}>
                                    {aiAnalysis.direction}
                                </p>
                            </div>
                            <div>
                                <div className="flex justify-between items-center text-xs text-slate-400 mb-1 px-1">
                                    <span>Confidence</span>
                                    <span>{aiAnalysis.confidence.toFixed(0)}%</span>
                                </div>
                                <div className="w-full bg-slate-700 rounded-full h-2 overflow-hidden">
                                    <motion.div 
                                        className={`h-2 rounded-full ${aiAnalysis.direction === 'Bullish' ? 'bg-accent-green' : aiAnalysis.direction === 'Bearish' ? 'bg-accent-red' : 'bg-slate-500'}`} 
                                        initial={{ width: 0 }}
                                        animate={{ width: `${aiAnalysis.confidence}%` }}
                                        transition={{ duration: 0.5, ease: 'easeOut' }}
                                    />
                                </div>
                            </div>
                             <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                <div className="bg-slate-800 p-3 rounded-lg border-l-4 border-accent-green">
                                    <h5 className="text-sm font-bold text-accent-green flex items-center gap-1"><TrendingUp size={14}/> {t('entrySignal')}</h5>
                                    <p className="text-slate-300 text-sm font-mono mt-1">{aiAnalysis.entrySuggestion}</p>
                                </div>
                                <div className="bg-slate-800 p-3 rounded-lg border-l-4 border-accent-red">
                                    <h5 className="text-sm font-bold text-accent-red flex items-center gap-1"><TrendingDown size={14}/> {t('exitSignal')}</h5>
                                    <p className="text-slate-300 text-sm font-mono mt-1">{aiAnalysis.exitSuggestion}</p>
                                </div>
                            </div>
                            <p className="text-xs text-slate-500 italic pt-1">{t('reasoning')}: {aiAnalysis.reasoning}</p>
                        </motion.div>
                    )}
                </AnimatePresence>

                {module.openPositions && module.openPositions.length > 0 && (
                    <div className="mt-4">
                        <h4 className="font-bold text-md mb-2">{t('moduleOpenPosition')}</h4>
                        {module.openPositions.map(pos => (
                            <div key={pos.id} className="bg-slate-800/50 p-2 rounded-lg text-sm flex justify-between items-center mb-1">
                                <span className="font-semibold text-white">{pos.symbol} {pos.side}</span>
                                <span className="text-slate-400">Entry: ${formatCurrency(pos.entryPrice)}</span>
                                <span className="text-slate-400">Current: ${formatCurrency(btcLivePrice || ethLivePrice)}</span> {/* Placeholder current price */}
                                <PnlText value={(btcLivePrice || ethLivePrice) - pos.entryPrice} />
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </Card>
    );
};

export default ScalpingModule;