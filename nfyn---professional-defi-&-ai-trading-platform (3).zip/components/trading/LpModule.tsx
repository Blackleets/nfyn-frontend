import React, { useState } from 'react';
import Card from '../Card';
import { ModuleState, LpPosition, LpRecommendation, LiveCoin } from '../../types';
import { useTranslation } from '../../LanguageContext';
// Add Plus to the import from lucide-react
import { Combine, BrainCircuit, SlidersHorizontal, Info, Plus } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { GeminiService } from '../../services/geminiService';
import SkeletonLoader from '../SkeletonLoader';

interface LpModuleProps {
    module: ModuleState;
    isBotRunning: boolean;
    onUpdateModule: (updatedModule: ModuleState) => void;
    liveCoinData: LiveCoin[];
}

const formatCurrency = (value: number) => {
    return value.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
};

const PnlText: React.FC<{ value: number, className?: string }> = ({ value, className }) => {
    const isProfit = value >= 0;
    return (
        <span className={`font-bold ${isProfit ? 'text-accent-green' : 'text-accent-red'} ${className ?? ''}`}>
            {isProfit ? '+' : ''}${formatCurrency(value)}
        </span>
    );
};

const LpModule: React.FC<LpModuleProps> = ({ module, isBotRunning, onUpdateModule, liveCoinData }) => {
    const { t } = useTranslation();
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const [aiRecommendation, setAiRecommendation] = useState<LpRecommendation | null>(null);

    const currentLpPosition = module.lpPositions?.[0]; // Assuming one LP position for simplicity

    const handleCreateLp = () => {
        if (module.capital === 0) return;
        const liquidityAmount = module.capital * 0.5; // Example: use 50% of capital
        const currentPrice = liveCoinData.find(c => c.symbol === 'ETH')?.price || 3500; // Assuming ETH-USDT pool
        
        onUpdateModule({
            ...module,
            capital: module.capital - liquidityAmount,
            lpPositions: [{
                id: `lp-${Date.now()}`,
                pair: 'ETH/USDT',
                rangeMin: currentPrice * 0.95,
                rangeMax: currentPrice * 1.05,
                fees: 0,
                il: 0,
                liquidityProvided: liquidityAmount,
            }],
        });
    };

    const handleManageLp = () => {
        // This would open a more complex modal to adjust range, add/remove liquidity
        alert("Managing LP position (feature coming soon!).");
    };

    const handleOptimizeRange = async () => {
        setIsAnalyzing(true);
        setAiRecommendation(null);
        try {
            const ethPrice = liveCoinData.find(c => c.symbol === 'ETH')?.price;
            if (!ethPrice) {
                throw new Error("Live ETH price not available for LP optimization.");
            }
            // Simulate current volatility (e.g., 3%)
            const currentVolatility = 0.03; 
            const result = await GeminiService.optimizeLPPool(
                'ETH/USDT',
                ethPrice,
                currentVolatility,
                module.rangeTolerance ?? 5
            );
            setAiRecommendation(result);
        } catch (error) {
            console.error("Failed to get AI LP optimization:", error);
            const ethPrice = liveCoinData.find(c => c.symbol === 'ETH')?.price || 3500;
            const defaultMin = ethPrice * (1 - (module.rangeTolerance ?? 5) / 100 * 1.5);
            const defaultMax = ethPrice * (1 + (module.rangeTolerance ?? 5) / 100 * 1.5);
            setAiRecommendation({
                minPrice: defaultMin,
                maxPrice: defaultMax,
                reasoning: t('gemini.error.analysisReasoning'),
                feeTier: '0.3%', // Added feeTier to fallback
            });
        } finally {
            setIsAnalyzing(false);
        }
    };

    return (
        <Card highlight="purple" className="p-4 flex flex-col h-full">
            <div className="flex items-center gap-3 mb-4">
                <Combine size={24} className="text-accent-purple" />
                <h3 className="text-xl font-bold text-accent-purple">{t('lp')}</h3>
            </div>

            <div className="space-y-3 text-sm flex-grow">
                <div className="flex justify-between items-center">
                    <span className="text-slate-400">{t('moduleCapital')}</span>
                    <span className="font-mono text-white">${formatCurrency(module.capital)}</span>
                </div>
                <div className="flex justify-between items-center">
                    <span className="text-slate-400">{t('moduleTotalPnl')}</span>
                    <PnlText value={module.pnl} />
                </div>
                
                {currentLpPosition ? (
                    <>
                        <div className="border-t border-slate-800 pt-3 mt-3">
                            <h4 className="font-bold text-md text-white mb-2">Current LP: {currentLpPosition.pair}</h4>
                            <div className="flex justify-between items-center">
                                <span className="text-slate-400">Liquidity Provided</span>
                                <span className="font-mono text-white">${formatCurrency(currentLpPosition.liquidityProvided)}</span>
                            </div>
                            <div className="flex justify-between items-center">
                                <span className="text-slate-400">Price Range</span>
                                <span className="font-mono text-white">${formatCurrency(currentLpPosition.rangeMin)} - ${formatCurrency(currentLpPosition.rangeMax)}</span>
                            </div>
                            <div className="flex justify-between items-center">
                                <span className="text-slate-400">{t('moduleFeesEarned')}</span>
                                <PnlText value={currentLpPosition.fees} />
                            </div>
                            <div className="flex justify-between items-center">
                                <span className="text-slate-400">{t('moduleImpermanentLoss')}</span>
                                <PnlText value={currentLpPosition.il} />
                            </div>
                        </div>
                        <div className="mt-4">
                             <button onClick={handleManageLp} disabled={isBotRunning} className="w-full bg-slate-700/50 hover:bg-slate-700 text-white font-semibold py-2 rounded-lg transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed">
                                <SlidersHorizontal size={16} /> {t('manageLp')}
                            </button>
                        </div>
                    </>
                ) : (
                    <div className="mt-4 text-center text-slate-400">
                        <p>{t('noActiveLp')}</p>
                        <button onClick={handleCreateLp} disabled={isBotRunning || module.capital === 0} className="w-full bg-slate-700/50 hover:bg-slate-700 text-white font-semibold py-2 rounded-lg transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed mt-2">
                            <Plus size={16} /> {t('createLp')}
                        </button>
                    </div>
                )}
            </div>

            <div className="mt-6 border-t border-slate-800 pt-4 flex-shrink-0">
                <h4 className="text-lg font-bold text-white mb-2 flex items-center gap-2"><BrainCircuit size={20} className="text-accent-purple"/> AI Range Optimization</h4>
                <motion.button
                    onClick={handleOptimizeRange}
                    disabled={isAnalyzing || isBotRunning || !currentLpPosition}
                    className="w-full bg-slate-700/50 hover:bg-slate-700 text-accent-cyan font-semibold py-2 rounded-lg transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    {isAnalyzing ? (
                        <>
                            <motion.span animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }}><BrainCircuit size={16} /></motion.span>
                            <span>{t('optimizingLpRange')}</span>
                        </>
                    ) : (
                        <>
                            <BrainCircuit size={16} />
                            <span>{t('optimizeLpRange')}</span>
                        </>
                    )}
                </motion.button>

                <AnimatePresence mode="wait">
                    {aiRecommendation && (
                        <motion.div
                            key="lp-analysis-result"
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            transition={{ duration: 0.3 }}
                            className="mt-3 bg-slate-800 p-3 rounded-lg text-sm"
                        >
                            <h5 className="font-semibold text-white">{t('aiSuggestedRange')}:</h5>
                            <p className="text-slate-400">Min: ${formatCurrency(aiRecommendation.minPrice)}</p>
                            <p className="text-slate-400">Max: ${formatCurrency(aiRecommendation.maxPrice)}</p>
                            <p className="text-slate-400">{t('feeTier')}: <span className="font-mono text-accent-cyan">{aiRecommendation.feeTier}</span></p>
                            <p className="text-xs text-slate-500 italic mt-2">{t('reasoning')}: {aiRecommendation.reasoning}</p>
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>
        </Card>
    );
};

export default LpModule;