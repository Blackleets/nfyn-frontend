import React, { useEffect, useRef, memo } from 'react';

declare global {
    interface Window {
        TradingView: any;
    }
}

const TradingViewWidget: React.FC = memo(() => {
    const containerRef = useRef<HTMLDivElement>(null);
    const widgetCreatedRef = useRef(false);

    useEffect(() => {
        const scriptId = 'tradingview-widget-script';
        const existingScript = document.getElementById(scriptId);

        const createWidget = () => {
            if (containerRef.current && 'TradingView' in window && !widgetCreatedRef.current) {
                new window.TradingView.widget({
                    autosize: true,
                    symbol: "BINANCE:BTCUSDT",
                    interval: "240", // 4 hours
                    timezone: "Etc/UTC",
                    theme: "dark",
                    style: "1",
                    locale: "en",
                    enable_publishing: false,
                    withdateranges: true,
                    hide_side_toolbar: false,
                    allow_symbol_change: true,
                    container_id: containerRef.current.id,
                    studies: [
                        "Volume@tv-basicstudies",
                        "RSI@tv-basicstudies"
                    ],
                    news: ["headlines"],
                    hotlist: true,
                });
                widgetCreatedRef.current = true;
            }
        };

        if (!existingScript) {
            const script = document.createElement('script');
            script.id = scriptId;
            script.src = 'https://s3.tradingview.com/tv.js';
            script.type = 'text/javascript';
            script.async = true;
            script.onload = createWidget;
            document.head.appendChild(script);
        } else {
            // If script exists, the library might already be loaded.
            // A brief timeout can help ensure the TradingView object is ready.
            const checkInterval = setInterval(() => {
                if ('TradingView' in window) {
                    clearInterval(checkInterval);
                    createWidget();
                }
            }, 100);
        }

        return () => {
            // On unmount, clear the container.
            if (containerRef.current) {
                containerRef.current.innerHTML = '';
            }
            widgetCreatedRef.current = false;
        };
    }, []);

    return (
        <div className="tradingview-widget-container h-full w-full">
            <div id={`tradingview_widget_${Math.random().toString(36).substring(2)}`} ref={containerRef} className="h-full w-full" />
        </div>
    );
});

export default TradingViewWidget;