import React, { useState, useEffect } from 'react';
import Card from './Card';
import { GeminiService } from '../services/geminiService';
import { useTranslation } from '../LanguageContext';
import SkeletonLoader from './SkeletonLoader';
import { BrainCircuit } from 'lucide-react';

const MarketSummaryAI: React.FC = () => {
    const { t } = useTranslation();
    const [summary, setSummary] = useState<string>('');
    const [isLoading, setIsLoading] = useState<boolean>(true);

    useEffect(() => {
        const fetchSummary = async () => {
            setIsLoading(true);
            const result = await GeminiService.getMarketSummary();
            setSummary(result.startsWith("gemini.error") ? t(result) : result);
            setIsLoading(false);
        };

        fetchSummary();
    }, [t]);

    return (
        <Card>
            <div className="p-4">
                <h3 className="font-bold text-lg text-slate-800 dark:text-slate-50 flex items-center gap-2">
                    <BrainCircuit className="text-accent-purple" />
                    <span>{t('aiMarketBriefing')}</span>
                </h3>
                <div className="mt-3 text-sm text-slate-600 dark:text-slate-300">
                    {isLoading ? (
                        <div className="space-y-2">
                            <SkeletonLoader className="h-4 w-full" />
                            <SkeletonLoader className="h-4 w-full" />
                            <SkeletonLoader className="h-4 w-5/6" />
                        </div>
                    ) : (
                        <p className="whitespace-pre-wrap">{summary}</p>
                    )}
                </div>
            </div>
        </Card>
    );
};

export default MarketSummaryAI;
