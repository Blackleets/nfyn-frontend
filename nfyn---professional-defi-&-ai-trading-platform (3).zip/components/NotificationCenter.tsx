import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AppNotification } from '../types';
import { Bell } from 'lucide-react';

interface ToastProps {
  notification: AppNotification;
  onDismiss: (id: number) => void;
}

const Toast: React.FC<ToastProps> = ({ notification, onDismiss }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onDismiss(notification.id);
    }, 5000); // Auto-dismiss after 5 seconds

    return () => {
      clearTimeout(timer);
    };
  }, [notification.id, onDismiss]);

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 50, scale: 0.5 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: 20, scale: 0.7 }}
      transition={{ type: 'spring', stiffness: 300, damping: 25 }}
      className="relative w-full max-w-sm p-4 rounded-xl shadow-lg bg-slate-800/80 backdrop-blur-md text-white border border-slate-700 overflow-hidden"
    >
        <div className="flex items-start gap-3">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-accent-cyan/20 flex items-center justify-center mt-0.5">
                <Bell className="w-5 h-5 text-accent-cyan" />
            </div>
            <div className="flex-grow">
                 <p className="font-bold text-base text-slate-50">Reminder</p>
                 <p className="text-sm text-slate-300">{notification.message}</p>
            </div>
             <button
                onClick={() => onDismiss(notification.id)}
                className="absolute top-2 right-2 text-slate-400 hover:text-white transition-colors"
                aria-label="Dismiss"
            >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
        </div>
    </motion.div>
  );
};


interface NotificationCenterProps {
  notifications: AppNotification[];
  onDismiss: (id: number) => void;
}

const NotificationCenter: React.FC<NotificationCenterProps> = ({ notifications, onDismiss }) => {
  return (
    <div className="fixed top-4 right-4 z-[100] w-full max-w-sm flex flex-col items-end gap-3 pointer-events-none">
      <AnimatePresence>
        {notifications.map(notification => (
           <div key={notification.id} className="pointer-events-auto">
             <Toast notification={notification} onDismiss={onDismiss} />
           </div>
        ))}
      </AnimatePresence>
    </div>
  );
};

export default NotificationCenter;