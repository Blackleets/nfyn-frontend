import React, { useMemo } from 'react';
import { ArrowUp, ArrowDown } from 'lucide-react';
import { TickerAsset } from '../types';

const TickerItem: React.FC<{ asset: TickerAsset }> = React.memo(({ asset }) => {
    const isPositive = asset.change !== null && asset.change >= 0;
    const formatPrice = (price: number | null) => {
        if (price === null) return '--';
        return price.toLocaleString('en-US', {
            minimumFractionDigits: 2,
            maximumFractionDigits: price > 1 ? 2 : 5,
        });
    };
    
    return (
        <div className="flex items-center space-x-4 mx-4 flex-shrink-0 text-sm">
            <span className="font-semibold text-slate-800 dark:text-slate-200">{asset.symbol}</span>
            <span className="font-mono text-slate-900 dark:text-slate-50">{formatPrice(asset.price)}</span>
            {asset.change !== null && (
                <div className={`flex items-center font-semibold ${isPositive ? 'text-accent-green' : 'text-accent-red'}`}>
                    {isPositive ? <ArrowUp size={14} className="mr-1" /> : <ArrowDown size={14} className="mr-1" />}
                    {asset.change.toFixed(2)}%
                </div>
            )}
        </div>
    );
});


const TickerTape: React.FC<{ assets: TickerAsset[] }> = ({ assets }) => {
    const overallTrend = useMemo(() => {
        if (!assets || assets.length === 0) return 'neutral';
        const averageChange = assets.reduce((sum, asset) => sum + (asset.change ?? 0), 0) / assets.length;
        return averageChange >= 0 ? 'positive' : 'negative';
    }, [assets]);
    
    if (!assets || assets.length === 0) {
        return <div className="h-10 bg-slate-200 dark:bg-slate-800 animate-pulse" />;
    }
    
    const tickerItems = [...assets, ...assets];
    
    const backgroundClass = overallTrend === 'positive' ? 'bg-ambient-green' : 'bg-ambient-red';

    return (
        <div className={`h-10 w-full bg-slate-800/60 backdrop-blur-sm overflow-hidden border-b border-slate-700 relative`}>
            <div className={`absolute inset-0 transition-opacity duration-1000 ${backgroundClass}`}></div>
            <div className="w-max flex items-center h-full animate-ticker-scroll hover:[animation-play-state:paused] relative z-10">
                {tickerItems.map((asset, index) => (
                    <TickerItem key={`${asset.symbol}-${index}`} asset={asset} />
                ))}
            </div>
        </div>
    );
};

export default TickerTape;