const { Redis } = require('ioredis');
require('dotenv').config();

// This connection is reused by all BullMQ components.
const connection = new Redis(process.env.REDIS_URL, {
  maxRetriesPerRequest: null, // Important for BullMQ
});

connection.on('connect', () => {
    console.log('Redis connected...');
});

connection.on('error', (err) => {
    console.error('Redis connection error:', err);
    process.exit(1);
});


module.exports = connection;
