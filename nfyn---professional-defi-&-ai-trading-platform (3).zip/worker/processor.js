const { Worker } = require('bullmq');
const connection = require('./connection');

const QUEUE_NAME = 'nfyn-tasks';

console.log('Worker is starting...');

// The Worker instance is what processes jobs.
// It connects to Redis and waits for new jobs to appear in the specified queue.
const worker = new Worker(
  QUEUE_NAME,
  async (job) => {
    // This is where your job processing logic will go.
    // For example, running AI models, sending notifications, processing trades.
    console.log(`Processing job #${job.id} with data:`, job.data);

    // Simulate some work.
    await new Promise(resolve => setTimeout(resolve, 2000));

    // You can return a result that gets stored on the job object.
    return { status: 'Completed', processedAt: new Date() };
  },
  { connection }
);

worker.on('completed', (job) => {
  console.log(`Job #${job.id} has completed!`);
});

worker.on('failed', (job, err) => {
  console.error(`Job #${job.id} has failed with error: ${err.message}`);
});

console.log(`Worker listening for jobs on queue: "${QUEUE_NAME}"`);
