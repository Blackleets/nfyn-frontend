import { ApiNewsArticle, FearAndGreedIndex, MarketMover } from '../types';
import { PubliApisService } from './publiApisService'; // Import the new PubliApisService

// --- EXPORTED SERVICE CLASS ---

export class NewsService {

    /**
     * Fetches a list of recent news articles.
     * Delegates to PubliApisService for data retrieval and caching.
     */
    static async getNewsFeed(): Promise<ApiNewsArticle[]> {
        // Delegate to PubliApisService
        return PubliApisService.getNewsFeed();
    }
    
    /**
     * Fetches the current Crypto Fear & Greed Index value.
     * Delegates to PubliApisService for data retrieval and caching.
     */
    static async getFearAndGreedIndex(): Promise<FearAndGreedIndex | null> {
        // Delegate to PubliApisService
        return PubliApisService.getFearAndGreedIndex();
    }

    /**
     * Fetches the top market gainers and losers.
     * Delegates to PubliApisService for data retrieval and caching.
     */
    static async getMarketMovers(): Promise<{ gainers: MarketMover[]; losers: MarketMover[] }> {
        // Delegate to PubliApisService
        return PubliApisService.getMarketMovers();
    }
}