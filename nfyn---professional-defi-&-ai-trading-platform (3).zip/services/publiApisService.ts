import { ApiNewsArticle, TrendingCoin, FearAndGreedIndex, MarketMover, NewTokenLaunch } from '../types';
import { CRYPTOCOMPARE_BASE_URL, CRYPTOCOMPARE_API_KEY, OPEN_EXCHANGE_RATES_BASE_URL } from './coingeckoService'; // Import necessary constants

// --- CONFIGURATION ---
const PUBLIC_APIS_BASE_URL = 'https://api.publicapis.io'; // Base URL for publicapis.io if used as an aggregator
const NEWS_API_KEY = process.env.NEWS_API_KEY || 'YOUR_NEWS_API_KEY'; // Placeholder for a generic news API key
const TWITTER_API_KEY = process.env.TWITTER_API_KEY || 'YOUR_TWITTER_API_KEY'; // Placeholder for Twitter API key

// --- MOCK DATA FOR API SIMULATION (similar to newsService.ts, but centralized here) ---
const MOCK_NEWS_ARTICLES: Omit<ApiNewsArticle, 'id' | 'publishedAt'>[] = [
    { title: "Bitcoin Surges Past $70,000 as Institutional Interest Grows", summary: "Major investment firms are increasing their Bitcoin holdings, signaling strong bullish sentiment in the market.", imageUrl: "https://images.unsplash.com/photo-1621417019369-16a7b74f3a74?q=80&w=600", source: "CoinDesk", articleUrl: "#" },
    { title: "Ethereum's Dencun Upgrade Drastically Reduces Layer 2 Fees", summary: "The latest network upgrade has successfully lowered transaction costs on Layer 2 solutions, boosting scalability.", imageUrl: "https://images.unsplash.com/photo-1631603090989-93f9ef6911b3?q=80&w=600", source: "The Block", articleUrl: "#" },
    { title: "Solana Ecosystem Sees Explosive Growth in DeFi and Memecoins", summary: "A wave of new projects and high transaction speeds are attracting users and developers to the Solana network.", imageUrl: "https://images.unsplash.com/photo-1642100249052-4e052c9f55e2?q=80&w=600", source: "Decrypt", articleUrl: "#" },
    { title: "SEC Delays Decision on Spot Ethereum ETF, Market Remains Cautious", summary: "The U.S. Securities and Exchange Commission has postponed its decision, leaving investors in a state of uncertainty.", imageUrl: "https://images.unsplash.com/photo-1518546305921-a20237ee734a?q=80&w=600", source: "Reuters", articleUrl: "#" },
    { title: "The Rise of Real-World Asset (RWA) Tokenization on Blockchain", summary: "Tokenizing traditional assets like real estate and bonds is becoming a major trend, bridging TradFi and DeFi.", imageUrl: "https://images.unsplash.com/photo-1665686306574-1ace09918530?q=80&w=600", source: "CryptoControl", articleUrl: "#" },
    { title: "Fear & Greed Index Swings to 'Extreme Greed' as Market Rallies", summary: "The popular sentiment indicator shows high levels of optimism, but some analysts warn of a potential correction.", imageUrl: "https://images.unsplash.com/photo-1502920514358-195b5b82a88f?q=80&w=600", source: "Alternative.me", articleUrl: "#" }
];

const MOCK_MARKET_MOVERS: Omit<MarketMover, 'id'>[] = [
    { name: "Render", symbol: "RNDR", logoUrl: "https://s2.coinmarketcap.com/static/img/coins/64x64/11066.png", price: 10.50, change24h: 15.23, sparkline: [100, 102, 105, 103, 108, 110, 115] },
    { name: "Fetch.ai", symbol: "FET", logoUrl: "https://s2.coinmarketcap.com/static/img/coins/64x64/3773.png", price: 2.30, change24h: 12.88, sparkline: [90, 92, 91, 95, 98, 105, 112] },
    { name: "Pepe", symbol: "PEPE", logoUrl: "https://s2.coinmarketcap.com/static/img/coins/64x64/24478.png", price: 0.000014, change24h: 9.75, sparkline: [100, 101, 99, 102, 105, 107, 109] },
    { name: "Starknet", symbol: "STRK", logoUrl: "https://s2.coinmarketcap.com/static/img/coins/64x64/26383.png", price: 1.25, change24h: -5.67, sparkline: [100, 98, 95, 96, 92, 90, 94] },
    { name: "Ethena", symbol: "ENA", logoUrl: "https://s2.coinmarketcap.com/static/img/coins/64x64/29721.png", price: 0.91, change24h: -7.21, sparkline: [110, 105, 102, 100, 98, 95, 93] },
];

const MOCK_NEW_TOKEN_LAUNCHES: Omit<NewTokenLaunch, 'id' | 'launchDate'>[] = [
    { name: "Quantum Protocol", symbol: "QTM", logoUrl: "https://picsum.photos/seed/quantum/64", network: "Ethereum", price: 0.12, change24h: 250, marketCap: 1200000, liquidity: 800000, volume24h: 5000000, contractAddress: "0x...", description: "A new protocol for quantum-resistant cryptography.", hasAudit: true },
    { name: "AeroDAO", symbol: "AERO", logoUrl: "https://picsum.photos/seed/aero/64", network: "Solana", price: 0.05, change24h: 180, marketCap: 800000, liquidity: 400000, volume24h: 3000000, contractAddress: "0x...", description: "Decentralized autonomous organization for aviation industry.", hasAudit: false },
    { name: "FusionX", symbol: "FSX", logoUrl: "https://picsum.photos/seed/fusion/64", network: "BSC", price: 0.008, change24h: 320, marketCap: 500000, liquidity: 250000, volume24h: 1800000, contractAddress: "0x...", description: "Yield farming aggregator with cross-chain capabilities.", hasAudit: true },
    { name: "Nebula Chain", symbol: "NBL", logoUrl: "https://picsum.photos/seed/nebula/64", network: "Ethereum", price: 0.25, change24h: 90, marketCap: 2500000, liquidity: 1500000, volume24h: 7000000, contractAddress: "0x...", description: "Layer 2 solution focused on privacy and scalability.", hasAudit: true },
    { name: "DegenBlast", symbol: "DGB", logoUrl: "https://picsum.photos/seed/degen/64", network: "Arbitrum", price: 0.0001, change24h: 1500, marketCap: 150000, liquidity: 75000, volume24h: 1000000, contractAddress: "0x...", description: "A high-risk, high-reward memecoin experiment.", hasAudit: false },
    { name: "HydroSwap", symbol: "HYS", logoUrl: "https://picsum.photos/seed/hydro/64", network: "Polygon", price: 0.015, change24h: 75, marketCap: 900000, liquidity: 600000, volume24h: 2500000, contractAddress: "0x...", description: "Sustainable energy tokenomics with integrated DEX.", hasAudit: true },
];


// Reusing some constants from coingeckoService.ts for consistency
const CACHE_KEY = {
    NEWS_FEED: 'nfyn_news_feed_cache',
    FEAR_GREED: 'nfyn_fear_greed_cache',
    MARKET_MOVERS: 'nfyn_market_movers_cache',
    TWITTER_TRENDS: 'nfyn_twitter_trends_cache',
    COINGECKO_TRENDING: 'nfyn_coingecko_trending_cache',
    NEW_TOKEN_LAUNCHES: 'nfyn_new_token_launches_cache', // New cache key
};
const CACHE_TTL = {
    NEWS_FEED: 60 * 1000, // 60 seconds as per requirement
    FEAR_GREED: 30 * 60 * 1000, // 30 minutes
    MARKET_MOVERS: 10 * 60 * 1000, // 10 minutes
    TWITTER_TRENDS: 5 * 60 * 1000, // 5 minutes for KOLs/Twitter
    COINGECKO_TRENDING: 15 * 60 * 1000, // 15 minutes for trending coins
    NEW_TOKEN_LAUNCHES: 5 * 60 * 1000, // 5 minutes for new token launches
};

// --- UTILITY FUNCTIONS ---
async function getCachedData<T>(key: string): Promise<T | null> {
    try {
        const item = localStorage.getItem(key);
        if (item) {
            const { timestamp, data } = JSON.parse(item);
            if (Date.now() - timestamp < CACHE_TTL[key as keyof typeof CACHE_TTL]) {
                return data;
            }
        }
    } catch (error) {
        console.warn(`PubliApisService: Failed to read cache for ${key}:`, error);
    }
    return null;
}

function setCachedData<T>(key: string, data: T) {
    try {
        const item = { timestamp: Date.now(), data };
        localStorage.setItem(key, JSON.stringify(item));
    } catch (error) {
        console.warn(`PubliApisService: Failed to write cache for ${key}:`, error);
    }
}

const simulateDelay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// --- API FETCHING LOGIC (MOCKED FOR NOW) ---

export class PubliApisService {

    /**
     * Fetches real-time crypto news articles.
     * This method simulates fetching from various news sources.
     */
    static async getNewsFeed(): Promise<ApiNewsArticle[]> {
        const cached = await getCachedData<ApiNewsArticle[]>(CACHE_KEY.NEWS_FEED);
        if (cached) return cached;

        try {
            await simulateDelay(800); // Simulate network latency

            const articles = MOCK_NEWS_ARTICLES.map((article, index) => ({
                ...article,
                id: `news-${index}-${Date.now()}`,
                publishedAt: new Date(Date.now() - Math.random() * 24 * 3600 * 1000).toISOString(), // Random recent time
            }));

            setCachedData(CACHE_KEY.NEWS_FEED, articles);
            return articles;
        } catch (error) {
            console.error("PubliApisService Error (getNewsFeed):", error);
            return [];
        }
    }

    /**
     * Fetches trending cryptocurrency data (e.g., from CoinMarketCap/CoinGecko).
     * This is a mock implementation. In a real app, it would hit a real API.
     */
    static async getTrendingCoins(): Promise<TrendingCoin[]> {
        const cached = await getCachedData<TrendingCoin[]>(CACHE_KEY.COINGECKO_TRENDING);
        if (cached) return cached;

        try {
            await simulateDelay(500);
            // Example of a real (but simplified) CoinGecko API call (would need full coingeckoService logic)
            // const response = await fetch('https://api.coingecko.com/api/v3/search/trending');
            // const data = await response.json();
            // const trending = data.coins.map(coin => ({
            //     id: coin.item.id,
            //     name: coin.item.name,
            //     symbol: coin.item.symbol,
            //     thumb: coin.item.thumb,
            //     market_cap_rank: coin.item.market_cap_rank,
            // }));

            // For now, mock some trending coins
            const mockTrending: TrendingCoin[] = [
                { id: 'solana', name: 'Solana', symbol: 'SOL', thumb: 'https://assets.coingecko.com/coins/images/4128/thumb/solana.png?1640133425', market_cap_rank: 5 },
                { id: 'dogecoin', name: 'Dogecoin', symbol: 'DOGE', thumb: 'https://assets.coingecko.com/coins/images/5/thumb/dogecoin.png?1547792256', market_cap_rank: 8 },
                { id: 'pepe', name: 'Pepe', symbol: 'PEPE', thumb: 'https://assets.coingecko.com/coins/images/29840/thumb/pepe.png?1682333072', market_cap_rank: 40 },
                { id: 'bonk', name: 'Bonk', symbol: 'BONK', thumb: 'https://assets.coingecko.com/coins/images/28343/thumb/bonk.png?1670989894', market_cap_rank: 60 },
            ];

            setCachedData(CACHE_KEY.COINGECKO_TRENDING, mockTrending);
            return mockTrending;
        } catch (error) {
            console.error("PubliApisService Error (getTrendingCoins):", error);
            return [];
        }
    }

    /**
     * Fetches market movers (top gainers/losers).
     * This is a mock implementation.
     */
    static async getMarketMovers(): Promise<{ gainers: MarketMover[]; losers: MarketMover[] }> {
        const cached = await getCachedData<{ gainers: MarketMover[]; losers: MarketMover[] }>(CACHE_KEY.MARKET_MOVERS);
        if (cached) return cached;

        try {
            await simulateDelay(600);

            const movers = MOCK_MARKET_MOVERS.map((mover, i) => ({
                ...mover,
                id: `mover-${i}`
            }));

            const result = {
                gainers: movers.filter(m => m.change24h >= 0),
                losers: movers.filter(m => m.change24h < 0),
            };

            setCachedData(CACHE_KEY.MARKET_MOVERS, result);
            return result;

        } catch (error) {
            console.error("PubliApisService Error (getMarketMovers):", error);
            return { gainers: [], losers: [] };
        }
    }

    /**
     * Fetches the current Crypto Fear & Greed Index value.
     * This is a mock implementation.
     */
    static async getFearAndGreedIndex(): Promise<FearAndGreedIndex | null> {
        const cached = await getCachedData<FearAndGreedIndex>(CACHE_KEY.FEAR_GREED);
        if (cached) return cached;

        try {
            await simulateDelay(500);

            const value = Math.floor(Math.random() * 80) + 15; // From 15 to 95
            let classification = "Neutral";
            if (value <= 25) classification = "Extreme Fear";
            else if (value <= 45) classification = "Fear";
            else if (value >= 75) classification = "Extreme Greed";
            else if (value >= 55) classification = "Greed";

            const result: FearAndGreedIndex = {
                value: value,
                value_classification: classification,
                timestamp: new Date().toISOString(),
            };

            setCachedData(CACHE_KEY.FEAR_GREED, result);
            return result;
        } catch (error) {
            console.error("PubliApisService Error (getFearAndGreedIndex):", error);
            return null;
        }
    }

    /**
     * Simulates fetching a Twitter stream for KOLs.
     * Due to Twitter API complexity and rate limits, this is a simplified mock.
     * In a real application, you'd need OAuth and proper API calls.
     */
    static async getKOLTwitterStream(kols: { handle: string }[]): Promise<{ handle: string; latestTweet: string }[]> {
        const cached = await getCachedData<{ handle: string; latestTweet: string }[]>(CACHE_KEY.TWITTER_TRENDS);
        if (cached) return cached;

        try {
            await simulateDelay(1000); // Simulate network latency

            const mockTweets = kols.map(kol => ({
                handle: kol.handle,
                latestTweet: `Just tweeted about the market. Check my feed! #crypto #${kol.handle.substring(1)}`
            }));
            
            setCachedData(CACHE_KEY.TWITTER_TRENDS, mockTweets);
            return mockTweets;
        } catch (error) {
            console.error("PubliApisService Error (getKOLTwitterStream):", error);
            return [];
        }
    }

    /**
     * Fetches new token launches (mocked from GMGN API or similar).
     */
    static async getNewTokenLaunches(): Promise<NewTokenLaunch[]> {
        const cached = await getCachedData<NewTokenLaunch[]>(CACHE_KEY.NEW_TOKEN_LAUNCHES);
        if (cached) return cached;

        try {
            await simulateDelay(1200); // Simulate network latency

            const launches = MOCK_NEW_TOKEN_LAUNCHES.map((token, index) => ({
                ...token,
                id: `newtoken-${index}-${Date.now()}`,
                launchDate: Date.now() - Math.random() * 7 * 24 * 3600 * 1000, // Random launch within last 7 days
                price: parseFloat((token.price * (1 + (Math.random() - 0.5) * 0.5)).toFixed(token.price < 0.01 ? 6 : 2)), // Vary price slightly
                change24h: parseFloat((token.change24h + (Math.random() - 0.5) * 50).toFixed(2)), // Vary change slightly
                marketCap: parseFloat((token.marketCap * (1 + (Math.random() - 0.5) * 0.2)).toFixed(0)),
                liquidity: parseFloat((token.liquidity * (1 + (Math.random() - 0.5) * 0.2)).toFixed(0)),
                volume24h: parseFloat((token.volume24h * (1 + (Math.random() - 0.5) * 0.2)).toFixed(0)),
            }));

            setCachedData(CACHE_KEY.NEW_TOKEN_LAUNCHES, launches);
            return launches;
        } catch (error) {
            console.error("PubliApisService Error (getNewTokenLaunches):", error);
            return [];
        }
    }
}