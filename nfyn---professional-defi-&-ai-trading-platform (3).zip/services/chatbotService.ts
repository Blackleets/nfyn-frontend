import { GoogleGenAI } from "@google/genai";

const SYSTEM_INSTRUCTION = `You are NEO, the integrated AI assistant for NFYN, a professional DeFi & AI trading platform. 
Your purpose is to help users with market analysis, trading strategies, and understanding platform features. 
- Be concise and clear in your responses.
- Use a helpful and professional tone.
- If asked for financial advice, politely decline and state that you are an AI assistant and cannot provide financial advice.
- When asked about market data (e.g., "What's the price of BTC?"), state that you don't have real-time data but can provide general information or analysis.
- Keep answers relatively short, suitable for a chat interface.`;


export class ChatbotService {
    /**
     * Fetches a response from the Gemini API. Can leverage streaming for low-latency
     * with gemini-2.5-flash-lite, or use gemini-2.5-pro with thinking budget for complex queries.
     * @param message - The user's input message.
     * @param useThinkingMode - If true, uses gemini-2.5-pro with a high thinking budget for complex reasoning.
     * @returns A promise that resolves to the chatbot's string response.
     */
    static async getResponse(message: string, useThinkingMode: boolean = false): Promise<string> {
        // Re-instantiate GoogleGenAI inside the function to ensure the latest API key is always used.
        const aiInstance = new GoogleGenAI({ apiKey: process.env.API_KEY as string }); 

        if (useThinkingMode) {
            try {
                const response = await aiInstance.models.generateContent({
                    model: 'gemini-2.5-pro',
                    contents: message,
                    config: {
                        systemInstruction: SYSTEM_INSTRUCTION,
                        thinkingConfig: { thinkingBudget: 32768 } // Max budget for 2.5 Pro
                    }
                });
                return response.text;
            } catch (error) {
                console.error("Gemini ChatbotService Error (Thinking Mode):", error);
                return "I'm currently engaged in a deep thought process. My apologies, I couldn't complete that complex query. Please try simplifying your question or disabling thinking mode.";
            }
        } else {
            // Existing low-latency streaming logic with gemini-2.5-flash-lite
            try {
                const responseStream = await aiInstance.models.generateContentStream({
                    model: 'gemini-2.5-flash',
                    contents: message,
                    config: {
                        systemInstruction: SYSTEM_INSTRUCTION,
                    }
                });

                let fullResponse = '';
                for await (const chunk of responseStream) {
                    if (chunk.text) {
                        fullResponse += chunk.text;
                    }
                }
                return fullResponse;

            } catch (error) {
                console.error("Gemini ChatbotService Error (Standard Mode):", error);
                return "I'm currently experiencing some difficulty connecting to my core analytical systems. Please try your query again in a few moments.";
            }
        }
    }
}