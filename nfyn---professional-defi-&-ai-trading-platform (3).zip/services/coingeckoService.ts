// This service handles cryptocurrency and forex data, using the CryptoCompare API and a free Forex API.
import { LiveCoin, ChartData, HistoricalPriceData, HistoricalVolumeData, HistoricalOHLCData, TrendingCoin, TickerAsset } from '../types';
import { INITIAL_COIN_DATA } from '../constants';
import { PubliApisService } from './publiApisService'; // Import the new PubliApisService

// --- CONFIGURATION ---
const CACHE_TTL = 60 * 1000; // 1 minute cache validity
const HISTORICAL_CACHE_TTL = 45 * 60 * 1000; // 45 minutes for historical data
const FOREX_CACHE_TTL = 60 * 60 * 1000; // 60 minutes for forex
// const TRENDING_CACHE_TTL = 15 * 60 * 1000; // 15 minutes for trending - now handled by PubliApisService
const COINLIST_CACHE_TTL = 24 * 60 * 60 * 1000; // 24 hours for the master coin list

// Reintroducing direct CryptoCompare base URL and API key.
export const CRYPTOCOMPARE_BASE_URL = 'https://min-api.cryptocompare.com/data';
const CRYPTOCOMPARE_IMAGE_URL = 'https://www.cryptocompare.com';
// NOTE: In a real application, CRYPTOCOMPARE_API_KEY would be obtained securely from environment variables.
// For this simulated environment, we use a placeholder or assume it's set externally if needed.
export const CRYPTOCOMPARE_API_KEY = (process.env.CRYPTOCOMPARE_API_KEY || 'YOUR_CRYPTOCOMPARE_API_KEY') as string; 

// Reintroducing direct Open Exchange Rates base URL and API key.
// The free tier v6 of open.er-api.com for /latest/{base} usually does not require an App ID.
// If a paid tier is used, an 'app_id' parameter might be necessary.
export const OPEN_EXCHANGE_RATES_BASE_URL = 'https://open.er-api.com/v6';
// NOTE: In a real application, OPEN_EXCHANGE_RATES_API_KEY would be obtained securely from environment variables.
const OPEN_EXCHANGE_RATES_API_KEY = (process.env.OPEN_EXCHANGE_RATES_API_KEY || 'YOUR_OPEN_EXCHANGE_RATES_API_KEY') as string;

// --- ROBUST FETCHING & CACHING LAYER ---

const pendingRequests = new Map<string, Promise<any>>();

async function managedFetch<T>(
    cacheKey: string,
    fetcher: () => Promise<T>,
    ttl: number,
    fallback: () => T
): Promise<T> {
    // 1. Check local storage cache
    try {
        const cached = localStorage.getItem(cacheKey);
        if (cached) {
            const { timestamp, data } = JSON.parse(cached);
            if (Date.now() - timestamp < ttl) {
                return data as T;
            }
        }
    } catch (e) {
        console.warn(`Could not read cache for ${cacheKey}`, e);
        localStorage.removeItem(cacheKey);
    }

    // 2. Check for in-flight requests (request coalescing)
    if (pendingRequests.has(cacheKey)) {
        return pendingRequests.get(cacheKey)!;
    }

    // 3. Create and store a new request promise
    const requestPromise = (async () => {
        try {
            const data = await fetcher();
            
            // 4. Cache successful result
            try {
                localStorage.setItem(cacheKey, JSON.stringify({ timestamp: Date.now(), data }));
            } catch (e) {
                console.warn(`Could not write to cache for ${cacheKey}`, e);
            }

            return data;
        } catch (error) {
            console.error(`Managed fetch failed for ${cacheKey}:`, error);

            // 5. On failure, try to return stale cache, otherwise use fallback
            try {
                const cached = localStorage.getItem(cacheKey);
                if (cached) {
                    const { data } = JSON.parse(cached);
                    console.warn(`Returning stale data for ${cacheKey} due to fetch error.`);
                    return data as T;
                }
            } catch (e) {
                // Ignore cache read error on fallback
            }
            return fallback();
        } finally {
            // 6. Clean up from pending requests map
            pendingRequests.delete(cacheKey);
        }
    })();

    pendingRequests.set(cacheKey, requestPromise);
    return requestPromise;
}

// Reintroducing safeFetch for direct API calls
async function safeFetch(url: string, options: RequestInit & { timeout?: number } = {}): Promise<Response> {
    const { timeout = 15000 } = options;
    const controller = new AbortController();
    const id = setTimeout(() => controller.abort(), timeout);
    
    const urlObj = new URL(url);

    // Append API key if it exists and is not the placeholder
    if (url.includes('cryptocompare.com') && CRYPTOCOMPARE_API_KEY && CRYPTOCOMPARE_API_KEY !== 'YOUR_CRYPTOCOMPARE_API_KEY') {
        urlObj.searchParams.append('api_key', CRYPTOCOMPARE_API_KEY);
    }
    // For open.er-api.com/v6/latest/USD, no explicit API key parameter is typically needed for the free tier.
    // If a paid tier or setup requires an 'app_id' or similar, this logic would need adjustment.

    try {
        const response = await fetch(urlObj.toString(), { ...options, signal: controller.signal });
        clearTimeout(id);
        return response;
    } catch (error) {
        clearTimeout(id);
        if (error instanceof Error && error.name === 'AbortError') {
            throw new Error('Request timed out');
        }
        throw error;
    }
}

const safeParseJSON = async (response: Response): Promise<any> => {
    const text = await response.text();
    if (!text) {
        if (!response.ok) throw new Error(`API Error (${response.status}): Empty response`);
        return null;
    }
    
    let data;
    try {
        data = JSON.parse(text);
    } catch (e) {
        console.error("Failed to parse JSON:", text);
        throw new Error("Invalid JSON response from API.");
    }

    // Checking for CryptoCompare specific error structure
    if (data && data.Response === 'Error') {
        throw new Error(`CryptoCompare API Error: ${data.Message}`);
    }

    // Checking for Open Exchange Rates API specific error structure
    if (data && data.result === 'error') {
        throw new Error(`Forex API Error: ${data['error-type']}`);
    }

    if (!response.ok) {
        const errorMessage = data?.error ? (typeof data.error === 'object' ? JSON.stringify(data.error) : data.error) : response.statusText;
        throw new Error(`API Error (${response.status}): ${errorMessage}`);
    }

    return data;
};

// --- HELPER FUNCTIONS ---

const getCoinListMap = async (): Promise<Map<string, { symbol: string; name: string; imageUrl: string }>> => {
    // Using a new cache key to avoid conflicts with the old format which stored a Map improperly.
    const cacheKey = 'nfyn_cc_coinlist_v2';
    const fetcher = async (): Promise<[string, { symbol: string; name: string; imageUrl: string }][]> => {
        // Use safeFetch for CryptoCompare API call
        const response = await safeFetch(`${CRYPTOCOMPARE_BASE_URL}/all/coinlist`);
        const data = await safeParseJSON(response);
        const coinMap = new Map<string, { symbol: string; name: string; imageUrl: string }>();
        if (data && data.Data) {
            for (const key in data.Data) {
                const coin = data.Data[key];
                // Map by lowercase CoinName which is similar to CoinGecko's ID
                coinMap.set(coin.CoinName.toLowerCase(), {
                    symbol: coin.Symbol,
                    name: coin.CoinName,
                    imageUrl: `https://www.cryptocompare.com${coin.ImageUrl}` // Image URL still directly from CryptoCompare
                });
            }
        }
        // Return an array of entries, which is properly serializable to JSON.
        return Array.from(coinMap.entries());
    };
    
    // managedFetch now correctly caches and retrieves the array of entries.
    const coinListArray = await managedFetch(cacheKey, fetcher, COINLIST_CACHE_TTL, () => []);
    
    // Reconstruct the Map from the array of entries.
    return new Map(coinListArray);
};

const calculateRSI = (ohlcData: { close: number; time: number }[], period: number = 14): { time: number; value: number }[] => {
    if (ohlcData.length <= period) return [];
    const rsiData: { time: number; value: number }[] = [];
    let gains: number[] = [];
    let losses: number[] = [];

    for (let i = 1; i <= period; i++) {
        const change = ohlcData[i].close - ohlcData[i - 1].close;
        change > 0 ? gains.push(change) : losses.push(Math.abs(change));
    }

    let avgGain = gains.reduce((sum, val) => sum + val, 0) / period;
    let avgLoss = losses.reduce((sum, val) => sum + val, 0) / period;

    for (let i = period + 1; i < ohlcData.length; i++) {
        const change = ohlcData[i].close - ohlcData[i - 1].close;
        avgGain = (avgGain * (period - 1) + (change > 0 ? change : 0)) / period;
        avgLoss = (avgLoss * (period - 1) + (change < 0 ? Math.abs(change) : 0)) / period;
        const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
        rsiData.push({ time: ohlcData[i].time, value: 100 - (100 / (1 + rs)) });
    }
    return rsiData;
};

const getStaticFallbackData = (): LiveCoin[] => {
    return INITIAL_COIN_DATA.map(coin => ({
        ...coin,
        logoUrl: `https://www.cryptocompare.com/media/19633/btc.png`, // Generic placeholder
        sparklineData: Array.from({ length: 50 }, () => coin.price * (1 + (Math.random() - 0.5) * 0.1)),
        marketCap: 1.2e12,
        volume24h: 3.5e10,
    }));
};

// --- EXPORTED API FUNCTIONS ---

export const fetchMarketData = async (coinIds: string[]): Promise<LiveCoin[]> => {
    if (coinIds.length === 0) return [];
    
    const sortedIds = [...coinIds].sort().join(',');
    const cacheKey = `nfyn_cc_market_${sortedIds}`;

    const fetcher = async () => {
        const coinListMap = await getCoinListMap();
        const symbols = coinIds.map(id => {
            // Special handling for "the-open-network" since CoinGecko ID might be different from CryptoCompare symbol lookup
            if (id === 'the-open-network') return 'TON'; // CryptoCompare symbol for The Open Network
            return coinListMap.get(id)?.symbol;
        }).filter(Boolean);
        if (symbols.length === 0) return [];
        
        // Use safeFetch for CryptoCompare API call
        const response = await safeFetch(`${CRYPTOCOMPARE_BASE_URL}/pricemultifull?fsyms=${symbols.join(',')}&tsyms=USD`);
        const data = await safeParseJSON(response);

        if (!data || !data.RAW) {
            throw new Error("Invalid data format received for market data.");
        }
        
        const liveCoins: LiveCoin[] = [];
        for(const id of coinIds) {
            let coinInfo = coinListMap.get(id);
            let symbol = coinInfo?.symbol;

            if (id === 'the-open-network') {
                symbol = 'TON';
                // Manually create coinInfo for TON if not found by generic ID mapping, using common name
                if (!coinInfo) {
                    coinInfo = { symbol: 'TON', name: 'The Open Network', imageUrl: 'https://s2.coinmarketcap.com/static/img/coins/64x64/10940.png' }; // Placeholder image
                }
            }
            
            if (!coinInfo || !symbol) continue; // Skip if coinInfo or symbol is still missing after checks

            const rawData = data.RAW[symbol]?.USD;
            if (!rawData) continue;
            
            liveCoins.push({
                id: id,
                symbol: symbol,
                name: coinInfo.name,
                price: rawData.PRICE ?? 0,
                change24h: rawData.CHANGEPCT24HOUR ?? 0,
                logoUrl: coinInfo.imageUrl,
                // Placeholder sparkline, as CryptoCompare doesn't provide this in the same call
                sparklineData: Array.from({ length: 50 }, () => (rawData.PRICE ?? 0) * (1 + (Math.random() - 0.5) * 0.05)),
                marketCap: rawData.MKTCAP,
                volume24h: rawData.TOTALVOLUME24HTO,
            });
        }
        return liveCoins;
    };

    return managedFetch<LiveCoin[]>(cacheKey, fetcher, CACHE_TTL, getStaticFallbackData);
};

export const fetchForexDataForTicker = async (pairs: string[]): Promise<TickerAsset[]> => {
    const staticForexFallback = [
        { symbol: 'EUR/USD', price: 1.08, change: 0.12 },
        { symbol: 'GBP/USD', price: 1.25, change: -0.25 },
        { symbol: 'USD/JPY', price: 155.7, change: 0.5 },
    ];
    if (pairs.length === 0) return [];

    const cacheKey = `nfyn_forex_data_v2`;

    const fetcher = async () => {
        // Use safeFetch for Open Exchange Rates API call
        // For the free tier (v6), no 'app_id' is needed in the URL for /latest/{base}.
        const response = await safeFetch(`${OPEN_EXCHANGE_RATES_BASE_URL}/latest/USD`);
        const data = await safeParseJSON(response);

        if (!data || data.result !== 'success' || !data.rates) {
            throw new Error('Invalid Forex API response format.');
        }

        return pairs.map(pair => {
            const [base, quote] = pair.split('/');
            let rate: number | null = null;
            // The API returns rates relative to the base currency (USD in this case).
            // So if `base` is USD, `rate` is `rates[quote]`.
            // If `quote` is USD, `rate` is `1 / rates[base]`.
            // If neither is USD, it's more complex (e.g., EUR/JPY = (EUR/USD) / (JPY/USD)).
            // For simplicity, we'll only handle direct USD pairs as shown in the original mock.
            if (base === 'USD' && data.rates[quote]) {
                rate = data.rates[quote];
            } else if (quote === 'USD' && data.rates[base]) {
                rate = 1 / data.rates[base];
            } else if (data.rates[base] && data.rates[quote]) {
                 // Cross-currency pair (e.g., EUR/JPY) where USD is the base for both from the API.
                 rate = data.rates[quote] / data.rates[base];
            }

            // Simulate change as the actual API does not provide 24h change.
            const change = rate !== null ? (Math.random() - 0.5) * 1 : null;
            return { symbol: pair, price: rate, change: change };
        });
    };

    return managedFetch<TickerAsset[]>(cacheKey, fetcher, FOREX_CACHE_TTL, () => staticForexFallback);
};

export const fetchHistoricalData = async (coinId: string, duration: number | '1H' | '1D' | '1W' | '1M'): Promise<ChartData | null> => {
    const cacheKey = `nfyn_cc_historical_v3_${coinId}_${duration}`;

    const fetcher = async () => {
        const coinListMap = await getCoinListMap();
        let symbol = coinListMap.get(coinId)?.symbol;
        if (coinId === 'the-open-network') symbol = 'TON'; // Specific symbol for TON

        if (!symbol) throw new Error(`Could not find symbol for coinId: ${coinId}`);
        
        let endpoint = 'histoday';
        let limit = 30; // default

        if (typeof duration === 'number') {
            limit = duration;
        } else {
            type Timeframe = typeof duration;
            const timeframeMap: Record<Timeframe, { endpoint: string, limit: number }> = {
                '1H': { endpoint: 'histominute', limit: 60 },
                '1D': { endpoint: 'histohour', limit: 24 },
                '1W': { endpoint: 'histoday', limit: 7 },
                '1M': { endpoint: 'histoday', limit: 30 },
            };
            endpoint = timeframeMap[duration].endpoint;
            limit = timeframeMap[duration].limit;
        }

        // Use safeFetch for CryptoCompare API call
        const response = await safeFetch(`${CRYPTOCOMPARE_BASE_URL}/v2/${endpoint}?fsym=${symbol}&tsym=USD&limit=${limit}`);
        const data = await safeParseJSON(response);

        if (!data || data.Response !== 'Success' || !data.Data?.Data) {
            throw new Error("Invalid historical data format from API.");
        }
        const historical = data.Data.Data;

        const priceData: HistoricalPriceData[] = historical.map((d: any) => ({ time: d.time, value: d.close }));
        let lastPrice = 0;
        const volumeData: HistoricalVolumeData[] = historical.map((d: any) => {
            const color = d.close >= lastPrice ? 'rgba(140, 255, 0, 0.5)' : 'rgba(239, 68, 68, 0.5)';
            lastPrice = d.close;
            return { time: d.time, value: d.volumeto, color };
        });
        const ohlcData: HistoricalOHLCData[] = historical.map((d: any) => ({ time: d.time, open: d.open, high: d.high, low: d.low, close: d.close }));
        const rsiData = calculateRSI(ohlcData);

        return { priceData, volumeData, ohlcData, rsiData };
    };
    
    return managedFetch<ChartData | null>(cacheKey, fetcher, HISTORICAL_CACHE_TTL, () => null);
};

export const fetchTrendingCoins = async (): Promise<TrendingCoin[]> => {
    // Delegate to PubliApisService for trending coins
    return PubliApisService.getTrendingCoins();
};