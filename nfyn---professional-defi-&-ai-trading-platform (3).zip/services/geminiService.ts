import { GoogleGenAI, Type } from "@google/genai";
import { ScalpingRiskProfile, SentimentData, HistoricalOHLCData, TrendAnalysisResult, FuturesFundingAnalysis, YieldFarmingOpportunity, LpRecommendation, NewTokenLaunch, AITokenAnalysisResult, AIPortfolioAnalysis, ModuleState } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });


// --- Caching Utility ---
const CACHE_PREFIX = 'nfyn_gemini_cache_v2_';
// Increased cache TTLs to reduce API calls and avoid rate limiting.
const CACHE_TTL = {
    SHORT: 20 * 60 * 1000,  // 20 minutes
    DEFAULT: 45 * 60 * 1000, // 45 minutes
    LONG: 120 * 60 * 1000,  // 2 hours
    VERY_LONG: 6 * 60 * 60 * 1000, // 6 hours for less volatile data
    TOKEN_ANALYSIS: 24 * 60 * 60 * 1000, // 24 hours for token analysis, as it's less frequent
};

interface CacheEntry<T> {
    timestamp: number;
    data: T;
}

async function cachedApiCall<T>(
    cacheKey: string,
    apiCall: () => Promise<T>,
    ttl: number = CACHE_TTL.DEFAULT
): Promise<T> {
    const fullCacheKey = `${CACHE_PREFIX}${cacheKey}`;
    try {
        const cachedItem = localStorage.getItem(fullCacheKey);
        if (cachedItem) {
            const entry = JSON.parse(cachedItem) as CacheEntry<T>;
            if (Date.now() - entry.timestamp < ttl) {
                return entry.data;
            }
        }
    } catch (error) {
        console.warn(`Gemini Cache: Could not read cache for key ${fullCacheKey}`, error);
        localStorage.removeItem(fullCacheKey); // Clear corrupted cache
    }

    const data = await apiCall();

    try {
        // A simple check to avoid caching error responses.
        const isErrorResponse = JSON.stringify(data).includes("gemini.error");
        if (!isErrorResponse) {
            const entry: CacheEntry<T> = { timestamp: Date.now(), data };
            localStorage.setItem(fullCacheKey, JSON.stringify(entry));
        }
    } catch (error) {
        console.warn(`Gemini Cache: Could not write to cache for key ${fullCacheKey}`, error);
    }

    return data;
}


export interface PriceDataPoint {
    period: string;
    price: number;
}

export class GeminiService {
    /**
     * Summarizes a news article using the Gemini API.
     * @param articleContent - The content or title of the news article.
     * @returns A promise that resolves to a summarized string.
     */
    static async summarizeNews(articleContent: string): Promise<string> {
        const cacheKey = `summary_${articleContent.substring(0, 50)}`;
        return cachedApiCall(cacheKey, async () => {
            try {
                const response = await ai.models.generateContent({
                    model: 'gemini-2.5-flash',
                    contents: `Summarize this news headline in one concise sentence for a crypto trader: "${articleContent}"`,
                });
                return response.text;
            } catch (error) {
                console.error("Gemini API error during summarization:", error);
                return "gemini.error.summary";
            }
        }, CACHE_TTL.LONG);
    }

    /**
     * Generates summaries for a batch of news headlines.
     * @param articles - An array of objects with article id and title.
     * @returns A promise that resolves to an object mapping article IDs to their summary.
     */
    static async getBulkSummaries(articles: { id: string, title: string }[]): Promise<Record<string, string>> {
        if (articles.length === 0) {
            return {};
        }
        const cacheKey = `bulk_summaries_v2_${articles.map(a => a.id).join('_')}`;
        
        return cachedApiCall(cacheKey, async () => {
            const articlesToProcess = JSON.stringify(articles);
            try {
                const response = await ai.models.generateContent({
                    model: 'gemini-2.5-flash',
                    contents: `For each news article object in this JSON array, provide a one-sentence summary for a crypto trader. Articles: ${articlesToProcess}. Return a single JSON array of objects, where each object contains the original 'id' and a new 'summary' field.`,
                    config: {
                        responseMimeType: "application/json",
                        responseSchema: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    id: { type: Type.STRING },
                                    summary: { type: Type.STRING }
                                },
                                required: ["id", "summary"]
                            }
                        }
                    }
                });

                const jsonStr = response.text.trim();
                const summariesArray: { id: string, summary: string }[] = JSON.parse(jsonStr);

                const results: Record<string, string> = {};
                summariesArray.forEach(item => {
                    results[item.id] = item.summary;
                });

                articles.forEach(article => {
                    if (!results[article.id]) {
                        results[article.id] = "gemini.error.summary";
                    }
                });

                return results;
            } catch (error) {
                console.error("Gemini API error during bulk summary generation:", error);
                const fallback: Record<string, string> = {};
                articles.forEach(({ id }) => {
                    fallback[id] = "gemini.error.summary";
                });
                return fallback;
            }
        }, CACHE_TTL.LONG);
    }

    /**
     * Analyzes sentiment for a batch of news headlines.
     * @param articles - An array of objects with article id and title.
     * @returns A promise that resolves to an object mapping article IDs to sentiment data.
     */
    static async getBulkSentimentAnalysis(articles: { id: string, title: string }[]): Promise<Record<string, SentimentData>> {
        if (articles.length === 0) {
            return {};
        }
        const cacheKey = `bulk_sentiment_${articles.map(a => a.id).join('_')}`;
        
        return cachedApiCall(cacheKey, async () => {
            const articleInputString = JSON.stringify(articles.map(a => ({ id: a.id, title: a.title })));
            const fallbackResult: Record<string, SentimentData> = {};
            articles.forEach(({ id }) => {
                fallbackResult[id] = {
                    classification: "Neutral",
                    confidenceScores: { bullish: 0, bearish: 0, neutral: 1 },
                };
            });

            try {
                const response = await ai.models.generateContent({
                    model: 'gemini-2.5-flash',
                    contents: `Analyze the sentiment for each news headline in this JSON array: ${articleInputString}. Return a single JSON array of objects. Each object must correspond to an article and contain: "id" (the original article ID), "classification" ("Bullish", "Bearish", or "Neutral"), and a "sentiment" object with "bullish", "bearish", and "neutral" confidence scores (numbers 0.0-1.0).`,
                    config: {
                        responseMimeType: "application/json",
                        responseSchema: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    id: { type: Type.STRING },
                                    classification: { type: Type.STRING, enum: ["Bullish", "Bearish", "Neutral"] },
                                    sentiment: {
                                        type: Type.OBJECT,
                                        properties: {
                                            bullish: { type: Type.NUMBER },
                                            bearish: { type: Type.NUMBER },
                                            neutral: { type: Type.NUMBER }
                                        },
                                        required: ["bullish", "bearish", "neutral"]
                                    }
                                },
                                required: ["id", "classification", "sentiment"]
                            }
                        }
                    },
                });

                const jsonStr = response.text.trim();
                 const sentimentArray: { 
                    id: string; 
                    classification: 'Bullish' | 'Bearish' | 'Neutral';
                    sentiment: { bullish: number; bearish: number; neutral: number; };
                }[] = JSON.parse(jsonStr);

                const results: Record<string, SentimentData> = {};
                sentimentArray.forEach(item => {
                    if (item && item.id && item.classification && item.sentiment) {
                         results[item.id] = {
                            classification: item.classification,
                            confidenceScores: item.sentiment
                        };
                    }
                });
                
                // Ensure all original articles have an entry, even if the AI missed one
                articles.forEach(article => {
                    if (!results[article.id]) {
                       results[article.id] = fallbackResult[article.id];
                    }
                });

                return results;

            } catch (error) {
                console.error("Gemini API error during bulk sentiment analysis:", error);
                return fallbackResult;
            }
        }, CACHE_TTL.DEFAULT);
    }

    /**
     * Answers a follow-up question about a news article.
     * @param articleTitle - The title of the news article for context.
     * @param question - The user's follow-up question.
     * @returns A promise that resolves to an answer string.
     */
    static async askFollowUp(articleTitle: string, question: string): Promise<string> {
        const cacheKey = `followup_${articleTitle.substring(0, 50)}_${question.substring(0, 50)}`;
        return cachedApiCall(cacheKey, async () => {
            try {
                const response = await ai.models.generateContent({
                    model: 'gemini-2.5-flash',
                    contents: `Regarding the news headline "${articleTitle}", answer this follow-up question concisely for a crypto trader: "${question}"`,
                });
                return response.text;
            } catch (error) {
                console.error("Gemini API error during follow-up question:", error);
                return "gemini.error.followUp";
            }
        }, CACHE_TTL.LONG);
    }

    /**
     * Generates a full news article from a headline.
     * @param articleTitle The headline of the news.
     * @returns A promise resolving to the full article content as a string.
     */
    static async generateFullArticle(articleTitle: string): Promise<string> {
         const cacheKey = `article_${articleTitle.substring(0, 50)}`;
        return cachedApiCall(cacheKey, async () => {
            try {
                const response = await ai.models.generateContent({
                    model: 'gemini-2.5-flash',
                    contents: `Act as a financial journalist for a top-tier crypto news outlet like CoinDesk. Write a short news article (3-4 paragraphs) based on the headline: "${articleTitle}". The article should be informative, objective, and provide context and potential market implications for a savvy crypto trader. Use a professional tone.`,
                });
                return response.text;
            } catch (error) {
                console.error("Gemini API error during article generation:", error);
                return "gemini.error.articleGeneration";
            }
        }, CACHE_TTL.LONG);
    }

    /**
     * Generates a summary of the current crypto market conditions.
     * @returns A promise resolving to the market summary as a string.
     */
    static async getMarketSummary(): Promise<string> {
        const cacheKey = 'market_summary';
        return cachedApiCall(cacheKey, async () => {
            try {
                const response = await ai.models.generateContent({
                    model: 'gemini-2.5-flash',
                    contents: "Act as a senior crypto market analyst. Provide a brief, one-paragraph summary of the current cryptocurrency market conditions. Mention the general trend (bullish, bearish, consolidating), key drivers (e.g., news, macroeconomic factors), and notable performing sectors or assets. Keep it concise and easy for a trader to digest quickly.",
                });
                return response.text;
            } catch (error) {
                console.error("Gemini API error during market summary generation:", error);
                return "The cryptocurrency market is currently experiencing a period of consolidation. Bitcoin is holding steady around key support levels, while Ethereum shows potential for a breakout. Altcoin sentiment is mixed, with DeFi and AI-related tokens showing notable strength. Traders are advised to monitor macroeconomic news for potential volatility.";
            }
        }, CACHE_TTL.SHORT);
    }

    /**
     * Generates a price prediction for a cryptocurrency based on historical data.
     * @param coinSymbol - The symbol of the coin (e.g., 'BTC').
     * @param historicalData - An array of past price points.
     * @returns A promise resolving to an object with predictions and a summary.
     */
    static async getPricePrediction(coinSymbol: string, historicalData: PriceDataPoint[]): Promise<{ predictions: PriceDataPoint[], summary: string }> {
        const cacheKey = `prediction_${coinSymbol}`;
        return cachedApiCall(cacheKey, async () => {
            try {
                const historicalDataString = historicalData.map(d => `${d.period}: $${d.price}`).join(', ');

                const response = await ai.models.generateContent({
                    model: 'gemini-2.5-flash',
                    contents: `Based on the following recent historical price data for ${coinSymbol} (${historicalDataString}), predict the price for the next 3 periods (e.g., "1d after", "2d after"). Also, provide a brief one-sentence summary of your prediction.`,
                    config: {
                        responseMimeType: "application/json",
                        responseSchema: {
                            type: Type.OBJECT,
                            properties: {
                                predictions: {
                                    type: Type.ARRAY,
                                    description: "An array of predicted price points for the next 3 periods.",
                                    items: {
                                        type: Type.OBJECT,
                                        properties: {
                                            period: { type: Type.STRING, description: "The future period (e.g., '1d after')." },
                                            price: { type: Type.NUMBER, description: "The predicted price." }
                                        },
                                        required: ["period", "price"]
                                    }
                                },
                                summary: {
                                    type: Type.STRING,
                                    description: "A brief, one-sentence summary of the price prediction."
                                }
                            },
                            required: ["predictions", "summary"]
                        }
                    }
                });

                const jsonStr = response.text.trim();
                const json = JSON.parse(jsonStr);
                return json;

            } catch (error) {
                console.error(`Gemini API error during price prediction for ${coinSymbol}:`, error);
                const lastPrice = historicalData.length > 0 ? historicalData[historicalData.length - 1].price : 50000;
                return { 
                    predictions: [
                        { period: '+1d', price: lastPrice * (1 + (Math.random() - 0.4) * 0.05) },
                        { period: '+2d', price: lastPrice * (1 + (Math.random() - 0.4) * 0.06) },
                        { period: '+3d', price: lastPrice * (1 + (Math.random() - 0.4) * 0.07) },
                    ], 
                    summary: "AI analysis is temporarily unavailable. Based on historical trends, the asset shows potential for slight upward movement with expected volatility." 
                };
            }
        }, CACHE_TTL.DEFAULT);
    }

    /**
     * Recommends a scalping bot risk profile based on a market summary.
     * @param marketSummary - A summary of current market conditions.
     * @returns A promise resolving to an object with a recommendation and reasoning.
     */
    static async getBotRiskProfileSuggestion(marketSummary: string): Promise<{ recommendation: ScalpingRiskProfile; reasoning: string; }> {
        // This is a user-initiated action, so we don't cache it to ensure a fresh analysis.
        try {
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: `As a crypto trading strategist, analyze the following market summary and recommend a risk profile for an automated scalping bot. The options are "Conservative", "Moderate", or "Aggressive". Provide a brief justification for your choice. Market Summary: "${marketSummary}"`,
                config: {
                    responseMimeType: "application/json",
                    responseSchema: {
                        type: Type.OBJECT,
                        properties: {
                            recommendation: {
                                type: Type.STRING,
                                enum: ["Conservative", "Moderate", "Aggressive"],
                                description: "The recommended risk profile for the scalping bot.",
                            },
                            reasoning: {
                                type: Type.STRING,
                                description: "A brief justification for the recommended risk profile.",
                            }
                        },
                        required: ["recommendation", "reasoning"]
                    }
                }
            });

            const jsonStr = response.text.trim();
            const json = JSON.parse(jsonStr);
            const recommendation = json.recommendation as ScalpingRiskProfile;

            if (!["Conservative", "Moderate", "Aggressive"].includes(recommendation)) {
                throw new Error("Invalid risk profile received from API");
            }
            
            return {
                recommendation,
                reasoning: json.reasoning,
            };
        } catch (error) {
            console.error("Gemini API error during risk profile suggestion:", error);
            return {
                recommendation: 'Moderate',
                reasoning: "AI analysis is currently unavailable. A 'Moderate' profile is suggested as a balanced default. Please assess market conditions manually before activating."
            };
        }
    }

    /**
     * Analyzes overall market sentiment from news headlines.
     * @param newsHeadlines - An array of recent news headlines.
     * @returns A promise resolving to an object with a sentiment score (0-100) and a summary.
     */
    static async getOverallMarketSentiment(newsHeadlines: string[]): Promise<{ sentimentValue: number; summary: string }> {
        const cacheKey = 'overall_sentiment';
        return cachedApiCall(cacheKey, async () => {
            try {
                const headlinesString = newsHeadlines.join('; ');
                const response = await ai.models.generateContent({
                    model: 'gemini-2.5-flash',
                    contents: `Analyze the overall crypto market sentiment based on these recent headlines: "${headlinesString}". 
                    1. Provide a sentiment score from 0 (Extreme Fear) to 100 (Extreme Greed).
                    2. Write a short, 2-3 sentence summary explaining the current market mood and key drivers.`,
                    config: {
                        responseMimeType: "application/json",
                        responseSchema: {
                            type: Type.OBJECT,
                            properties: {
                                sentimentValue: {
                                    type: Type.NUMBER,
                                    description: "A number between 0 and 100 representing market sentiment."
                                },
                                summary: {
                                    type: Type.STRING,
                                    description: "A short summary of the market mood."
                                }
                            },
                            required: ["sentimentValue", "summary"]
                        }
                    }
                });
                const jsonStr = response.text.trim();
                const json = JSON.parse(jsonStr);
                return {
                    sentimentValue: json.sentimentValue,
                    summary: json.summary
                };
            } catch (error) {
                console.error("Gemini API error during overall sentiment analysis:", error);
                return {
                    sentimentValue: 50 + (Math.random() - 0.5) * 10,
                    summary: "AI sentiment analysis is temporarily unavailable due to high demand. The overall market mood appears neutral, awaiting clearer signals from major assets and regulatory news."
                };
            }
        }, CACHE_TTL.SHORT);
    }
    
    /**
     * Generates an AI-driven analysis of the user's portfolio.
     * @param portfolioData - Object containing user's portfolio metrics.
     * @returns A promise resolving to an AIPortfolioAnalysis object.
     */
    static async getAIPortfolioAnalysis(portfolioData: { totalCapital: number; totalPnl: number; initialCapital: number; modules: ModuleState[] }): Promise<AIPortfolioAnalysis> {
        const cacheKey = `portfolio_analysis_${portfolioData.totalCapital.toFixed(0)}`;
        return cachedApiCall(cacheKey, async () => {
            const simplifiedModules = portfolioData.modules.map(m => ({ name: m.name, capital: m.capital, pnl: m.pnl }));
            const prompt = `Act as a senior portfolio analyst for a DeFi trading platform. Analyze the following user portfolio and provide insights.
            Portfolio Data:
            - Total Capital: $${portfolioData.totalCapital.toFixed(2)}
            - Total P&L: $${portfolioData.totalPnl.toFixed(2)}
            - Initial Capital: $${portfolioData.initialCapital.toFixed(2)}
            - Strategy Allocation: ${JSON.stringify(simplifiedModules)}

            Based on this data, provide:
            1. A 'riskScore' from 0 (very safe) to 100 (very risky).
            2. A 'riskLevel' classification ('Low', 'Medium', 'High').
            3. A single, actionable 'recommendation' as the key takeaway.
            4. A brief, 2-3 sentence 'analysis' explaining the current state and why you gave the recommendation.
            
            Return this as a JSON object.`;

            try {
                const response = await ai.models.generateContent({
                    model: 'gemini-2.5-pro',
                    contents: prompt,
                    config: {
                        responseMimeType: "application/json",
                        responseSchema: {
                            type: Type.OBJECT,
                            properties: {
                                riskScore: { type: Type.NUMBER },
                                riskLevel: { type: Type.STRING, enum: ["Low", "Medium", "High"] },
                                recommendation: { type: Type.STRING },
                                analysis: { type: Type.STRING }
                            },
                            required: ["riskScore", "riskLevel", "recommendation", "analysis"]
                        }
                    }
                });
                const jsonStr = response.text.trim();
                return JSON.parse(jsonStr) as AIPortfolioAnalysis;
            } catch (error) {
                console.error("Gemini API error during portfolio analysis:", error);
                return {
                    riskScore: 55,
                    riskLevel: 'Medium',
                    recommendation: 'Consider rebalancing capital towards top-performing strategies.',
                    analysis: 'AI analysis is temporarily unavailable. Your portfolio shows moderate growth. Diversification across active strategies appears balanced. Continue monitoring performance and market conditions.'
                };
            }
        }, CACHE_TTL.SHORT);
    }

    /**
     * Analyzes market trends for a given asset based on historical OHLC data, RSI, and MACD (simulated).
     * @param coinSymbol - The symbol of the coin (e.g., 'BTC').
     * @param historicalOHLCData - Array of historical OHLC data.
     * @returns A promise resolving to a TrendAnalysisResult.
     */
    static async analyzeMarketTrends(coinSymbol: string, historicalOHLCData: HistoricalOHLCData[]): Promise<TrendAnalysisResult> {
        const cacheKey = `trend_analysis_${coinSymbol}`;
        return cachedApiCall(cacheKey, async () => {
            try {
                const ohlcString = JSON.stringify(historicalOHLCData.slice(-50)); // Last 50 data points
                const response = await ai.models.generateContent({
                    model: 'gemini-2.5-flash',
                    contents: `As an expert crypto technical analyst, analyze the market trends for ${coinSymbol} based on the following historical OHLC data (Open, High, Low, Close) from the last 50 periods: ${ohlcString}. Identify the current direction (Bullish, Bearish, or Neutral), suggest optimal entry and exit points, and provide a confidence score (0-100) with brief reasoning based on patterns like moving averages, RSI, and volume. Return a JSON object.`,
                    config: {
                        responseMimeType: "application/json",
                        responseSchema: {
                            type: Type.OBJECT,
                            properties: {
                                direction: { type: Type.STRING, enum: ["Bullish", "Bearish", "Neutral"] },
                                entrySuggestion: { type: Type.STRING },
                                exitSuggestion: { type: Type.STRING },
                                confidence: { type: Type.NUMBER },
                                reasoning: { type: Type.STRING },
                            },
                            required: ["direction", "entrySuggestion", "exitSuggestion", "confidence", "reasoning"]
                        }
                    },
                });
                const jsonStr = response.text.trim();
                const result = JSON.parse(jsonStr) as TrendAnalysisResult;
                return result;
            } catch (error) {
                console.error(`Gemini API error during trend analysis for ${coinSymbol}:`, error);
                return {
                    direction: 'Neutral',
                    entrySuggestion: "AI analysis unavailable.",
                    exitSuggestion: "AI analysis unavailable.",
                    confidence: 0,
                    reasoning: "Failed to perform market trend analysis due to API error. Manual review recommended."
                };
            }
        }, CACHE_TTL.DEFAULT);
    }

    /**
     * Analyzes futures funding rates for a given asset.
     * @param asset - The asset symbol (e.g., 'BTC').
     * @returns A promise resolving to FuturesFundingAnalysis.
     */
    static async analyzeFuturesFundingRates(asset: string): Promise<FuturesFundingAnalysis> {
        const cacheKey = `futures_funding_${asset}`;
        return cachedApiCall(cacheKey, async () => {
            try {
                // Simulate funding rates and open interest data for Gemini
                const mockFundingRate = (Math.random() * 0.01 - 0.005).toFixed(4); // e.g., -0.0050 to 0.0050
                const mockOpenInterest = Math.floor(Math.random() * 500000) + 100000; // 100k to 600k USD
                const response = await ai.models.generateContent({
                    model: 'gemini-2.5-flash',
                    contents: `As an expert in crypto futures, analyze the current market conditions for ${asset}. Consider a hypothetical funding rate of ${mockFundingRate}% and open interest of $${mockOpenInterest.toLocaleString()}. Based on this, predict whether the market has a 'LongBias', 'ShortBias', or is 'Neutral' due to funding pressures. Provide a brief reasoning and suggest an optimal leverage factor (integer between 1-100). Return a JSON object.`,
                    config: {
                        responseMimeType: "application/json",
                        responseSchema: {
                            type: Type.OBJECT,
                            properties: {
                                prediction: { type: Type.STRING, enum: ["LongBias", "ShortBias", "Neutral"] },
                                reasoning: { type: Type.STRING },
                                optimalLeverage: { type: Type.NUMBER },
                            },
                            required: ["prediction", "reasoning", "optimalLeverage"]
                        }
                    },
                });
                const jsonStr = response.text.trim();
                const result = JSON.parse(jsonStr) as FuturesFundingAnalysis;
                return result;
            } catch (error) {
                console.error(`Gemini API error during futures funding analysis for ${asset}:`, error);
                return {
                    prediction: 'Neutral',
                    reasoning: "Failed to analyze futures funding rates due to API error. Exercise caution.",
                    optimalLeverage: 10, // Default to a moderate leverage
                };
            }
        }, CACHE_TTL.LONG);
    }

    /**
     * Finds yield farming opportunities based on a market summary.
     * @param currentMarketSummary - A general summary of the current crypto market.
     * @returns A promise resolving to an array of YieldFarmingOpportunity.
     */
    static async findYieldFarmingOpportunities(currentMarketSummary: string, minApyThreshold: number = 10): Promise<YieldFarmingOpportunity[]> {
        const cacheKey = `farming_opportunities_${minApyThreshold}`;
        return cachedApiCall(cacheKey, async () => {
            try {
                const response = await ai.models.generateContent({
                    model: 'gemini-2.5-flash',
                    contents: `As a DeFi expert, identify 3-5 high-quality yield farming opportunities (pools, protocols) with an APY above ${minApyThreshold}% based on the current market summary: "${currentMarketSummary}". For each opportunity, specify the 'protocol', 'pair', estimated 'apy', 'risk' (Low, Medium, High), and a brief 'reasoning' why it's a good pick. Return a JSON array of objects.`,
                    config: {
                        responseMimeType: "application/json",
                        responseSchema: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    protocol: { type: Type.STRING },
                                    pair: { type: Type.STRING },
                                    apy: { type: Type.NUMBER },
                                    risk: { type: Type.STRING, enum: ["Low", "Medium", "High"] },
                                    reasoning: { type: Type.STRING },
                                },
                                required: ["protocol", "pair", "apy", "risk", "reasoning"]
                            }
                        }
                    },
                });
                const jsonStr = response.text.trim();
                const result = JSON.parse(jsonStr) as YieldFarmingOpportunity[];
                return result;
            } catch (error) {
                console.error("Gemini API error during yield farming analysis:", error);
                return [
                    { protocol: "MockFarm", pair: "ETH-USDT", apy: 15.2, risk: "Medium", reasoning: "Simulated good returns due to stable pair." },
                    { protocol: "MockSwap", pair: "BTC-DAI", apy: 12.8, risk: "Low", reasoning: "Decent APY on a less volatile pair, good for beginners." },
                ];
            }
        }, CACHE_TTL.VERY_LONG);
    }

    /**
     * Optimizes concentrated LP ranges for a given pair.
     * @param pair - The trading pair (e.g., 'ETH/USDT').
     * @param currentPrice - The current price of the base asset in the pair.
     * @param currentVolatility - A hypothetical volatility measure (e.g., 0.05 for 5%).
     * @param rangeTolerance - User-defined tolerance for price fluctuations.
     * @returns A promise resolving to LpRecommendation.
     */
    static async optimizeLPPool(pair: string, currentPrice: number, currentVolatility: number, rangeTolerance: number): Promise<LpRecommendation> {
        const cacheKey = `lp_optimization_${pair}_${currentPrice}_${currentVolatility}_${rangeTolerance}`;
        return cachedApiCall(cacheKey, async () => {
            try {
                const response = await ai.models.generateContent({
                    model: 'gemini-2.5-flash',
                    contents: `As an expert in concentrated liquidity pools (e.g., Uniswap V3), recommend optimal price ranges for providing liquidity for the ${pair} pair. The current price is $${currentPrice}, and current market volatility is approximately ${currentVolatility * 100}%. The user's preferred range tolerance is ${rangeTolerance}%. Suggest a 'minPrice', 'maxPrice', a 'feeTier' ('0.05%', '0.3%', or '1%'), and provide a 'reasoning' for your recommendation, considering factors like expected impermanent loss and fee generation. Return a JSON object.`,
                    config: {
                        responseMimeType: "application/json",
                        responseSchema: {
                            type: Type.OBJECT,
                            properties: {
                                minPrice: { type: Type.NUMBER },
                                maxPrice: { type: Type.NUMBER },
                                reasoning: { type: Type.STRING },
                                feeTier: { type: Type.STRING, enum: ["0.05%", "0.3%", "1%"] },
                            },
                            required: ["minPrice", "maxPrice", "reasoning", "feeTier"]
                        }
                    },
                });
                const jsonStr = response.text.trim();
                const result = JSON.parse(jsonStr) as LpRecommendation;
                return result;
            } catch (error) {
                console.error(`Gemini API error during LP optimization for ${pair}:`, error);
                const defaultMin = currentPrice * (1 - rangeTolerance / 100 * 1.5); // Fallback range
                const defaultMax = currentPrice * (1 + rangeTolerance / 100 * 1.5);
                return {
                    minPrice: defaultMin,
                    maxPrice: defaultMax,
                    reasoning: "Failed to optimize LP range due to API error. A conservative default range is provided. Manual adjustment recommended.",
                    feeTier: '0.3%',
                };
            }
        }, CACHE_TTL.VERY_LONG);
    }

    /**
     * Analyzes a batch of new token launches for safety and potential.
     * @param tokens - The NewTokenLaunch objects to analyze.
     * @returns A promise resolving to a record mapping token ID to its AITokenAnalysisResult.
     */
    static async getBulkTokenAnalysis(tokens: NewTokenLaunch[]): Promise<Record<string, AITokenAnalysisResult>> {
        if (tokens.length === 0) {
            return {};
        }
        const cacheKey = `bulk_token_analysis_${tokens.map(t => t.id).join('_')}`;
        
        return cachedApiCall(cacheKey, async () => {
            const tokenDetails = JSON.stringify(tokens.map(token => ({
                id: token.id,
                name: token.name,
                symbol: token.symbol,
                network: token.network,
                marketCap: token.marketCap,
                liquidity: token.liquidity,
                volume24h: token.volume24h,
                hasAudit: token.hasAudit,
                description: token.description,
                launchAgeHours: (Date.now() - token.launchDate) / (1000 * 60 * 60),
            })));

            const prompt = `As an expert in decentralized finance and crypto security, analyze each new token launch in this JSON array: ${tokenDetails}.
            Provide a 'safety' rating (Very Low, Low, Medium, High, Very High) based on factors like audits, liquidity, and age.
            Provide a 'potential' rating (Very Low, Low, Medium, High, Very High) based on factors like market cap, volume, and narrative.
            Give a brief 'reasoning' for both. 
            Return a single JSON array of objects. Each object must contain the original 'id', 'safety', 'potential', and 'reasoning'.`;

            const fallbackResult: Record<string, AITokenAnalysisResult> = {};
            tokens.forEach(token => {
                fallbackResult[token.id] = {
                    safety: 'Medium',
                    potential: 'Medium',
                    reasoning: "AI analysis unavailable. Proceed with caution and conduct your own research."
                };
            });
            
            try {
                const response = await ai.models.generateContent({
                    model: 'gemini-2.5-flash',
                    contents: prompt,
                    config: {
                        responseMimeType: "application/json",
                        responseSchema: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    id: { type: Type.STRING },
                                    safety: { type: Type.STRING, enum: ["Very Low", "Low", "Medium", "High", "Very High"] },
                                    potential: { type: Type.STRING, enum: ["Very Low", "Low", "Medium", "High", "Very High"] },
                                    reasoning: { type: Type.STRING },
                                },
                                required: ["id", "safety", "potential", "reasoning"]
                            }
                        }
                    },
                });
                const jsonStr = response.text.trim();
                const analysisArray: (AITokenAnalysisResult & { id: string })[] = JSON.parse(jsonStr);

                const results: Record<string, AITokenAnalysisResult> = {};
                analysisArray.forEach(item => {
                    results[item.id] = {
                        safety: item.safety,
                        potential: item.potential,
                        reasoning: item.reasoning,
                    };
                });
                
                // Ensure all original tokens have an entry, even if the AI missed one
                tokens.forEach(token => {
                    if (!results[token.id]) {
                        results[token.id] = fallbackResult[token.id];
                    }
                });
                
                return results;
            } catch (error) {
                console.error("Gemini API error during bulk token analysis:", error);
                return fallbackResult;
            }
        }, CACHE_TTL.TOKEN_ANALYSIS);
    }
}