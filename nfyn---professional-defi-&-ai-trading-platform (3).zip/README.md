# NFYN Backend & Worker - Phase 1

This repository contains the foundational backend and worker services for the NFYN (Next Financial Yield Network) platform. This initial phase focuses on user authentication via wallet connection, a persistent sandbox environment, and a scalable architecture for future development.

## ✨ Features

-   **Idempotent Wallet Connect**: Safely create or retrieve user profiles via a Solana wallet address.
-   **Persistent Sandbox Environment**: Every user gets a `sandbox_balance` for simulated trading, stored securely in the database.
-   **Non-Destructive by Design**: The API and migration scripts are built to never alter or delete existing user data, only append where necessary.
-   **Scalable Worker System**: Uses BullMQ and Redis to create a robust background job processing system.
-   **Dockerized Staging Environment**: Spin up the entire stack (API, Worker, DB, Redis) with a single command for easy local development and testing.
-   **Unit Tested**: Core endpoints are verified with Jest for reliability.

## 🧱 Architecture Overview

-   **API**: An Express.js server responsible for handling HTTP requests, user authentication, and interaction with the database.
-   **Worker**: A Node.js process that listens for jobs on a Redis queue (using BullMQ). It's designed for long-running or heavy tasks like AI analysis, transaction processing, or sending notifications.
-   **MongoDB**: The primary database for storing user data, transactions, and other platform information.
-   **Redis**: An in-memory data store used as a message broker for the BullMQ job queue system.

---

## ⚙️ Installation & Setup

### Prerequisites

-   [Docker](https://www.docker.com/get-started) and Docker Compose
-   [Node.js](https://nodejs.org/) (v18 or higher)
-   [npm](https://www.npmjs.com/)

### Steps

1.  **Clone the repository:**
    ```bash
    git clone <repository_url>
    cd nfyn-backend
    ```

2.  **Install dependencies:**
    ```bash
    npm install
    ```

3.  **Create Environment File:**
    Copy the example environment file. No changes are needed if you are using the provided Docker setup.
    ```bash
    cp .env.example .env
    ```

---

## 🚀 Running the Staging Environment

The easiest way to run the entire stack is with Docker Compose.

```bash
docker-compose -f docker-compose.staging.yml up --build
```

This command will:
1.  Build the Docker images for the `api` and `worker`.
2.  Start four containers: `nfyn-mongo-staging`, `nfyn-redis-staging`, `nfyn-api-staging`, and `nfyn-worker-staging`.
3.  The API will be available at `http://localhost:3001`.

To stop the services:
```bash
docker-compose -f docker-compose.staging.yml down
```

---

##  migration
### 🔄 Running the Migration Script

If you have existing users in your database from a previous version who are missing the `sandbox_balance`, you can run the non-destructive migration script.

**Important:** Always backup your database before running a migration.

```bash
# Execute this command from your host machine while the Docker containers are running
docker-compose -f docker-compose.staging.yml exec api npm run migrate
```

This will safely add a `sandbox_balance` of `10000` to any user who doesn't have one.

---

## 🧪 Testing

### Running Unit Tests

We use Jest for unit testing. The tests run against an in-memory MongoDB database to ensure they don't interfere with your staging data.

```bash
npm test
```

### Manual Endpoint Testing (cURL)

You can test the primary wallet connect endpoint using `curl`.

**1. Connect a brand-new wallet:**
This will create a new user and return their profile with the default `sandbox_balance`.

```bash
curl -X POST http://localhost:3001/api/auth/connect \
-H "Content-Type: application/json" \
-d '{"wallet": "So11111111111111111111111111111111111111112"}'
```

**2. Connect the same wallet again (Idempotency Test):**
This will find and return the existing user without creating a new one.

```bash
curl -X POST http://localhost:3001/api/auth/connect \
-H "Content-Type: application/json" \
-d '{"wallet": "So11111111111111111111111111111111111111112"}'
```

**3. Test with an invalid wallet address:**
This should return a 400 Bad Request error.
```bash
curl -X POST http://localhost:3001/api/auth/connect \
-H "Content-Type: application/json" \
-d '{"wallet": "invalid-address"}'
```

---

## ⚠️ Safety, Backup, and Rollback

### Sandbox vs. Live Environment

-   **Sandbox**: All current functionality, especially `sandbox_balance` and simulated transactions, operates in a "sandbox" mode. This data is real and persistent but is explicitly separated from any future "live" balance.
-   **Live Environment (Future)**: To introduce live trading, a new set of fields (e.g., `live_balance`) will be created. Access to live functionality will require an explicit and secure user **opt-in**, ensuring no accidental mixing of funds.

### Database Backup

It is critical to perform regular backups of your MongoDB database, especially before running migrations.

**Backup command (run from your host machine):**
```bash
# This dumps the entire nfyn_staging database into a 'dump/' directory
docker-compose -f docker-compose.staging.yml exec mongodb mongodump --db nfyn_staging --out /data/db/backup/$(date +%Y-%m-%d_%H-%M-%S)
```
*Note: This saves the backup inside the Docker volume. You may want to copy it out to your host.*

### Database Restore / Rollback

**Restore command:**
```bash
# Replace <backup_directory_name> with the actual directory from the backup command
docker-compose -f docker-compose.staging.yml exec mongodb mongorestore --db nfyn_staging /data/db/backup/<backup_directory_name>/nfyn_staging
```

**Rollback for Migration:**
If you need to reverse the `add_sandbox_balance` migration, you would run a script to remove the field. A rollback script would look like this (do not run unless necessary):
```javascript
// migrations/rollback_sandbox_balance.js
// ... (DB connection setup) ...
// const filter = { sandbox_balance: { $exists: true } };
// const update = { $unset: { sandbox_balance: "" } };
// await User.updateMany(filter, update);
```
