import React, { useState, useEffect } from 'react';
import Card from '../components/Card';
import { MOCK_QUIZ_QUESTIONS } from '../constants';
import { FaGraduationCap, FaTrophy, FaLightbulb, FaCheckCircle, FaTimesCircle, FaChartLine, FaArrowRight } from 'react-icons/fa';
import { motion, AnimatePresence } from 'framer-motion';
import { useTranslation } from '../LanguageContext';
import { PubliApisService } from '../services/publiApisService'; // Use the new PubliApisService
import { FearAndGreedIndex, MarketMover } from '../types';
import SkeletonLoader from '../components/SkeletonLoader';
import { TrendingUp, TrendingDown, BookOpen } from 'lucide-react';


const Sparkline: React.FC<{ data: number[] }> = ({ data }) => {
    if (!data || data.length === 0) return null;
    const width = 100;
    const height = 30;
    const max = Math.max(...data);
    const min = Math.min(...data);
    const range = max - min === 0 ? 1 : max - min;
    const points = data.map((d, i) => `${(i / (data.length - 1)) * width},${height - ((d - min) / range) * height}`).join(' ');

    return (
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-8" preserveAspectRatio="none">
            <polyline points={points} fill="none" stroke={data[data.length - 1] >= data[0] ? '#8cff00' : '#EF4444'} strokeWidth="2" />
        </svg>
    );
};

const TopMoverCard: React.FC<{ mover: MarketMover }> = ({ mover }) => {
    const isGainer = mover.change24h >= 0;
    return (
        <Card className="p-3">
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                    <img src={mover.logoUrl} alt={mover.name} className="w-8 h-8 rounded-full" />
                    <div>
                        <p className="font-bold text-sm text-white">{mover.symbol}</p>
                        <p className="text-xs text-slate-400 truncate w-16">{mover.name}</p>
                    </div>
                </div>
                <div className="w-1/3">
                    <Sparkline data={mover.sparkline} />
                </div>
                <div className="text-right">
                     <p className="font-mono font-semibold text-white">${mover.price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: mover.price > 1 ? 2 : 6 })}</p>
                     <p className={`font-bold text-xs ${isGainer ? 'text-accent-green' : 'text-accent-red'}`}>{isGainer ? '+' : ''}{mover.change24h.toFixed(2)}%</p>
                </div>
            </div>
        </Card>
    );
};

const FearAndGreedGauge: React.FC<{ data: FearAndGreedIndex }> = ({ data }) => {
    const percentage = data.value / 100;
    const angle = -90 + (percentage * 180);
    const color = `hsl(${(percentage * 120)}, 80%, 50%)`;

    return (
        <Card className="p-6 text-center">
            <h3 className="font-bold text-lg text-white mb-2">Market Sentiment</h3>
             <div className="relative flex flex-col items-center justify-center w-full max-w-[200px] mx-auto">
                <svg viewBox="0 0 120 70" className="w-full">
                    <defs>
                        <linearGradient id="gaugeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                            <stop offset="0%" stopColor="#EF4444" />
                            <stop offset="50%" stopColor="#FBBF24" />
                            <stop offset="100%" stopColor="#8cff00" />
                        </linearGradient>
                    </defs>
                    <path d="M10 60 A 50 50 0 0 1 110 60" stroke="url(#gaugeGradient)" strokeWidth="12" strokeLinecap="round" fill="none" opacity="0.3" />
                    <g style={{ transformOrigin: '60px 60px', transition: 'transform 1s ease-out', transform: `rotate(${angle}deg)` }}>
                        <path d="M60 60 L60 15" stroke="white" strokeWidth="2.5" strokeLinecap="round" />
                        <circle cx="60" cy="60" r="4" fill="white" />
                    </g>
                </svg>
                <div className="absolute bottom-5 text-center">
                    <p className="text-3xl font-bold text-white">{data.value}</p>
                    <p className="font-semibold" style={{ color }}>{data.value_classification}</p>
                </div>
            </div>
        </Card>
    );
};

const EducationCard: React.FC<{ icon: React.ReactElement; title: string; description: string; linkText: string; }> = ({ icon, title, description, linkText }) => (
    <Card className="p-4 group">
        <div className="flex items-center gap-3">
            <div className="p-2 bg-slate-700 rounded-lg">{icon}</div>
            <div>
                <h3 className="font-bold text-white">{title}</h3>
                <p className="text-sm text-slate-400">{description}</p>
            </div>
        </div>
        <div className="text-right mt-3">
            <a href="#" className="text-sm font-semibold text-accent-cyan group-hover:underline flex items-center justify-end gap-1">
                {linkText} <FaArrowRight className="transition-transform group-hover:translate-x-1" />
            </a>
        </div>
    </Card>
);

const DailyQuiz: React.FC = () => {
    const { t } = useTranslation();
    const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
    const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
    const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
    const [xpGained, setXpGained] = useState(0);
    const [showResult, setShowResult] = useState(false);

    const question = MOCK_QUIZ_QUESTIONS[currentQuestionIndex];
    const answers = Object.entries(question.answers).filter(([, val]) => val !== null);

    const handleAnswer = (answerKey: string) => {
        if (selectedAnswer) return;
        const answerKeyWithoutPrefix = answerKey.replace('answer_', '');
        setSelectedAnswer(answerKeyWithoutPrefix);
        const correctKey = Object.keys(question.correct_answers).find(key => question.correct_answers[key as keyof typeof question.correct_answers] === "true");
        const isAnswerCorrect = `${answerKeyWithoutPrefix}_correct` === correctKey;
        setIsCorrect(isAnswerCorrect);
        if (isAnswerCorrect) {
            setXpGained(prev => prev + 25);
        }
        setShowResult(true);
    };

    const handleNext = () => {
        setShowResult(false);
        setTimeout(() => {
            setSelectedAnswer(null);
            setIsCorrect(null);
            if (currentQuestionIndex < MOCK_QUIZ_QUESTIONS.length - 1) {
                setCurrentQuestionIndex(prev => prev + 1);
            } else {
                 // Quiz finished, reset or show summary
                 setCurrentQuestionIndex(0);
                 setXpGained(0);
            }
        }, 300);
    };
    
    const isQuizFinished = showResult && currentQuestionIndex === MOCK_QUIZ_QUESTIONS.length - 1;

    return (
        <div>
            <h2 className="text-2xl font-semibold text-white mb-4 flex items-center gap-2"><FaLightbulb className="text-glovo-yellow" /> Daily Quiz</h2>
            <Card className="p-6 relative overflow-hidden">
                <AnimatePresence mode="wait">
                    <motion.div
                        key={currentQuestionIndex}
                        initial={{ opacity: 0, x: 50 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -50 }}
                        transition={{ duration: 0.3 }}
                    >
                        <p className="font-semibold text-white mb-4 text-lg">{question.question}</p>
                        <div className="space-y-3">
                            {answers.map(([key, text]) => {
                                const answerKey = key.replace('answer_', '');
                                const isSelected = selectedAnswer === answerKey;
                                let buttonStyle = 'bg-slate-700 hover:bg-slate-600';
                                if (isSelected) {
                                    buttonStyle = isCorrect ? 'bg-accent-green text-black' : 'bg-accent-red text-white';
                                }
                                
                                return (
                                    <button 
                                        key={key} 
                                        onClick={() => handleAnswer(key)} 
                                        disabled={!!selectedAnswer}
                                        className={`w-full text-left p-3 rounded-lg transition-colors duration-300 flex justify-between items-center ${buttonStyle}`}
                                    >
                                        <span>{text}</span>
                                        {isSelected && (isCorrect ? <FaCheckCircle /> : <FaTimesCircle />)}
                                    </button>
                                );
                            })}
                        </div>
                    </motion.div>
                </AnimatePresence>

                <div className="flex justify-between items-center mt-6 h-8">
                     <p className="text-glovo-yellow font-bold text-lg">XP Gained: {xpGained}</p>
                     <AnimatePresence>
                        {showResult && (
                             <motion.button 
                                initial={{ opacity: 0, scale: 0.8 }}
                                animate={{ opacity: 1, scale: 1 }}
                                exit={{ opacity: 0, scale: 0.8 }}
                                onClick={handleNext} 
                                className="bg-accent-purple text-white font-bold py-2 px-6 rounded-lg"
                             >
                                {isQuizFinished ? 'Finish' : 'Next'}
                            </motion.button>
                        )}
                    </AnimatePresence>
                </div>
            </Card>
        </div>
    );
};

const LearnScreen: React.FC = () => {
    const [fearAndGreed, setFearAndGreed] = useState<FearAndGreedIndex | null>(null);
    const [movers, setMovers] = useState<{ gainers: MarketMover[], losers: MarketMover[] }>({ gainers: [], losers: [] });
    const [isLoading, setIsLoading] = useState(true);
    
    useEffect(() => {
        const fetchData = async () => {
            setIsLoading(true);
            const [fgData, moversData] = await Promise.all([
                PubliApisService.getFearAndGreedIndex(), // Use PubliApisService
                PubliApisService.getMarketMovers() // Use PubliApisService
            ]);
            setFearAndGreed(fgData);
            setMovers(moversData);
            setIsLoading(false);
        };
        fetchData();
    }, []);

    const getLearningSuggestion = () => {
        if (!fearAndGreed) return null;
        if (fearAndGreed.value <= 30) {
            return {
                icon: <FaChartLine className="text-accent-green" />,
                title: "Market is Fearful",
                description: "Fear can signal buying opportunities. Learn to analyze trends.",
                linkText: "Study Technical Analysis"
            };
        }
        if (fearAndGreed.value >= 70) {
            return {
                icon: <FaTrophy className="text-accent-red" />,
                title: "Market is Greedy",
                description: "Greed can be risky. Learn to take profits and manage risk.",
                linkText: "Master Risk Management"
            };
        }
        return {
            icon: <BookOpen className="text-accent-cyan" />,
            title: "Market is Neutral",
            description: "A good time to build a solid foundation. Explore core DeFi concepts.",
            linkText: "Learn DeFi Basics"
        };
    };

    const learningSuggestion = getLearningSuggestion();

    return (
        <div className="p-4 md:p-6 space-y-8">
            <div className="text-center">
                <h1 className="text-3xl font-bold font-orbitron bg-gradient-to-r from-accent-cyan to-accent-purple text-transparent bg-clip-text flex items-center justify-center gap-3">
                    <FaGraduationCap /> Education Hub
                </h1>
                <p className="text-slate-400">Expand your knowledge and level up your trading skills.</p>
            </div>
            
            <section>
                <h2 className="text-2xl font-bold text-white mb-4">Market Pulse</h2>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <div className="lg:col-span-1">
                        {isLoading || !fearAndGreed ? <SkeletonLoader className="h-full min-h-[250px] rounded-2xl" /> : <FearAndGreedGauge data={fearAndGreed} />}
                    </div>
                    <div className="lg:col-span-2 space-y-4">
                        {isLoading ? (
                           [...Array(2)].map((_, i) => (
                               <Card key={i} className="p-4">
                                   <div className="flex justify-between items-center mb-2">
                                       <SkeletonLoader className="h-5 w-24 rounded" />
                                       <SkeletonLoader className="h-5 w-16 rounded" />
                                   </div>
                                   <div className="space-y-2">
                                        {[...Array(3)].map((_, j) => (
                                            <div key={j} className="flex items-center gap-2 p-1.5"><SkeletonLoader className="w-8 h-8 rounded-full" /><SkeletonLoader className="h-4 w-20 rounded" /><SkeletonLoader className="h-4 w-16 ml-auto rounded" /></div>
                                        ))}
                                   </div>
                               </Card>
                           ))
                        ) : (
                            <>
                                <Card className="p-4">
                                    <h3 className="font-bold text-lg text-white mb-2 flex items-center gap-2"><TrendingUp className="text-accent-green" /> Top Gainers</h3>
                                    <div className="space-y-2">
                                        {movers.gainers.map(g => <TopMoverCard key={g.id} mover={g} />)}
                                    </div>
                                </Card>
                                <Card className="p-4">
                                     <h3 className="font-bold text-lg text-white mb-2 flex items-center gap-2"><TrendingDown className="text-accent-red" /> Top Losers</h3>
                                    <div className="space-y-2">
                                        {movers.losers.map(l => <TopMoverCard key={l.id} mover={l} />)}
                                    </div>
                                </Card>
                            </>
                        )}
                    </div>
                </div>
            </section>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
                <div className="space-y-8">
                     <DailyQuiz />
                </div>
                <div className="space-y-4">
                     <h2 className="text-2xl font-semibold text-white">Learning Paths</h2>
                     {isLoading ? (
                         <SkeletonLoader className="h-24 rounded-2xl" />
                     ) : learningSuggestion && (
                         <EducationCard {...learningSuggestion} />
                     )}
                     <EducationCard icon={<FaTrophy className="text-glovo-yellow"/>} title="Daily Challenge" description="Earn 50 bonus XP by completing a full quiz round!" linkText="Start Challenge" />
                </div>
            </div>
        </div>
    );
};

export default LearnScreen;