import React, { useState, useEffect } from 'react';
import Card from '../components/Card';
import SkeletonLoader from '../components/SkeletonLoader';
import { useTranslation } from '../LanguageContext';
import { GeminiService } from '../services/geminiService';
import { PubliApisService } from '../services/publiApisService'; // Use the new PubliApisService
import { TrendingCoin, NewsArticle } from '../types';
import { motion } from 'framer-motion';
import { Compass, Newspaper, TrendingUp, BrainCircuit } from 'lucide-react';

// --- SUB-COMPONENTS ---

const SentimentGauge: React.FC<{ value: number }> = ({ value }) => {
    const { t } = useTranslation();
    const percentage = value / 100;
    const angle = -90 + (percentage * 180);
    const color = `hsl(${(percentage * 120)}, 80%, 50%)`;

    const getSentimentText = (val: number) => {
        if (val < 20) return t('marketOverview.extremeFear');
        if (val < 45) return "Fear";
        if (val < 55) return "Neutral";
        if (val < 80) return "Greed";
        return t('marketOverview.extremeGreed');
    }

    return (
        <div className="relative flex flex-col items-center justify-center w-full">
            <svg viewBox="0 0 120 70" className="w-full">
                <defs>
                    <linearGradient id="gaugeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="#EF4444" />
                        <stop offset="50%" stopColor="#FBBF24" />
                        <stop offset="100%" stopColor="#39FF14" />
                    </linearGradient>
                </defs>
                <path
                    d="M10 60 A 50 50 0 0 1 110 60"
                    stroke="url(#gaugeGradient)"
                    strokeWidth="12"
                    strokeLinecap="round"
                    fill="none"
                />
                {/* Needle */}
                <g style={{ transformOrigin: '60px 60px', transition: 'transform 1s ease-out', transform: `rotate(${angle}deg)` }}>
                    <path d="M60 60 L60 15" stroke="white" strokeWidth="2" strokeLinecap="round" />
                    <circle cx="60" cy="60" r="4" fill="white" />
                </g>
            </svg>
            <div className="absolute bottom-8 text-center">
                <p className="text-4xl font-bold text-white">{value}</p>
                <p className="font-semibold" style={{ color }}>{getSentimentText(value)}</p>
            </div>
             <p className="absolute left-0 bottom-0 text-xs text-red-400 font-semibold">{t('marketOverview.extremeFear')}</p>
             <p className="absolute right-0 bottom-0 text-xs text-green-400 font-semibold">{t('marketOverview.extremeGreed')}</p>
        </div>
    );
};

const MarketSentimentWidget: React.FC = () => {
    const { t } = useTranslation();
    const [sentiment, setSentiment] = useState<{ value: number; summary: string } | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchSentiment = async () => {
            setIsLoading(true);
            const fetchedNews = await PubliApisService.getNewsFeed(); // Fetch news from PubliApisService
            const headlines = fetchedNews.map(a => a.title);
            const { sentimentValue, summary } = await GeminiService.getOverallMarketSentiment(headlines);
            setSentiment({ value: sentimentValue, summary: summary.startsWith("gemini.error") ? t(summary) : summary });
            setIsLoading(false);
        };
        fetchSentiment();
    }, [t]);

    return (
        <Card className="col-span-1 md:col-span-3" highlight="purple">
            <div className="p-6">
                <h2 className="text-xl font-bold text-slate-800 dark:text-slate-50 flex items-center gap-2 mb-4">
                    <Compass /> {t('marketOverview.sentimentTitle')}
                </h2>
                {isLoading ? (
                    <div className="flex flex-col md:flex-row items-center gap-6">
                        <div className="w-full max-w-xs h-36"><SkeletonLoader className="w-full h-full rounded-lg" /></div>
                        <div className="flex-1 space-y-2">
                            <SkeletonLoader className="h-5 w-1/3 rounded" />
                            <SkeletonLoader className="h-4 w-full rounded" />
                            <SkeletonLoader className="h-4 w-full rounded" />
                            <SkeletonLoader className="h-4 w-3/4 rounded" />
                        </div>
                    </div>
                ) : sentiment && (
                    <div className="flex flex-col md:flex-row items-center justify-center gap-6 md:gap-8">
                        <div className="w-full max-w-xs md:w-56 flex-shrink-0">
                             <SentimentGauge value={sentiment.value} />
                        </div>
                        <div className="flex-1">
                            <h3 className="font-bold text-accent-purple text-base flex items-center gap-2">
                                <BrainCircuit size={20} />
                                <span>{t('aiSummary')}</span>
                            </h3>
                            <p className="text-slate-600 dark:text-slate-300 mt-2">{sentiment.summary}</p>
                        </div>
                    </div>
                )}
            </div>
        </Card>
    );
};

const TrendingCoinsWidget: React.FC = () => {
    const { t } = useTranslation();
    const [trending, setTrending] = useState<TrendingCoin[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchTrending = async () => {
            setIsLoading(true);
            const data = await PubliApisService.getTrendingCoins(); // Fetch trending coins from PubliApisService
            setTrending(data);
            setIsLoading(false);
        };
        fetchTrending();
    }, []);

    return (
        <Card className="flex flex-col h-full">
            <div className="p-4 border-b border-slate-200 dark:border-slate-700 flex-shrink-0">
                <h2 className="font-bold text-lg text-slate-800 dark:text-slate-50 flex items-center gap-2">
                    <TrendingUp /> {t('marketOverview.trendingTitle')}
                </h2>
            </div>
            <div className="p-2 flex-1 overflow-y-auto">
                {isLoading ? (
                    [...Array(5)].map((_, i) => (
                        <div key={i} className="flex items-center gap-3 p-2">
                            <SkeletonLoader className="w-8 h-8 rounded-full" />
                            <SkeletonLoader className="h-4 w-24 rounded" />
                            <SkeletonLoader className="h-4 w-12 rounded ml-auto" />
                        </div>
                    ))
                ) : (
                    trending.slice(0, 5).map(coin => (
                        <motion.div
                            key={coin.id}
                            className="flex items-center justify-between p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700/50"
                            whileHover={{ scale: 1.02 }}
                        >
                            <div className="flex items-center gap-3">
                                <img src={coin.thumb} alt={coin.name} className="w-8 h-8 rounded-full" />
                                <div>
                                    <p className="font-bold text-slate-800 dark:text-slate-50">{coin.name}</p>
                                    <p className="text-xs text-slate-500 dark:text-slate-400">{coin.symbol.toUpperCase()}</p>
                                </div>
                            </div>
                            {coin.market_cap_rank && (
                                <div className="text-right">
                                    <p className="text-xs text-slate-500 dark:text-slate-400">{t('marketOverview.rank')}</p>
                                    <p className="font-bold text-lg text-slate-800 dark:text-slate-50">#{coin.market_cap_rank}</p>
                                </div>
                            )}
                        </motion.div>
                    ))
                )}
            </div>
        </Card>
    );
};

const TopNewsWidget: React.FC = () => {
    const { t } = useTranslation();
    const [summaries, setSummaries] = useState<Record<string, string>>({});
    const [newsArticles, setNewsArticles] = useState<NewsArticle[]>([]); // State for news articles
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchNewsAndSummaries = async () => {
            setIsLoading(true);
            const fetchedArticles = await PubliApisService.getNewsFeed(); // Fetch news from PubliApisService
            const topArticles = fetchedArticles.slice(0, 3);
            setNewsArticles(topArticles);

            const articlesToSummarize = topArticles.map(a => ({ id: a.id, title: a.title }));
            const summaryMap = await GeminiService.getBulkSummaries(articlesToSummarize);
            
            const translatedSummaries: Record<string, string> = {};
            for (const article of topArticles) {
                const summary = summaryMap[article.id] || "gemini.error.summary";
                translatedSummaries[article.id] = summary.startsWith("gemini.error") ? t(summary) : summary;
            }

            setSummaries(translatedSummaries);
            setIsLoading(false);
        };
        fetchNewsAndSummaries();
    }, [t]);

    return (
        <Card className="col-span-1 md:col-span-2 flex flex-col h-full">
            <div className="p-4 border-b border-slate-200 dark:border-slate-700 flex-shrink-0">
                <h2 className="font-bold text-lg text-slate-800 dark:text-slate-50 flex items-center gap-2">
                    <Newspaper /> {t('marketOverview.newsTitle')}
                </h2>
            </div>
            <div className="divide-y divide-slate-200 dark:divide-slate-700 flex-1 overflow-y-auto">
                {newsArticles.map(article => ( // Use newsArticles from state
                    <div key={article.id} className="p-4">
                        <h3 className="font-semibold text-slate-800 dark:text-slate-50">{article.title}</h3>
                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">{article.source}</p>
                        <div className="mt-2 text-sm text-slate-600 dark:text-slate-300">
                            {isLoading ? (
                                <SkeletonLoader className="h-10 w-full rounded" />
                            ) : (
                                <p>
                                    <span className="font-bold text-accent-purple mr-1">{t('aiSummary')}:</span>
                                    {summaries[article.id]}
                                </p>
                            )}
                        </div>
                    </div>
                ))}
            </div>
        </Card>
    );
};

// --- MAIN SCREEN COMPONENT ---

const MarketOverviewScreen: React.FC = () => {
    return (
        <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.3 }}
            className="p-4 md:p-6 grid grid-cols-1 md:grid-cols-3 gap-6"
        >
            <MarketSentimentWidget />
            <TopNewsWidget />
            <TrendingCoinsWidget />
        </motion.div>
    );
};

export default MarketOverviewScreen;