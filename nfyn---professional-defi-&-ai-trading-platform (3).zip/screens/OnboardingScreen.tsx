import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FaRobot, FaUsers, FaGraduationCap } from 'react-icons/fa';
import { ChevronRight, ChevronLeft } from 'lucide-react';
import { NfynLogo } from '../components/icons/Logo';

interface OnboardingScreenProps {
  onComplete: () => void;
}

const onboardingSteps = [
  {
    icon: <FaRobot className="w-20 h-20" />,
    title: "AI-Powered Trading",
    description: "Leverage our advanced AI to automate your trading strategies. Scalping, farming, and futures bots at your command.",
    color: "cyan"
  },
  {
    icon: <FaUsers className="w-20 h-20" />,
    title: "Community & Intel",
    description: "Access AI-driven news summaries, follow top traders on the leaderboard, and participate in governance.",
    color: "purple"
  },
  {
    icon: <FaGraduationCap className="w-20 h-20" />,
    title: "Learn and Grow",
    description: "Master DeFi concepts with our integrated academy. From beginner guides to advanced strategies, level up your skills.",
    color: "green"
  },
];

const variants = {
  enter: (direction: number) => ({
    x: direction > 0 ? 1000 : -1000,
    opacity: 0
  }),
  center: {
    zIndex: 1,
    x: 0,
    opacity: 1
  },
  exit: (direction: number) => ({
    zIndex: 0,
    x: direction < 0 ? 1000 : -1000,
    opacity: 0
  })
};

const OnboardingScreen: React.FC<OnboardingScreenProps> = ({ onComplete }) => {
  const [[page, direction], setPage] = useState([0, 0]);

  const paginate = (newDirection: number) => {
    const newPage = page + newDirection;
    if (newPage >= 0 && newPage < onboardingSteps.length) {
      setPage([newPage, newDirection]);
    }
  };
  
  const step = onboardingSteps[page];
  
  const highlightClasses: { [key: string]: string } = {
    cyan: 'text-accent-cyan shadow-cyan',
    purple: 'text-accent-purple shadow-purple',
    green: 'text-accent-green shadow-green'
  };
  const backgroundClasses: { [key: string]: string } = {
    cyan: 'bg-accent-cyan',
    purple: 'bg-accent-purple',
    green: 'bg-accent-green'
  };

  return (
    <div className="fixed inset-0 bg-slate-900 text-white flex flex-col items-center justify-center overflow-hidden font-sans">
      <div className="absolute top-8">
        <NfynLogo className="w-28 h-12" />
      </div>

      <div className="relative w-full h-full flex items-center justify-center">
        <AnimatePresence initial={false} custom={direction}>
          <motion.div
            key={page}
            custom={direction}
            variants={variants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{
              x: { type: "spring", stiffness: 300, damping: 30 },
              opacity: { duration: 0.2 }
            }}
            drag="x"
            dragConstraints={{ left: 0, right: 0 }}
            dragElastic={1}
            onDragEnd={(e, { offset, velocity }) => {
              const swipe = Math.abs(offset.x) * velocity.x;
              if (swipe < -10000) {
                paginate(1);
              } else if (swipe > 10000) {
                paginate(-1);
              }
            }}
            className="absolute w-[90%] max-w-sm text-center flex flex-col items-center"
          >
            <div className={`mb-8 ${highlightClasses[step.color]} animate-subtle-glow`}>
              {step.icon}
            </div>
            <h2 className={`text-3xl font-bold mb-4 ${highlightClasses[step.color]}`}>{step.title}</h2>
            <p className="text-slate-300 leading-relaxed">{step.description}</p>
          </motion.div>
        </AnimatePresence>
      </div>
      
      <div className="absolute bottom-10 left-0 right-0 px-8">
        <div className="flex justify-between items-center mb-6">
          <button 
            onClick={() => paginate(-1)} 
            className={`p-3 rounded-full transition-opacity ${page === 0 ? 'opacity-0 cursor-default' : 'opacity-100 bg-slate-800 hover:bg-slate-700'}`}
            disabled={page === 0}
            aria-label="Previous step"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          <div className="flex space-x-2">
            {onboardingSteps.map((_, i) => (
              <div
                key={i}
                className={`w-2 h-2 rounded-full transition-all duration-300 ${i === page ? `bg-accent-cyan scale-125` : 'bg-slate-600'}`}
              />
            ))}
          </div>

          <button 
             onClick={() => paginate(1)} 
            className={`p-3 rounded-full transition-opacity ${page === onboardingSteps.length - 1 ? 'opacity-0 cursor-default' : 'opacity-100 bg-slate-800 hover:bg-slate-700'}`}
            disabled={page === onboardingSteps.length - 1}
            aria-label="Next step"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        </div>
        
        <motion.button
          onClick={onComplete}
          className={`w-full py-3 font-bold rounded-lg text-lg transition-all duration-300 text-slate-900 ${backgroundClasses[step.color]}`}
          style={{
              boxShadow: page === onboardingSteps.length - 1 ? `0 0 20px var(--tw-color-${step.color})` : 'none',
              opacity: page === onboardingSteps.length - 1 ? 1 : 0,
              transform: page === onboardingSteps.length - 1 ? 'translateY(0)' : 'translateY(20px)',
              pointerEvents: page === onboardingSteps.length - 1 ? 'auto' : 'none'
          }}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          Get Started
        </motion.button>
      </div>
    </div>
  );
};

export default OnboardingScreen;
