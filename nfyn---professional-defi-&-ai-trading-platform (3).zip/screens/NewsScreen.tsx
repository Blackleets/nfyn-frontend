
import React, { useState, useMemo, useCallback, useEffect } from 'react';
import { useTranslation } from '../LanguageContext';
import { ApiNewsArticle, SentimentData } from '../types';
import { PubliApisService } from '../services/publiApisService';
import { GeminiService } from '../services/geminiService';
import Card from '../components/Card';
import SkeletonLoader from '../components/SkeletonLoader';
import { motion, AnimatePresence, useMotionValue, useTransform } from 'framer-motion';
import { Newspaper, Check, Bookmark, Filter, RefreshCw, ArrowDown, BrainCircuit, Smile, Frown, Meh, ExternalLink } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';


const SentimentBadge: React.FC<{ sentiment: SentimentData['classification'] }> = ({ sentiment }) => {
    const { t } = useTranslation();
    const styles = {
        Bullish: 'bg-accent-green/20 text-accent-green',
        Bearish: 'bg-accent-red/20 text-accent-red',
        Neutral: 'bg-slate-500/20 text-slate-400',
    };
    const icons = {
        Bullish: <Smile size={14} />,
        Bearish: <Frown size={14} />,
        Neutral: <Meh size={14} />,
    };
    return (
        <span className={`px-2 py-1 text-xs font-bold rounded-full flex items-center gap-1 ${styles[sentiment]}`}>
            {icons[sentiment]} {t(`sentiment.${sentiment.toLowerCase()}`)}
        </span>
    );
};

const NewsArticleCard: React.FC<{ 
    article: ApiNewsArticle;
    isRead: boolean;
    isSaved: boolean;
    onToggleRead: (id: string) => void;
    onToggleSave: (id: string) => void;
    summaryAI: string | null;
    isSummaryLoading: boolean;
    onGenerateSummary: (id: string, title: string) => void;
    sentiment: SentimentData | null;
}> = ({ article, isRead, isSaved, onToggleRead, onToggleSave, summaryAI, isSummaryLoading, onGenerateSummary, sentiment }) => {
    const { t } = useTranslation();
    const [isExpanded, setIsExpanded] = useState(false);
    const summaryText = summaryAI?.startsWith("gemini.error") ? t(summaryAI) : summaryAI;
    const SUMMARY_TRUNCATE_LENGTH = 120;
    
    return (
        <motion.div
            layout
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: isRead ? 0.75 : 1, y: 0, scale: 1 }}
            whileHover={{ opacity: 1, scale: 1.02 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            transition={{ type: 'spring', stiffness: 250, damping: 25 }}
            className="h-full"
        >
            <Card className={`p-0 overflow-hidden h-full flex flex-col ${isRead ? 'border-slate-800' : 'border-slate-700'} transition-colors`}>
                <div className="relative group">
                    <a href={article.articleUrl} target="_blank" rel="noopener noreferrer" className="block overflow-hidden">
                        <img 
                            src={article.imageUrl} 
                            alt={article.title} 
                            className="w-full h-40 object-cover transition-transform duration-500 group-hover:scale-110" 
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end justify-between p-3">
                             <span className="text-xs text-white font-semibold flex items-center gap-1">
                                Read Full Story <ExternalLink size={12} />
                            </span>
                        </div>
                    </a>

                    {/* Visual Badges Overlay */}
                    <div className="absolute top-2 right-2 flex flex-col gap-2 items-end pointer-events-none">
                        {isSaved && (
                            <motion.div 
                                initial={{ scale: 0, opacity: 0 }} 
                                animate={{ scale: 1, opacity: 1 }}
                                className="bg-accent-purple/90 text-white text-[10px] font-bold px-2 py-1 rounded-md shadow-lg flex items-center gap-1 backdrop-blur-md border border-accent-purple/50"
                            >
                                <Bookmark size={10} fill="currentColor" /> SAVED
                            </motion.div>
                        )}
                        {isRead && (
                            <motion.div 
                                initial={{ scale: 0, opacity: 0 }} 
                                animate={{ scale: 1, opacity: 1 }}
                                className="bg-slate-900/80 text-slate-400 text-[10px] font-bold px-2 py-1 rounded-md shadow-lg backdrop-blur-md border border-slate-700"
                            >
                                READ
                            </motion.div>
                        )}
                    </div>
                </div>

                <div className="p-4 flex-grow flex flex-col">
                    <div className="flex-grow">
                        <a href={article.articleUrl} target="_blank" rel="noopener noreferrer" >
                            <h3 className={`font-bold text-base transition-colors ${isRead ? 'text-slate-400' : 'text-slate-50 hover:text-accent-cyan'}`}>
                                {article.title}
                            </h3>
                            <p className="text-sm text-slate-400 mt-2 line-clamp-3">{article.summary}</p>
                        </a>
                        <div className="mt-4">
                            <AnimatePresence mode="wait">
                                {isSummaryLoading ? (
                                    <motion.div key="loading" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="border-t border-slate-800/50 pt-3">
                                        <h4 className="text-xs font-semibold text-accent-purple flex items-center gap-2 mb-2">
                                            <BrainCircuit size={14} className="animate-pulse" /> {t('aiSummary')}
                                        </h4>
                                        <div className="space-y-1.5"><SkeletonLoader className="h-3 w-full rounded"/><SkeletonLoader className="h-3 w-5/6 rounded"/></div>
                                    </motion.div>
                                ) : summaryText ? (
                                    <motion.div key="summary" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="border-t border-slate-800/50 pt-3">
                                        <h4 className="text-xs font-semibold text-accent-purple flex items-center gap-2 mb-1">
                                            <BrainCircuit size={14} /> {t('aiSummary')}
                                        </h4>
                                        <div className="text-sm text-slate-300">
                                            <p>{isExpanded || (summaryText && summaryText.length < SUMMARY_TRUNCATE_LENGTH) ? summaryText : `${summaryText?.slice(0, SUMMARY_TRUNCATE_LENGTH)}...`}</p>
                                            {summaryText && summaryText.length >= SUMMARY_TRUNCATE_LENGTH && (
                                                <button onClick={() => setIsExpanded(!isExpanded)} className="text-accent-cyan text-xs font-bold mt-1 hover:underline">
                                                    {isExpanded ? t('showLess') : t('showMore')}
                                                </button>
                                            )}
                                        </div>
                                    </motion.div>
                                ) : (
                                    <motion.div key="button" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="mt-3">
                                        <button 
                                            onClick={() => onGenerateSummary(article.id, article.title)}
                                            className="w-full flex items-center justify-center gap-2 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-accent-cyan py-2 rounded-lg transition-colors border border-slate-700 hover:border-accent-cyan/50"
                                        >
                                            <BrainCircuit size={14} />
                                            <span>Summarize</span>
                                        </button>
                                    </motion.div>
                                )}
                            </AnimatePresence>
                        </div>
                    </div>

                    <div className="flex justify-between items-center mt-4 pt-3 border-t border-slate-800">
                        <p className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold">{article.source} &bull; {formatDistanceToNow(new Date(article.publishedAt), { addSuffix: true })}</p>
                        <div className="flex items-center gap-2">
                            {sentiment && <SentimentBadge sentiment={sentiment.classification} />}
                            
                            <div className="h-4 w-px bg-slate-700 mx-1"></div>

                            <motion.button 
                                whileTap={{ scale: 0.9 }}
                                onClick={() => onToggleRead(article.id)}
                                className={`p-1.5 rounded-md transition-colors ${isRead ? 'bg-accent-green/10 text-accent-green' : 'bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-slate-200'}`}
                                title={isRead ? "Mark as Unread" : "Mark as Read"}
                            >
                                <Check size={16} />
                            </motion.button>
                             <motion.button 
                                whileTap={{ scale: 0.9 }}
                                onClick={() => onToggleSave(article.id)}
                                className={`p-1.5 rounded-md transition-colors ${isSaved ? 'bg-accent-purple/10 text-accent-purple' : 'bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-slate-200'}`}
                                title={isSaved ? "Remove from Saved" : "Save for Later"}
                            >
                                <Bookmark size={16} className={isSaved ? 'fill-current' : ''}/>
                            </motion.button>
                        </div>
                    </div>
                </div>
            </Card>
        </motion.div>
    );
};

const NewsSkeletonCard: React.FC = () => (
    <Card className="p-0 overflow-hidden">
        <SkeletonLoader className="h-40 w-full" />
        <div className="p-4">
            <SkeletonLoader className="h-5 w-5/6 mb-3 rounded" />
            <SkeletonLoader className="h-4 w-full mb-1 rounded" />
            <SkeletonLoader className="h-4 w-3/4 rounded" />
            <div className="flex justify-between items-center mt-4 pt-3 border-t border-slate-800">
                <SkeletonLoader className="h-3 w-24 rounded" />
                <div className="flex gap-2">
                    <SkeletonLoader className="w-8 h-8 rounded-full" />
                    <SkeletonLoader className="w-8 h-8 rounded-full" />
                </div>
            </div>
        </div>
    </Card>
);

type NewsFilter = 'All' | 'Unread' | 'Saved';
type SentimentFilter = 'all' | 'bullish' | 'bearish' | 'neutral';

const PullToRefresh: React.FC<{ onRefresh: () => void; isRefreshing: boolean }> = ({ onRefresh, isRefreshing }) => {
    const { t } = useTranslation();
    const y = useMotionValue(0);
    const opacity = useTransform(y, [0, 100], [0, 1]);
    const scale = useTransform(y, [0, 100], [0.5, 1.2]);

    return (
        <motion.div
            drag="y"
            dragConstraints={{ top: 0, bottom: 0 }}
            style={{ y }}
            onDragEnd={() => {
                if (y.get() > 100 && !isRefreshing) {
                    onRefresh();
                }
            }}
            className="relative z-10"
        >
            <motion.div
                style={{ opacity, scale }}
                className="absolute -top-12 left-0 right-0 flex justify-center items-center text-slate-400"
            >
                <div className="flex items-center gap-2 p-2 bg-dark-card rounded-full shadow-lg border border-slate-700">
                    <ArrowDown size={16} />
                    <span className="text-xs font-semibold">{t('mobile.pullToRefresh')}</span>
                </div>
            </motion.div>
        </motion.div>
    );
};

const NewsScreen: React.FC = () => {
    const { t } = useTranslation();
    const [articles, setArticles] = useState<ApiNewsArticle[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isRefreshing, setIsRefreshing] = useState(false);
    
    const [summaries, setSummaries] = useState<Record<string, string>>({});
    const [summariesLoading, setSummariesLoading] = useState<Set<string>>(new Set());
    const [sentimentData, setSentimentData] = useState<Record<string, SentimentData>>({});
    const [sentimentLoading, setSentimentLoading] = useState(false);
    
    const [readArticles, setReadArticles] = useState<Set<string>>(() => new Set(JSON.parse(localStorage.getItem('nfyn_read_news') || '[]')));
    const [savedArticles, setSavedArticles] = useState<Set<string>>(() => new Set(JSON.parse(localStorage.getItem('nfyn_saved_news') || '[]')));
    
    const [activeFilter, setActiveFilter] = useState<NewsFilter>('Unread');
    const [activeSentimentFilter, setActiveSentimentFilter] = useState<SentimentFilter>('all');

    const fetchNews = useCallback(async () => {
        if (isRefreshing) return;
    
        if (articles.length === 0) setIsLoading(true);
        setIsRefreshing(true);
    
        const fetchedArticles = await PubliApisService.getNewsFeed();
    
        // Identify new articles by title to handle mock API's changing IDs
        const existingTitles = new Set(articles.map(a => a.title));
        const newArticles = fetchedArticles.filter(a => !existingTitles.has(a.title));
    
        if (newArticles.length > 0) {
            // Add new articles to the main list
            setArticles(prev =>
                [...newArticles, ...prev]
                    .sort((a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime())
                    .slice(0, 50)
            );
    
            // Fetch sentiment for only the new articles
            setSentimentLoading(true);
            const articlesToAnalyze = newArticles.map(a => ({ id: a.id, title: a.title }));
            try {
                const newSentimentData = await GeminiService.getBulkSentimentAnalysis(articlesToAnalyze);
                setSentimentData(prev => ({ ...prev, ...newSentimentData }));
            } catch (e) {
                console.error("Sentiment analysis failed", e);
            } finally {
                setSentimentLoading(false);
            }
        }
    
        setIsLoading(false);
        setIsRefreshing(false);
    }, [articles, isRefreshing]);

    useEffect(() => {
        fetchNews();
        const interval = setInterval(fetchNews, 60 * 1000); // Refresh every 60 seconds
        return () => clearInterval(interval);
    }, [fetchNews]);

    const handleGenerateSummary = useCallback(async (articleId: string, articleTitle: string) => {
        if (summaries[articleId] || summariesLoading.has(articleId)) return;

        setSummariesLoading(prev => new Set(prev).add(articleId));
        try {
            const summary = await GeminiService.summarizeNews(articleTitle);
            setSummaries(prev => ({ ...prev, [articleId]: summary }));
        } catch (error) {
            console.error(`Failed to generate summary for article ${articleId}:`, error);
            setSummaries(prev => ({ ...prev, [articleId]: "gemini.error.summary" }));
        } finally {
            setSummariesLoading(prev => {
                const newSet = new Set(prev);
                newSet.delete(articleId);
                return newSet;
            });
        }
    }, [summaries, summariesLoading]);

    const updateStateAndStorage = (id: string, state: Set<string>, setState: React.Dispatch<React.SetStateAction<Set<string>>>, storageKey: string) => {
        const newSet = new Set(state);
        if (newSet.has(id)) {
            newSet.delete(id);
        } else {
            newSet.add(id);
        }
        setState(newSet);
        localStorage.setItem(storageKey, JSON.stringify(Array.from(newSet)));
    };

    const toggleRead = (id: string) => updateStateAndStorage(id, readArticles, setReadArticles, 'nfyn_read_news');
    const toggleSave = (id: string) => updateStateAndStorage(id, savedArticles, setSavedArticles, 'nfyn_saved_news');
    
    const filteredArticles = useMemo(() => {
        let currentArticles = articles;

        // Apply read/saved filter
        switch(activeFilter) {
            case 'Unread': currentArticles = currentArticles.filter(a => !readArticles.has(a.id)); break;
            case 'Saved': currentArticles = currentArticles.filter(a => savedArticles.has(a.id)); break;
            case 'All':
            default: break;
        }

        // Apply sentiment filter
        if (activeSentimentFilter !== 'all') {
            currentArticles = currentArticles.filter(a => {
                const sentiment = sentimentData[a.id];
                return sentiment && sentiment.classification.toLowerCase() === activeSentimentFilter;
            });
        }

        return currentArticles;
    }, [articles, activeFilter, readArticles, savedArticles, activeSentimentFilter, sentimentData]);

    return (
        <div className="p-4 md:p-6 space-y-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                     <h1 className="text-3xl font-bold font-orbitron bg-gradient-to-r from-accent-cyan to-accent-purple text-transparent bg-clip-text flex items-center gap-3">
                        <Newspaper /> {t('Intel')}
                    </h1>
                    <p className="text-slate-400">Real-time market news and intelligence.</p>
                </div>
                 <button onClick={() => fetchNews()} disabled={isRefreshing} className="flex items-center gap-2 text-sm font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 px-4 py-2 rounded-lg transition-colors disabled:opacity-50">
                    <RefreshCw size={16} className={isRefreshing ? 'animate-spin' : ''}/>
                    <span>{isRefreshing ? t('refreshing') : t('refreshFeed')}</span>
                </button>
            </div>
            
            <Card className="p-3">
                <div className="flex flex-wrap items-center gap-4">
                    <div className="flex items-center gap-2 text-slate-300">
                        <Filter size={16} />
                        <span className="font-semibold text-sm">Filter:</span>
                    </div>
                    <div className="flex space-x-1 p-0.5 bg-slate-800 rounded-md">
                        {(['Unread', 'Saved', 'All'] as NewsFilter[]).map(filter => (
                            <button key={filter} onClick={() => setActiveFilter(filter)}
                                className={`px-3 py-1 text-xs font-semibold rounded transition-colors ${activeFilter === filter ? 'bg-slate-700 shadow text-white' : 'text-slate-400 hover:bg-slate-700/50'}`}>
                                {filter}
                            </button>
                        ))}
                    </div>
                    <div className="flex items-center gap-2 text-slate-300 ml-auto md:ml-4">
                        <BrainCircuit size={16} />
                        <span className="font-semibold text-sm">{t('aiFilterTitle')}:</span>
                    </div>
                     <div className="flex space-x-1 p-0.5 bg-slate-800 rounded-md">
                        {(['all', 'bullish', 'neutral', 'bearish'] as SentimentFilter[]).map(filter => (
                            <button key={filter} onClick={() => setActiveSentimentFilter(filter)} disabled={sentimentLoading}
                                className={`px-3 py-1 text-xs font-semibold rounded transition-colors ${activeSentimentFilter === filter ? 'bg-slate-700 shadow text-white' : 'text-slate-400 hover:bg-slate-700/50'} ${sentimentLoading ? 'opacity-50 cursor-not-allowed' : ''}`}>
                                {t(`sentiment.${filter}`)}
                            </button>
                        ))}
                    </div>
                </div>
            </Card>

            <PullToRefresh onRefresh={fetchNews} isRefreshing={isRefreshing} />

            {(isLoading || sentimentLoading) ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {[...Array(6)].map((_, i) => <NewsSkeletonCard key={i} />)}
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <AnimatePresence>
                        {filteredArticles.map(article => (
                            <NewsArticleCard 
                                key={article.id}
                                article={article}
                                isRead={readArticles.has(article.id)}
                                isSaved={savedArticles.has(article.id)}
                                onToggleRead={toggleRead}
                                onToggleSave={toggleSave}
                                summaryAI={summaries[article.id] || null}
                                isSummaryLoading={summariesLoading.has(article.id)}
                                onGenerateSummary={handleGenerateSummary}
                                sentiment={sentimentData[article.id] || null}
                            />
                        ))}
                    </AnimatePresence>
                </div>
            )}
            
            {!isLoading && filteredArticles.length === 0 && (
                <div className="text-center py-16">
                    <h3 className="text-xl font-bold text-slate-50">{t('noArticlesAiFilter')}</h3>
                    <p className="text-slate-400 mt-2">Try adjusting your filters.</p>
                </div>
            )}
        </div>
    );
};

export default NewsScreen;
