import React, { useState, useMemo } from 'react';
import Card from '../components/Card';
import { LiveCoin } from '../types';
import { useTranslation } from '../LanguageContext';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, ChevronDown, Star } from 'lucide-react';

const AssetCard: React.FC<{ asset: LiveCoin; onToggleWatchlist: (id: string) => void; isWatched: boolean }> = ({ asset, onToggleWatchlist, isWatched }) => {
    const isPositive = asset.change24h >= 0;
    return (
        <motion.div
            layout
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            transition={{ type: 'spring', stiffness: 300, damping: 25 }}
        >
            <Card className="p-4 overflow-hidden group h-full flex flex-col">
                 <div className="flex justify-between items-start">
                    <div className="flex items-center gap-3">
                        <img src={asset.logoUrl} alt={asset.name} className="w-10 h-10 rounded-full" />
                        <div>
                            <p className="font-bold text-slate-50">{asset.symbol}</p>
                            <p className="text-xs text-slate-400 truncate w-24">{asset.name}</p>
                        </div>
                    </div>
                    <button onClick={(e) => { e.stopPropagation(); onToggleWatchlist(asset.id); }} className="text-slate-500 hover:text-glovo-yellow transition-colors">
                        <Star size={20} className={isWatched ? 'fill-current text-glovo-yellow' : ''} />
                    </button>
                </div>
                <div className="mt-4 text-right flex-grow flex flex-col justify-end">
                    <p className="font-mono font-semibold text-lg text-slate-50">${asset.price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: asset.price > 1 ? 2 : 6 })}</p>
                    <p className={`text-sm font-bold ${isPositive ? 'text-accent-green' : 'text-accent-red'}`}>
                        {isPositive ? '+' : ''}{asset.change24h.toFixed(2)}%
                    </p>
                </div>
            </Card>
        </motion.div>
    );
};

interface TokensScreenProps {
    watchlist: string[];
    toggleWatchlist: (coinId: string) => void;
    liveCoinData: LiveCoin[];
}

const TokensScreen: React.FC<TokensScreenProps> = ({ watchlist, toggleWatchlist, liveCoinData }) => {
    const { t } = useTranslation();
    const [activeTab, setActiveTab] = useState<'watchlist' | 'new'>('watchlist');

    const watchlistAssets = useMemo(() => {
        return liveCoinData.filter(coin => watchlist.includes(coin.id));
    }, [liveCoinData, watchlist]);

    const newAndNotableAssets = useMemo(() => {
        // Mocking "new & notable" by taking some non-watchlist, high-volume coins
        return liveCoinData
            .filter(coin => !watchlist.includes(coin.id))
            .sort((a, b) => (b.volume24h ?? 0) - (a.volume24h ?? 0))
            .slice(0, 10);
    }, [liveCoinData, watchlist]);

    const renderContent = () => {
        const assetsToDisplay = activeTab === 'watchlist' ? watchlistAssets : newAndNotableAssets;
        
        if (activeTab === 'watchlist' && watchlistAssets.length === 0) {
            return (
                <div className="text-center py-16">
                    <Star className="mx-auto text-slate-600 w-16 h-16 mb-4" />
                    <h3 className="text-xl font-bold text-slate-50">{t('tokens.emptyWatchlist')}</h3>
                    <p className="text-slate-400 mt-2">{t('tokens.addToWatchlistPrompt')}</p>
                </div>
            );
        }

        return (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
                <AnimatePresence>
                    {assetsToDisplay.map(asset => (
                        <AssetCard 
                            key={asset.id} 
                            asset={asset} 
                            onToggleWatchlist={toggleWatchlist}
                            isWatched={watchlist.includes(asset.id)}
                        />
                    ))}
                </AnimatePresence>
            </div>
        );
    };

    return (
        <div className="p-4 md:p-6 space-y-6">
            <h1 className="text-3xl font-bold bg-gradient-to-r from-accent-cyan to-accent-purple text-transparent bg-clip-text">{t('tokens.title')}</h1>
            
            <div className="flex space-x-2 p-1 bg-slate-800 rounded-lg">
                <button onClick={() => setActiveTab('watchlist')} className={`w-full py-2.5 text-sm font-semibold rounded-md transition-colors ${activeTab === 'watchlist' ? 'bg-slate-700 text-white' : 'text-slate-400'}`}>
                    {t('tokens.watchlist')}
                </button>
                 <button onClick={() => setActiveTab('new')} className={`w-full py-2.5 text-sm font-semibold rounded-md transition-colors ${activeTab === 'new' ? 'bg-slate-700 text-white' : 'text-slate-400'}`}>
                    {t('tokens.newAndNotable')}
                </button>
            </div>

            <AnimatePresence mode="wait">
                <motion.div
                    key={activeTab}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.2 }}
                >
                    {renderContent()}
                </motion.div>
            </AnimatePresence>

        </div>
    );
};

export default TokensScreen;
