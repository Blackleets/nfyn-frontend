import React, { useState, useMemo, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useTranslation } from '../LanguageContext';
import { CommunityUser, CommunityMessage, ChatChannel } from '../types';
import Card from '../components/Card';
import { Search, Send, Hash, MessageSquare, AtSign, BrainCircuit, Lightbulb } from 'lucide-react'; // Added Lightbulb icon
import { ChatbotService } from '../services/chatbotService';

// --- MOCK DATA & CONSTANTS ---
const MOCK_USERS: CommunityUser[] = [
    { id: '1', name: 'Lee renmos', avatarUrl: `https://api.dicebear.com/8.x/bottts/svg?seed=trader-lee`, isOnline: true },
    { id: '2', name: 'Cypher', avatarUrl: `https://api.dicebear.com/8.x/bottts/svg?seed=cypher`, isOnline: true },
    { id: '3', name: 'Glitch', avatarUrl: `https://api.dicebear.com/8.x/bottts/svg?seed=glitch`, isOnline: false },
    { id: '4', name: 'Nova', avatarUrl: `https://api.dicebear.com/8.x/bottts/svg?seed=nova`, isOnline: true },
    { id: '5', name: 'Syntax', avatarUrl: `https://api.dicebear.com/8.x/bottts/svg?seed=syntax`, isOnline: false },
    { id: 'ai', name: 'AI Assistant', avatarUrl: `https://api.dicebear.com/8.x/bottts-neutral/svg?seed=ai`, isOnline: true },
];

const MOCK_MESSAGE_PHRASES: Record<Exclude<ChatChannel, 'DMs'>, string[]> = {
    Global: ["Anyone watching BTC?", "Market is looking choppy today.", "GM everyone!", "What are your top picks for this week?", "Just closed a nice trade on ETH.", "Regulatory news coming out of the US soon."],
    DeFi: ["Check out the new APY on platform X.", "Impermanent loss is a killer.", "Is yield farming still profitable?", "The new governance proposal for XYZ just passed.", "Looking for a good stablecoin farm."],
    NFTs: ["Just minted a new piece!", "Floor price is sweeping up.", "This new collection has amazing art.", "What's the next big mint?", "Utility is key for long-term holds."],
    Memecoins: ["To the moon!", "Which dog coin is next?", "Diamond hands only!", "HODL!", "This is the degen channel, right?", "I just aped into $PEANUT."],
};

const generateMockMessages = (channel: ChatChannel | 'AI', count: number): CommunityMessage[] => {
    const messages: CommunityMessage[] = [];
    
    // Use a generic phrase for DMs since it's a 1-on-1 conversation.
    const phrases = channel in MOCK_MESSAGE_PHRASES 
        ? MOCK_MESSAGE_PHRASES[channel as Exclude<ChatChannel, 'DMs'>] 
        : ["Hey, saw your post in global, wanted to ask...", "Can you explain that strategy you mentioned?", "Thanks for the tip!"];

    // For AI channel, always add the initial AI message.
    if (channel === 'AI' && !messages.some(m => m.id === 'ai-init')) {
        messages.push({ id: 'ai-init', userId: 'ai', text: "Hello! I'm the NFYN AI Assistant. How can I help you with market data, strategies, or general questions?", timestamp: Date.now() - 3600000 });
    }

    for (let i = 0; i < count; i++) {
        const user = MOCK_USERS.filter(u => u.id !== '1' && u.id !== 'ai')[Math.floor(Math.random() * (MOCK_USERS.length - 2))];
        const phrase = phrases[Math.floor(Math.random() * phrases.length)];
        messages.push({
            id: `${channel}-${i}`,
            userId: user.id,
            text: phrase,
            timestamp: Date.now() - (count - i) * 60000 * Math.random() * 5,
        });
    }
    return messages.sort((a, b) => a.timestamp - b.timestamp);
};

// --- SUB-COMPONENTS ---

const MessageBubble: React.FC<{ message: CommunityMessage, user: CommunityUser }> = ({ message, user }) => {
    const isCurrentUser = user.id === '1';
    const isAI = user.id === 'ai';
    const alignment = isCurrentUser ? 'justify-end' : 'justify-start';
    
    let bubbleStyles = '';
    if (isCurrentUser) bubbleStyles = 'bg-accent-purple text-white rounded-br-none';
    else if (isAI) bubbleStyles = 'bg-dark-card text-slate-200 rounded-bl-none border border-accent-cyan';
    else bubbleStyles = 'bg-dark-card text-slate-200 rounded-bl-none';

    const shadow = isCurrentUser ? 'shadow-glow-purple' : isAI ? 'shadow-glow-blue' : '';

    return (
        <motion.div
            layout
            initial={{ opacity: 0, y: 10, x: isCurrentUser ? 10 : -10 }}
            animate={{ opacity: 1, y: 0, x: 0 }}
            exit={{ opacity: 0 }}
            transition={{ type: 'spring', stiffness: 300, damping: 25 }}
            className={`flex items-end gap-2 ${alignment}`}
        >
            {!isCurrentUser && (
                <div className="relative flex-shrink-0">
                    <img src={user.avatarUrl} alt={user.name} className="w-8 h-8 rounded-full" />
                    {user.isOnline && <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-accent-green rounded-full border-2 border-dark-card"></div>}
                </div>
            )}
            <div>
                 {!isCurrentUser && <p className={`text-xs mb-1 ml-2 ${isAI ? 'text-accent-cyan font-semibold' : 'text-slate-400'}`}>{user.name}</p>}
                <div className={`p-3 rounded-2xl max-w-xs md:max-w-md break-words ${bubbleStyles} ${shadow}`}>
                    <p className="text-sm">{message.text}</p>
                </div>
            </div>
        </motion.div>
    );
};

interface CommunityScreenProps {
    initialActiveChannel?: ChatChannel | 'AI';
    onChannelChange: (channel: ChatChannel | 'AI' | undefined) => void;
}

const CommunityScreen: React.FC<CommunityScreenProps> = ({ initialActiveChannel, onChannelChange }) => {
    const { t } = useTranslation();
    const [activeChannel, setActiveChannel] = useState<ChatChannel | 'AI'>(initialActiveChannel || 'Global');
    const [messages, setMessages] = useState<Record<string, CommunityMessage[]>>(() => ({
        Global: generateMockMessages('Global', 20),
        DeFi: generateMockMessages('DeFi', 15),
        NFTs: generateMockMessages('NFTs', 12),
        Memecoins: generateMockMessages('Memecoins', 18),
        DMs: generateMockMessages('DMs', 5),
        AI: generateMockMessages('AI', 1), // Ensures initial AI message
    }));
    const [newMessage, setNewMessage] = useState('');
    const [isAiThinking, setIsAiThinking] = useState(false);
    const [isThinkingModeEnabled, setIsThinkingModeEnabled] = useState(false); // New state for thinking mode
    const messagesEndRef = useRef<HTMLDivElement>(null);
    const users = MOCK_USERS;

    const channels: { id: ChatChannel | 'AI', name: string, icon: React.ReactElement }[] = [
        { id: 'Global', name: t('community.global'), icon: <Hash size={20} /> },
        { id: 'DeFi', name: t('community.defi'), icon: <Hash size={20} /> },
        { id: 'NFTs', name: t('community.nfts'), icon: <Hash size={20} /> },
        { id: 'Memecoins', name: t('community.memecoins'), icon: <Hash size={20} /> },
        { id: 'AI', name: t('aiAssistant'), icon: <BrainCircuit size={20} /> }, // AI Assistant added to main channels
    ];
    
    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages, activeChannel, isAiThinking]); // Added isAiThinking to dependencies for smooth scroll

    useEffect(() => {
        if (initialActiveChannel && initialActiveChannel !== activeChannel) {
            setActiveChannel(initialActiveChannel);
            onChannelChange(undefined); // Reset in parent after use
        }
    }, [initialActiveChannel, activeChannel, onChannelChange]);

    // Simulate other users talking in public channels
    useEffect(() => {
        const publicChannels = Object.keys(MOCK_MESSAGE_PHRASES);
        if (publicChannels.includes(activeChannel)) {
            const interval = setInterval(() => {
                const user = users.filter(u => u.id !== '1' && u.id !== 'ai')[Math.floor(Math.random() * (users.length - 2))];
                const phrasesForChannel = MOCK_MESSAGE_PHRASES[activeChannel as keyof typeof MOCK_MESSAGE_PHRASES];
                const text = phrasesForChannel[Math.floor(Math.random() * phrasesForChannel.length)];
                
                const msg: CommunityMessage = {
                    id: `msg-${Date.now()}`,
                    userId: user.id,
                    text: text,
                    timestamp: Date.now(),
                };
                setMessages(prev => ({ ...prev, [activeChannel]: [...prev[activeChannel] || [], msg] }));
            }, 15000); // New message every 15 seconds
            return () => clearInterval(interval);
        }
    }, [activeChannel, users]);


    const handleSendMessage = async (e: React.FormEvent) => {
        e.preventDefault();
        if (newMessage.trim() === '') return;

        const userMsg: CommunityMessage = {
            id: `msg-${Date.now()}`,
            userId: '1',
            text: newMessage,
            timestamp: Date.now(),
        };

        setMessages(prev => ({ ...prev, [activeChannel]: [...(prev[activeChannel] || []), userMsg] }));
        const currentMessage = newMessage;
        setNewMessage('');

        if (activeChannel === 'AI') {
            setIsAiThinking(true);
            const aiResponse = await ChatbotService.getResponse(currentMessage, isThinkingModeEnabled); // Pass thinking mode
            const aiMsg: CommunityMessage = {
                id: `msg-${Date.now()}-ai`,
                userId: 'ai',
                text: aiResponse,
                timestamp: Date.now()
            };
            setMessages(prev => ({ ...prev, AI: [...prev.AI, aiMsg] }));
            setIsAiThinking(false);
        }
    };
    
    const currentMessages = messages[activeChannel] || [];
    
    return (
        <div className="p-4 md:p-6 h-[calc(100vh-104px)] md:h-[calc(100vh-64px)]">
            <div className="grid grid-cols-12 gap-6 h-full">
                <div className="col-span-12 md:col-span-3 lg:col-span-2">
                    <Card className="h-full p-3 flex flex-col">
                        <h2 className="text-lg font-bold mb-4 px-2 font-orbitron">Channels</h2>
                        <div className="space-y-1">
                            {channels.map(ch => (
                                <button key={ch.id} onClick={() => setActiveChannel(ch.id)}
                                    className={`w-full flex items-center gap-2 p-2 rounded-lg text-sm font-semibold transition-colors ${activeChannel === ch.id ? 'bg-accent-cyan/10 text-accent-cyan' : 'text-slate-400 hover:bg-slate-800'}`}>
                                    {ch.icon} {ch.name}
                                </button>
                            ))}
                        </div>
                        <div className="mt-auto pt-4">
                            <h2 className="text-lg font-bold mb-2 px-2 font-orbitron">DMs</h2>
                            <div className="space-y-1">
                                <button onClick={() => setActiveChannel('DMs')}
                                    className={`w-full flex items-center gap-2 p-2 rounded-lg text-sm font-semibold transition-colors ${activeChannel === 'DMs' ? 'bg-accent-cyan/10 text-accent-cyan' : 'text-slate-400 hover:bg-slate-800'}`}>
                                    <AtSign size={20} /> Cypher
                                </button>
                            </div>
                        </div>
                    </Card>
                </div>
                <div className="col-span-12 md:col-span-9 lg:col-span-7">
                    <Card className="h-full flex flex-col p-0">
                        <header className="p-4 border-b border-slate-800 flex-shrink-0 flex items-center justify-between">
                            <h1 className="text-xl font-bold">{channels.find(c => c.id === activeChannel)?.name || 'Cypher'}</h1>
                            {activeChannel === 'AI' && (
                                <div className="flex items-center gap-2">
                                    <Lightbulb size={18} className={`${isThinkingModeEnabled ? 'text-accent-purple' : 'text-slate-500'}`} />
                                    <label htmlFor="thinking-mode-toggle" className="flex items-center cursor-pointer">
                                        <div className="relative">
                                            <input
                                                type="checkbox"
                                                id="thinking-mode-toggle"
                                                className="sr-only"
                                                checked={isThinkingModeEnabled}
                                                onChange={() => setIsThinkingModeEnabled(!isThinkingModeEnabled)}
                                            />
                                            <motion.div
                                                className={`block w-10 h-6 rounded-full transition-colors duration-200 ease-in-out ${isThinkingModeEnabled ? 'bg-accent-purple' : 'bg-slate-700'}`}
                                            ></motion.div>
                                            <motion.div
                                                className="dot absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform duration-200 ease-in-out shadow"
                                                initial={false}
                                                animate={{ x: isThinkingModeEnabled ? '1rem' : '0rem' }}
                                                transition={{ type: 'spring', stiffness: 700, damping: 30 }}
                                            ></motion.div>
                                        </div>
                                        <span className="ml-2 text-sm font-medium text-slate-400">{t('thinkingModeToggle')}</span>
                                    </label>
                                    <motion.div
                                        initial={{ opacity: 0, x: -10 }}
                                        animate={{ opacity: isThinkingModeEnabled ? 1 : 0, x: isThinkingModeEnabled ? 0 : -10 }}
                                        transition={{ duration: 0.2 }}
                                        className="text-xs text-slate-500 ml-2 max-w-[150px] italic"
                                    >
                                        {t('thinkingModeDescription')}
                                    </motion.div>
                                </div>
                            )}
                        </header>
                        <div className="flex-grow p-4 overflow-y-auto space-y-4">
                            <AnimatePresence>
                                {currentMessages.map(msg => {
                                    const user = users.find(u => u.id === msg.userId);
                                    if (!user) return null;
                                    return <MessageBubble key={msg.id} message={msg} user={user} />;
                                })}
                            </AnimatePresence>
                            {isAiThinking && (
                                <motion.div layout initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-end gap-2 justify-start">
                                    <img src={MOCK_USERS.find(u => u.id === 'ai')?.avatarUrl} alt="AI" className="w-8 h-8 rounded-full" />
                                    <div className="p-3 rounded-2xl rounded-bl-none bg-dark-card border border-accent-cyan shadow-glow-blue">
                                        <div className="flex items-center gap-1.5">
                                            <motion.div className="w-2 h-2 bg-accent-cyan rounded-full" animate={{ scale: [1, 1.2, 1], opacity: [0.5, 1, 0.5] }} transition={{ duration: 1, repeat: Infinity }} />
                                            <motion.div className="w-2 h-2 bg-accent-cyan rounded-full" animate={{ scale: [1, 1.2, 1], opacity: [0.5, 1, 0.5] }} transition={{ duration: 1, repeat: Infinity, delay: 0.2 }} />
                                            <motion.div className="w-2 h-2 bg-accent-cyan rounded-full" animate={{ scale: [1, 1.2, 1], opacity: [0.5, 1, 0.5] }} transition={{ duration: 1, repeat: Infinity, delay: 0.4 }} />
                                        </div>
                                        <p className="text-sm text-slate-300 ml-1 mt-1">{isThinkingModeEnabled ? t('aiThinkingDeeply') : 'AI is typing...'}</p>
                                    </div>
                                </motion.div>
                            )}
                            <div ref={messagesEndRef} />
                        </div>
                        <form onSubmit={handleSendMessage} className="p-4 border-t border-slate-800 flex-shrink-0">
                            <div className="relative">
                                <input type="text" value={newMessage} onChange={e => setNewMessage(e.target.value)}
                                    placeholder={t('community.sendMessage')}
                                    className="w-full bg-slate-800 border-2 border-slate-700 focus:border-accent-purple focus:ring-0 rounded-lg pr-12 pl-4 py-3" />
                                <button type="submit" disabled={isAiThinking} className="absolute right-3 top-1/2 -translate-y-1/2 p-2 text-slate-400 hover:text-accent-purple transition-colors disabled:opacity-50">
                                    <Send size={20} />
                                </button>
                            </div>
                        </form>
                    </Card>
                </div>
                <div className="hidden lg:block col-span-3">
                    <Card className="h-full p-3">
                        <h2 className="text-lg font-bold mb-4 px-2 font-orbitron">{t('community.online')} ({users.filter(u=>u.isOnline).length})</h2>
                        <div className="space-y-2">
                             {users.filter(u=>u.isOnline).map(user => (
                                <div key={user.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-slate-800">
                                    <img src={user.avatarUrl} alt={user.name} className="w-8 h-8 rounded-full" />
                                    <span className="font-semibold text-sm">{user.name}</span>
                                </div>
                             ))}
                        </div>
                    </Card>
                </div>
            </div>
        </div>
    );
};

export default CommunityScreen;