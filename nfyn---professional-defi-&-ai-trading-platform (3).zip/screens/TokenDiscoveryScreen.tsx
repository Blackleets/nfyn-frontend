import React, { useState, useMemo, useEffect, useCallback, useRef } from 'react';
import Card from '../components/Card';
import { LiveCoin, NewTokenLaunch, AITokenAnalysisResult, TokenNetwork, TokenAge } from '../types';
import { useTranslation } from '../LanguageContext';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, ChevronDown, Star, Zap, BrainCircuit, ShieldCheck, TrendingUp, Filter, BarChart, DollarSign, Clock, Check, Scale, X, CheckSquare, Square } from 'lucide-react';
import { PubliApisService } from '../services/publiApisService';
import { GeminiService } from '../services/geminiService';
import SkeletonLoader from '../components/SkeletonLoader';
import { formatDistanceToNow } from 'date-fns';

interface TokenLaunchCardProps {
    token: NewTokenLaunch;
    isWatched: boolean;
    onToggleWatchlist: (id: string) => void;
    aiAnalysisLoading: boolean;
    isSelected: boolean;
    onToggleSelect: (id: string) => void;
}

const formatCurrency = (value: number) => {
    return value.toLocaleString('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 0, maximumFractionDigits: 0 });
};

const formatPrice = (price: number) => {
    if (price > 100) return price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    if (price < 0.0001) return price.toLocaleString('en-US', { minimumFractionDigits: 8, maximumFractionDigits: 8 });
    if (price < 0.1) return price.toLocaleString('en-US', { minimumFractionDigits: 6, maximumFractionDigits: 6 });
    return price.toLocaleString('en-US', { minimumFractionDigits: 4, maximumFractionDigits: 4 });
};

const getRatingStyles = (rating: AITokenAnalysisResult['safety'] | AITokenAnalysisResult['potential']): { bg: string; text: string; } => {
    switch (rating) {
        case 'Very High': return { bg: 'bg-teal-500/20', text: 'text-teal-400' };
        case 'High': return { bg: 'bg-green-500/20', text: 'text-green-400' };
        case 'Medium': return { bg: 'bg-yellow-500/20', text: 'text-yellow-400' };
        case 'Low': return { bg: 'bg-orange-500/20', text: 'text-orange-400' };
        case 'Very Low': return { bg: 'bg-red-500/20', text: 'text-red-500' };
        default: return { bg: 'bg-slate-700', text: 'text-slate-400' };
    }
};

const getRatingMeterProps = (rating: AITokenAnalysisResult['safety'] | AITokenAnalysisResult['potential']): { width: string; color: string; } => {
    switch (rating) {
        case 'Very High': return { width: '100%', color: 'bg-teal-400' };
        case 'High': return { width: '80%', color: 'bg-green-400' };
        case 'Medium': return { width: '60%', color: 'bg-yellow-400' };
        case 'Low': return { width: '40%', color: 'bg-orange-400' };
        case 'Very Low': return { width: '20%', color: 'bg-red-400' };
        default: return { width: '0%', color: 'bg-slate-500' };
    }
};

const RatingMeter: React.FC<{
    label: string;
    icon: React.ReactElement;
    rating: AITokenAnalysisResult['safety'] | AITokenAnalysisResult['potential'];
}> = ({ label, icon, rating }) => {
    const { width, color } = getRatingMeterProps(rating);
    const styles = getRatingStyles(rating);

    return (
        <div>
            <div className="flex justify-between items-center mb-1">
                <span className="text-xs font-semibold text-slate-400 flex items-center gap-1.5">{icon} {label}</span>
                <span className={`text-xs font-bold ${styles.text}`}>{rating}</span>
            </div>
            <div className="w-full bg-slate-700 rounded-full h-1.5">
                <motion.div
                    className={`h-1.5 rounded-full ${color}`}
                    initial={{ width: 0 }}
                    animate={{ width }}
                    transition={{ duration: 0.5, ease: "easeOut" }}
                />
            </div>
        </div>
    );
};


const TokenLaunchCard: React.FC<TokenLaunchCardProps> = ({ token, isWatched, onToggleWatchlist, aiAnalysisLoading, isSelected, onToggleSelect }) => {
    const { t } = useTranslation();
    const isPositiveChange = token.change24h >= 0;

    const ageInHours = (Date.now() - token.launchDate) / (1000 * 60 * 60);
    const displayAge = ageInHours < 24 
        ? `${Math.floor(ageInHours)}h ago` 
        : formatDistanceToNow(new Date(token.launchDate), { addSuffix: true });

    return (
        <motion.div
            layout
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            transition={{ type: 'spring', stiffness: 300, damping: 25 }}
            whileHover={{ scale: 1.03, y: -3, boxShadow: '0 0 20px rgba(0, 240, 255, 0.2)' }}
            className={`relative rounded-2xl ${isSelected ? 'ring-2 ring-accent-cyan ring-offset-2 ring-offset-slate-900' : ''}`}
        >
            <Card className="p-4 flex flex-col justify-between h-full" highlight={isPositiveChange ? 'green' : 'red'}>
                <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                        <img src={token.logoUrl} alt={token.name} className="w-10 h-10 rounded-full flex-shrink-0" />
                        <div>
                            <p className="font-bold text-white text-lg">{token.symbol}</p>
                            <p className="text-xs text-slate-400">{token.name}</p>
                        </div>
                    </div>
                    <div className="flex gap-2">
                        <button onClick={(e) => { e.stopPropagation(); onToggleSelect(token.id); }} className="text-slate-500 hover:text-accent-cyan transition-colors z-10">
                            {isSelected ? <CheckSquare size={20} className="text-accent-cyan" /> : <Square size={20} />}
                        </button>
                        <button onClick={(e) => { e.stopPropagation(); onToggleWatchlist(token.id); }} className="text-slate-500 hover:text-glovo-yellow transition-colors z-10">
                            <Star size={20} className={isWatched ? 'fill-current text-glovo-yellow' : ''} />
                        </button>
                    </div>
                </div>
                
                <div className="space-y-1 text-sm flex-grow">
                    <div className="flex justify-between">
                        <span className="text-slate-400">{t('tokenDiscovery.price')}</span>
                        <span className="font-mono text-white">${formatPrice(token.price)}</span>
                    </div>
                    <div className="flex justify-between">
                        <span className="text-slate-400">{t('tokenDiscovery.change24h')}</span>
                        <span className={`font-mono font-bold ${isPositiveChange ? 'text-accent-green' : 'text-accent-red'}`}>
                            {isPositiveChange ? '+' : ''}{token.change24h.toFixed(2)}%
                        </span>
                    </div>
                     <div className="flex justify-between">
                        <span className="text-slate-400">{t('tokenDiscovery.marketCap')}</span>
                        <span className="font-mono text-white">{formatCurrency(token.marketCap)}</span>
                    </div>
                     <div className="flex justify-between">
                        <span className="text-slate-400">{t('tokenDiscovery.network')}</span>
                        <span className="font-mono text-white">{token.network}</span>
                    </div>
                    <div className="flex justify-between">
                        <span className="text-slate-400">{t('tokenDiscovery.minLiquidity')}</span>
                        <span className="font-mono text-white">{formatCurrency(token.liquidity)}</span>
                    </div>
                    <div className="flex justify-between">
                        <span className="text-slate-400">{t('tokenDiscovery.volume24h')}</span>
                        <span className="font-mono text-white">{formatCurrency(token.volume24h)}</span>
                    </div>
                    <div className="flex justify-between">
                        <span className="text-slate-400">{t('tokenDiscovery.age')}</span>
                        <span className="font-mono text-white">{displayAge}</span>
                    </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800">
                    <h4 className="text-sm font-bold text-accent-purple flex items-center gap-2 mb-2"><BrainCircuit size={16}/> {t('tokenDiscovery.aiAnalysis')}</h4>
                    {aiAnalysisLoading ? (
                        <div className="space-y-3">
                            <SkeletonLoader className="h-3 w-1/4 rounded mb-1" />
                            <SkeletonLoader className="h-1.5 w-full rounded" />
                             <div className="pt-1"><SkeletonLoader className="h-3 w-1/4 rounded mb-1" />
                            <SkeletonLoader className="h-1.5 w-full rounded" /></div>
                        </div>
                    ) : token.aiAnalysis ? (
                        <div className="space-y-3">
                            <RatingMeter
                                label={t('tokenDiscovery.safety')}
                                icon={<ShieldCheck size={14} />}
                                rating={token.aiAnalysis.safety}
                            />
                            <RatingMeter
                                label={t('tokenDiscovery.potential')}
                                icon={<TrendingUp size={14} />}
                                rating={token.aiAnalysis.potential}
                            />
                            <p className="text-xs text-slate-500 italic pt-1 line-clamp-2">{t('reasoning')}: {token.aiAnalysis.reasoning}</p>
                        </div>
                    ) : (
                        <p className="text-xs text-slate-500 italic">{t('tokenDiscovery.noAiAnalysis')}</p>
                    )}
                </div>
            </Card>
        </motion.div>
    );
};

const ComparisonModal: React.FC<{ isOpen: boolean; onClose: () => void; tokens: NewTokenLaunch[] }> = ({ isOpen, onClose, tokens }) => {
    if (!isOpen) return null;

    const metrics = [
        { label: 'Price', key: 'price', format: (t: NewTokenLaunch) => `$${formatPrice(t.price)}` },
        { label: '24h Change', key: 'change24h', format: (t: NewTokenLaunch) => <span className={t.change24h >= 0 ? 'text-accent-green' : 'text-accent-red'}>{t.change24h >= 0 ? '+' : ''}{t.change24h.toFixed(2)}%</span> },
        { label: 'Market Cap', key: 'marketCap', format: (t: NewTokenLaunch) => formatCurrency(t.marketCap) },
        { label: 'Volume 24h', key: 'volume24h', format: (t: NewTokenLaunch) => formatCurrency(t.volume24h) },
        { label: 'Liquidity', key: 'liquidity', format: (t: NewTokenLaunch) => formatCurrency(t.liquidity) },
        { label: 'Network', key: 'network', format: (t: NewTokenLaunch) => t.network },
        { label: 'Age', key: 'launchDate', format: (t: NewTokenLaunch) => formatDistanceToNow(new Date(t.launchDate), { addSuffix: true }) },
        { label: 'AI Safety', key: 'aiSafety', format: (t: NewTokenLaunch) => t.aiAnalysis ? <span className={getRatingStyles(t.aiAnalysis.safety).text}>{t.aiAnalysis.safety}</span> : 'N/A' },
        { label: 'AI Potential', key: 'aiPotential', format: (t: NewTokenLaunch) => t.aiAnalysis ? <span className={getRatingStyles(t.aiAnalysis.potential).text}>{t.aiAnalysis.potential}</span> : 'N/A' },
    ];

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm" onClick={onClose}>
            <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="bg-dark-card border border-slate-700 rounded-2xl shadow-2xl w-full max-w-5xl h-[80vh] overflow-hidden flex flex-col m-4"
                onClick={e => e.stopPropagation()}
            >
                <div className="flex justify-between items-center p-4 border-b border-slate-800">
                    <h2 className="text-xl font-bold text-white flex items-center gap-2"><Scale size={24} className="text-accent-cyan" /> Token Comparison</h2>
                    <button onClick={onClose} className="p-2 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white"><X size={20} /></button>
                </div>
                <div className="flex-grow overflow-auto p-4">
                    <div className="min-w-max">
                        <div className="grid gap-4" style={{ gridTemplateColumns: `150px repeat(${tokens.length}, minmax(180px, 1fr))` }}>
                            {/* Header Row */}
                            <div className="font-bold text-slate-500 p-2 flex items-end border-b border-slate-700">Metric</div>
                            {tokens.map(token => (
                                <div key={token.id} className="p-2 flex flex-col items-center border-b border-slate-700 pb-4">
                                    <img src={token.logoUrl} alt={token.name} className="w-12 h-12 rounded-full mb-2" />
                                    <p className="font-bold text-white text-center">{token.symbol}</p>
                                    <p className="text-xs text-slate-400 text-center">{token.name}</p>
                                </div>
                            ))}

                            {/* Data Rows */}
                            {metrics.map((metric, idx) => (
                                <React.Fragment key={metric.label}>
                                    <div className={`p-2 font-semibold text-slate-400 flex items-center ${idx % 2 === 0 ? 'bg-slate-800/30' : ''}`}>{metric.label}</div>
                                    {tokens.map(token => (
                                        <div key={`${token.id}-${metric.label}`} className={`p-2 font-mono text-slate-200 flex items-center justify-center ${idx % 2 === 0 ? 'bg-slate-800/30' : ''}`}>
                                            {metric.format(token)}
                                        </div>
                                    ))}
                                </React.Fragment>
                            ))}
                        </div>
                    </div>
                </div>
            </motion.div>
        </div>
    );
};

interface TokenDiscoveryScreenProps {
    watchlist: string[];
    toggleWatchlist: (coinId: string) => void;
    liveCoinData: LiveCoin[];
}

const TokenDiscoveryScreen: React.FC<TokenDiscoveryScreenProps> = ({ watchlist, toggleWatchlist, liveCoinData }) => {
    const { t } = useTranslation();
    const [activeTab, setActiveTab] = useState<'watchlist' | 'newLaunches'>('newLaunches');
    const [newLaunches, setNewLaunches] = useState<NewTokenLaunch[]>([]);
    const [isLoadingLaunches, setIsLoadingLaunches] = useState(true);
    const [aiAnalysisStatus, setAiAnalysisStatus] = useState<Record<string, 'loading' | 'done' | 'error'>>({});

    // Comparison State
    const [selectedForComparison, setSelectedForComparison] = useState<Set<string>>(new Set());
    const [isComparisonModalOpen, setIsComparisonModalOpen] = useState(false);

    // Filter states
    const [selectedNetworks, setSelectedNetworks] = useState<TokenNetwork[]>([]);
    const [isNetworkDropdownOpen, setIsNetworkDropdownOpen] = useState(false);
    const networkDropdownRef = useRef<HTMLDivElement>(null);

    const [ageFilter, setAgeFilter] = useState<TokenAge | 'All'>('All');
    const [minLiquidity, setMinLiquidity] = useState<number | ''>('');
    const [minVolume, setMinVolume] = useState<number | ''>('');
    const [minMarketCap, setMinMarketCap] = useState<number | ''>('');
    const [maxMarketCap, setMaxMarketCap] = useState<number | ''>('');

    const networks: TokenNetwork[] = ['Ethereum', 'Solana', 'BSC', 'Arbitrum', 'Polygon'];
    const ages: (TokenAge | 'All')[] = ['All', 'new', '1d', '7d', '30d'];

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (networkDropdownRef.current && !networkDropdownRef.current.contains(event.target as Node)) {
                setIsNetworkDropdownOpen(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, []);

    const handleNetworkToggle = (network: TokenNetwork) => {
        setSelectedNetworks(prev =>
            prev.includes(network)
                ? prev.filter(n => n !== network)
                : [...prev, network]
        );
    };

    const fetchNewLaunches = useCallback(async () => {
        setIsLoadingLaunches(true);
        const fetchedLaunches = await PubliApisService.getNewTokenLaunches();
        setNewLaunches(fetchedLaunches);
        setIsLoadingLaunches(false);
    
        // Trigger AI analysis for all tokens in a single batch
        if (fetchedLaunches.length > 0) {
            fetchedLaunches.forEach(token => {
                setAiAnalysisStatus(prev => ({ ...prev, [token.id]: 'loading' }));
            });
            try {
                const analyses = await GeminiService.getBulkTokenAnalysis(fetchedLaunches);
                setNewLaunches(prev => prev.map(token => ({
                    ...token,
                    aiAnalysis: analyses[token.id] || token.aiAnalysis,
                })));
                Object.keys(analyses).forEach(tokenId => {
                    setAiAnalysisStatus(prev => ({ ...prev, [tokenId]: 'done' }));
                });
            } catch (error) {
                console.error(`Bulk AI analysis failed:`, error);
                fetchedLaunches.forEach(token => {
                    setAiAnalysisStatus(prev => ({ ...prev, [token.id]: 'error' }));
                });
            }
        }
    }, []);

    useEffect(() => {
        fetchNewLaunches();
        const interval = setInterval(fetchNewLaunches, 5 * 60 * 1000); // Refresh every 5 minutes
        return () => clearInterval(interval);
    }, [fetchNewLaunches]);

    const watchlistAssets = useMemo(() => {
        return liveCoinData.filter(coin => watchlist.includes(coin.id));
    }, [liveCoinData, watchlist]);

    const normalizeLiveCoin = (coin: LiveCoin): NewTokenLaunch => ({
        id: coin.id,
        name: coin.name,
        symbol: coin.symbol,
        logoUrl: coin.logoUrl,
        network: 'Ethereum', // Fallback for live coins without explicit network data
        price: coin.price,
        change24h: coin.change24h,
        marketCap: coin.marketCap || 0,
        liquidity: coin.volume24h || 0, // Using volume as proxy if liquidity missing
        volume24h: coin.volume24h || 0,
        launchDate: Date.now() - 1000 * 60 * 60 * 24 * 365, // Assume old
        contractAddress: 'N/A',
        description: 'Asset from Live Market Data',
        hasAudit: true,
        aiAnalysis: undefined, // Live coins don't have this pre-fetched here
    });

    const filteredLaunches = useMemo(() => {
        return newLaunches.filter(token => {
            if (selectedNetworks.length > 0 && !selectedNetworks.includes(token.network)) return false;
            if (minLiquidity !== '' && token.liquidity < minLiquidity) return false;
            if (minVolume !== '' && token.volume24h < minVolume) return false;
            if (minMarketCap !== '' && token.marketCap < minMarketCap) return false;
            if (maxMarketCap !== '' && token.marketCap > maxMarketCap) return false;

            const ageHours = (Date.now() - token.launchDate) / (1000 * 60 * 60);
            if (ageFilter === 'new' && ageHours > 1) return false;
            if (ageFilter === '1d' && ageHours > 24) return false;
            if (ageFilter === '7d' && ageHours > 7 * 24) return false;
            if (ageFilter === '30d' && ageHours > 30 * 24) return false;

            return true;
        });
    }, [newLaunches, selectedNetworks, minLiquidity, minVolume, ageFilter, minMarketCap, maxMarketCap]);

    const toggleComparisonSelection = (id: string) => {
        setSelectedForComparison(prev => {
            const newSet = new Set(prev);
            if (newSet.has(id)) {
                newSet.delete(id);
            } else {
                if (newSet.size >= 5) {
                    // Ideally show a toast here: "Max 5 tokens for comparison"
                    return newSet;
                }
                newSet.add(id);
            }
            return newSet;
        });
    };

    const comparisonTokens = useMemo(() => {
        const allTokens = [...newLaunches, ...watchlistAssets.map(normalizeLiveCoin)];
        return allTokens.filter(t => selectedForComparison.has(t.id));
    }, [newLaunches, watchlistAssets, selectedForComparison]);

    const renderContent = () => {
        if (activeTab === 'watchlist') {
            if (watchlistAssets.length === 0) {
                return (
                    <div className="text-center py-16">
                        <Star className="mx-auto text-slate-600 w-16 h-16 mb-4" />
                        <h3 className="text-xl font-bold text-slate-50">{t('tokenDiscovery.emptyWatchlist')}</h3>
                        <p className="text-slate-400 mt-2">{t('tokenDiscovery.addToWatchlistPrompt')}</p>
                    </div>
                );
            }
            return (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    <AnimatePresence>
                        {watchlistAssets.map(asset => (
                            <TokenLaunchCard 
                                key={asset.id}
                                token={normalizeLiveCoin(asset)}
                                isWatched={watchlist.includes(asset.id)}
                                onToggleWatchlist={toggleWatchlist}
                                aiAnalysisLoading={false}
                                isSelected={selectedForComparison.has(asset.id)}
                                onToggleSelect={toggleComparisonSelection}
                            />
                        ))}
                    </AnimatePresence>
                </div>
            );
        } else { // 'newLaunches' tab
            if (isLoadingLaunches) {
                return (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                        {[...Array(8)].map((_, i) => <SkeletonLoader key={i} className="h-72 rounded-2xl" />)}
                    </div>
                );
            }
            if (filteredLaunches.length === 0) {
                 return (
                    <div className="text-center py-16">
                        <BrainCircuit className="mx-auto text-slate-600 w-16 h-16 mb-4" />
                        <h3 className="text-xl font-bold text-slate-50">{t('tokenDiscovery.noLaunchesMatchFilter')}</h3>
                        <p className="text-slate-400 mt-2">{t('tokenDiscovery.adjustFilters')}</p>
                    </div>
                );
            }
            return (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    <AnimatePresence>
                        {filteredLaunches.map(token => (
                            <TokenLaunchCard 
                                key={token.id} 
                                token={token} 
                                isWatched={watchlist.includes(token.id)} 
                                onToggleWatchlist={toggleWatchlist}
                                aiAnalysisLoading={aiAnalysisStatus[token.id] === 'loading'}
                                isSelected={selectedForComparison.has(token.id)}
                                onToggleSelect={toggleComparisonSelection}
                            />
                        ))}
                    </AnimatePresence>
                </div>
            );
        }
    };

    return (
        <div className="p-4 md:p-6 space-y-6 relative">
            <h1 className="text-3xl font-bold bg-gradient-to-r from-accent-cyan to-accent-purple text-transparent bg-clip-text flex items-center gap-3">
                <Zap size={32} className="text-accent-purple"/> {t('tokenDiscovery.title')}
            </h1>
            
            <Card className="p-4">
                <div className="flex flex-wrap items-center gap-4">
                    <div className="flex space-x-2 p-1 bg-slate-800 rounded-lg flex-grow max-w-sm">
                        <button onClick={() => setActiveTab('newLaunches')} className={`w-full py-2.5 text-sm font-semibold rounded-md transition-colors ${activeTab === 'newLaunches' ? 'bg-slate-700 text-white' : 'text-slate-400'}`}>
                            {t('tokenDiscovery.newLaunches')}
                        </button>
                        <button onClick={() => setActiveTab('watchlist')} className={`w-full py-2.5 text-sm font-semibold rounded-md transition-colors ${activeTab === 'watchlist' ? 'bg-slate-700 text-white' : 'text-slate-400'}`}>
                            {t('tokenDiscovery.watchlist')}
                        </button>
                    </div>
                </div>
                 {activeTab === 'newLaunches' && (
                    <div className="mt-4 pt-4 border-t border-slate-800 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                        {/* Network Filter */}
                        <div className="relative" ref={networkDropdownRef}>
                            <button
                                onClick={() => setIsNetworkDropdownOpen(prev => !prev)}
                                className="w-full flex items-center justify-between appearance-none bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm focus:border-accent-cyan focus:ring-0"
                            >
                                <span className="flex items-center gap-2">
                                    <Filter className="w-4 h-4 text-slate-400" />
                                    {selectedNetworks.length === 0
                                        ? t('tokenDiscovery.network')
                                        : `${t('tokenDiscovery.network')} (${selectedNetworks.length})`
                                    }
                                </span>
                                <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${isNetworkDropdownOpen ? 'rotate-180' : ''}`} />
                            </button>
                            <AnimatePresence>
                                {isNetworkDropdownOpen && (
                                    <motion.div
                                        initial={{ opacity: 0, y: -10 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        exit={{ opacity: 0, y: -10 }}
                                        className="absolute top-full mt-2 w-full bg-dark-card border border-slate-700 rounded-lg shadow-lg z-30 p-2"
                                    >
                                        {networks.map(net => {
                                            const isSelected = selectedNetworks.includes(net);
                                            return (
                                                <button
                                                    key={net}
                                                    onClick={() => handleNetworkToggle(net)}
                                                    className="w-full flex items-center justify-between text-left p-2 rounded-md hover:bg-slate-800 transition-colors"
                                                >
                                                    <span className="text-sm">{net}</span>
                                                    {isSelected && <Check size={16} className="text-accent-cyan" />}
                                                </button>
                                            )
                                        })}
                                        {selectedNetworks.length > 0 && (
                                            <button
                                                onClick={() => setSelectedNetworks([])}
                                                className="w-full text-center text-xs text-slate-400 p-2 mt-1 hover:text-white"
                                            >
                                                {t('tokenDiscovery.clearSelection')}
                                            </button>
                                        )}
                                    </motion.div>
                                )}
                            </AnimatePresence>
                        </div>
                        {/* Age Filter */}
                        <div className="relative">
                            <Clock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                            <select
                                value={ageFilter}
                                onChange={e => setAgeFilter(e.target.value as TokenAge | 'All')}
                                className="w-full appearance-none bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 pl-9 text-sm focus:border-accent-cyan focus:ring-0"
                            >
                                {ages.map(age => <option key={age} value={age} className="bg-slate-900">{t(`tokenDiscovery.ageOptions.${age}`)}</option>)}
                            </select>
                            <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                        </div>
                        {/* Min Liquidity */}
                        <div className="relative">
                            <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                            <input
                                type="number"
                                placeholder={t('tokenDiscovery.minLiquidity')}
                                value={minLiquidity}
                                onChange={e => setMinLiquidity(e.target.value === '' ? '' : parseFloat(e.target.value))}
                                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 pl-9 text-sm focus:border-accent-cyan focus:ring-0"
                            />
                        </div>
                        {/* Min Volume */}
                        <div className="relative">
                            <BarChart className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                            <input
                                type="number"
                                placeholder={t('tokenDiscovery.minVolume')}
                                value={minVolume}
                                onChange={e => setMinVolume(e.target.value === '' ? '' : parseFloat(e.target.value))}
                                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 pl-9 text-sm focus:border-accent-cyan focus:ring-0"
                            />
                        </div>
                        {/* Min Market Cap */}
                        <div className="relative">
                            <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                            <input
                                type="number"
                                placeholder={t('tokenDiscovery.minMarketCap')}
                                value={minMarketCap}
                                onChange={e => setMinMarketCap(e.target.value === '' ? '' : parseFloat(e.target.value))}
                                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 pl-9 text-sm focus:border-accent-cyan focus:ring-0"
                            />
                        </div>
                        {/* Max Market Cap */}
                        <div className="relative">
                            <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                            <input
                                type="number"
                                placeholder={t('tokenDiscovery.maxMarketCap')}
                                value={maxMarketCap}
                                onChange={e => setMaxMarketCap(e.target.value === '' ? '' : parseFloat(e.target.value))}
                                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 pl-9 text-sm focus:border-accent-cyan focus:ring-0"
                            />
                        </div>
                    </div>
                )}
            </Card>

            <AnimatePresence mode="wait">
                <motion.div
                    key={activeTab}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.2 }}
                >
                    {renderContent()}
                </motion.div>
            </AnimatePresence>

            {/* Floating Comparison Button */}
            <AnimatePresence>
                {selectedForComparison.size > 0 && (
                    <motion.button
                        initial={{ y: 100, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        exit={{ y: 100, opacity: 0 }}
                        onClick={() => setIsComparisonModalOpen(true)}
                        className="fixed bottom-24 md:bottom-8 left-1/2 -translate-x-1/2 z-40 bg-accent-cyan text-slate-900 font-bold py-3 px-8 rounded-full shadow-lg shadow-cyan-500/30 flex items-center gap-3 hover:scale-105 transition-transform"
                    >
                        <Scale size={20} />
                        <span>Compare ({selectedForComparison.size})</span>
                    </motion.button>
                )}
            </AnimatePresence>

            <ComparisonModal 
                isOpen={isComparisonModalOpen} 
                onClose={() => setIsComparisonModalOpen(false)} 
                tokens={comparisonTokens} 
            />
        </div>
    );
};

export default TokenDiscoveryScreen;