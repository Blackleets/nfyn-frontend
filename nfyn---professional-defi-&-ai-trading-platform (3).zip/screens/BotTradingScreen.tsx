


import React, { useState, useEffect, useMemo } from 'react';
import Card from '../components/Card';
import { BotEvent, ModuleState, ModuleName, ScalpingRiskProfile, LiveCoin } from '../types';
import { Zap, DatabaseZap, BarChartHorizontal, Combine, BrainCircuit, Grid, Crosshair, Settings } from 'lucide-react';
import Modal from '../components/Modal';
import { FaRobot, FaTrophy } from 'react-icons/fa';
import { motion, AnimatePresence } from 'framer-motion';
import { useTranslation } from '../LanguageContext';
import { GeminiService } from '../services/geminiService';
import ScalpingModule from '../components/trading/ScalpingModule';
import FarmingModule from '../components/trading/FarmingModule';
import LpModule from '../components/trading/LpModule';
import FuturesModule from '../components/trading/FuturesModule';

const formatCurrency = (value: number) => {
    return value.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
};

const PnlText: React.FC<{ value: number, className?: string }> = ({ value, className }) => {
    const isProfit = value >= 0;
    return (
        <span className={`font-bold ${isProfit ? 'text-accent-green' : 'text-accent-red'} ${className ?? ''}`}>
            {isProfit ? '+' : ''}${formatCurrency(value)}
        </span>
    );
};

const MetricRow: React.FC<{ label: string; children: React.ReactNode; className?: string }> = ({ label, children, className }) => (
    <div className={`flex justify-between items-center text-sm ${className}`}>
        <span className="text-slate-400">{label}</span>
        <div className="font-mono text-slate-50 text-right">{children}</div>
    </div>
);

const SettingInput: React.FC<{ label: string; value: any; onChange: (e: React.ChangeEvent<HTMLInputElement>) => void; name: string; disabled: boolean; unit?: string; min?: number; step?: number; }> = ({ label, value, onChange, name, disabled, unit, min, step }) => (
    <div>
        <label htmlFor={name} className="block text-sm font-medium text-slate-400 mb-1">{label}</label>
        <div className="relative">
            <input 
                type="number" 
                id={name}
                name={name} 
                value={value || ''}
                onChange={onChange}
                disabled={disabled}
                min={min}
                step={step}
                className="w-full bg-slate-900 border border-slate-600 rounded-md px-3 py-2 text-sm disabled:opacity-50 appearance-none [-moz-appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
            />
            {unit && <span className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none">{unit}</span>}
        </div>
    </div>
);

interface ModuleSettingsModalProps {
    module: ModuleState;
    isOpen: boolean;
    onClose: () => void;
    onSave: (updatedModule: ModuleState) => void;
    isBotRunning: boolean;
}

const ModuleSettingsModal: React.FC<ModuleSettingsModalProps> = ({ module, isOpen, onClose, onSave, isBotRunning }) => {
    const { t } = useTranslation();
    const [settings, setSettings] = useState(module);

    useEffect(() => {
        setSettings(module);
    }, [module]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setSettings(prev => ({ ...prev, [name]: parseFloat(value) || 0 }));
    };
    
    const handleSave = () => {
        onSave(settings);
    };

    const renderSettings = () => {
        switch(settings.name) {
            case 'Scalping':
            case 'Sniper':
                return (
                    <div className="space-y-4">
                        <SettingInput label={t('positionSize')} name="positionSizePercent" value={settings.positionSizePercent} onChange={handleChange} disabled={isBotRunning} unit="% of Capital" min={1} step={1} />
                        <SettingInput label={t('takeProfit')} name="takeProfitPercent" value={settings.takeProfitPercent} onChange={handleChange} disabled={isBotRunning} unit="%" min={0.1} step={0.1} />
                        <SettingInput label={t('stopLoss')} name="stopLossPercent" value={settings.stopLossPercent} onChange={handleChange} disabled={isBotRunning} unit="%" min={0.1} step={0.1} />
                    </div>
                );
            case 'Grid':
                return (
                     <div className="space-y-4">
                        <SettingInput label="Grid Lines" name="gridCount" value={settings.gridCount} onChange={handleChange} disabled={isBotRunning} min={2} step={1} />
                        <SettingInput label="Upper Price" name="upperPrice" value={settings.upperPrice} onChange={handleChange} disabled={isBotRunning} unit="USD" min={1} step={1} />
                        <SettingInput label="Lower Price" name="lowerPrice" value={settings.lowerPrice} onChange={handleChange} disabled={isBotRunning} unit="USD" min={1} step={1} />
                        <SettingInput label="Grid Stop Loss" name="gridStopLossPrice" value={settings.gridStopLossPrice} onChange={handleChange} disabled={isBotRunning} unit="USD" min={1} step={1} />
                        <SettingInput label="Grid Take Profit" name="gridTakeProfitPrice" value={settings.gridTakeProfitPrice} onChange={handleChange} disabled={isBotRunning} unit="USD" min={1} step={1} />
                    </div>
                );
            case 'Farming':
                return (
                    <div className="space-y-4">
                        <SettingInput label={t('minApyThreshold')} name="minApyThreshold" value={settings.minApyThreshold} onChange={handleChange} disabled={isBotRunning} unit="%" min={0.1} step={0.1} />
                    </div>
                );
            case 'LP':
                return (
                    <div className="space-y-4">
                        <SettingInput label={t('rangeTolerance')} name="rangeTolerance" value={settings.rangeTolerance} onChange={handleChange} disabled={isBotRunning} unit="%" min={1} step={1} />
                    </div>
                );
            case 'Futures':
                return (
                    <div className="space-y-4">
                        <SettingInput label={t('maxLeverage')} name="maxLeverage" value={settings.maxLeverage} onChange={handleChange} disabled={isBotRunning} min={1} step={1} />
                        <SettingInput label={t('fundingRateThreshold')} name="fundingRateThreshold" value={settings.fundingRateThreshold} onChange={handleChange} disabled={isBotRunning} unit="%" min={0.0001} step={0.0001} />
                        <SettingInput label={t('positionSize')} name="positionSizePercent" value={settings.positionSizePercent} onChange={handleChange} disabled={isBotRunning} unit="% of Capital" min={1} step={1} />
                        <SettingInput label={t('stopLoss')} name="stopLossPercent" value={settings.stopLossPercent} onChange={handleChange} disabled={isBotRunning} unit="%" min={0.1} step={0.1} />
                    </div>
                );
            default:
                return null;
        }
    }

    return (
        <Modal 
            isOpen={isOpen}
            onClose={onClose}
            onConfirm={handleSave}
            title={`${module.name} Settings`}
            confirmText="Save Changes"
            confirmColor="cyan"
            confirmDisabled={isBotRunning}
        >
            <div className="p-4">
                {isBotRunning && (
                    <div className="bg-yellow-500/10 text-yellow-400 text-sm p-3 rounded-lg mb-4">
                        {t('riskChangeWarning')}
                    </div>
                )}
                {renderSettings()}
            </div>
        </Modal>
    );
};

const StatusIndicator: React.FC<{ status: ModuleState['status'] }> = ({ status }) => {
    const statusStyles = {
        Active: 'bg-accent-green animate-pulse',
        Idle: 'bg-gray-500',
        Error: 'bg-accent-red',
    };
    return <div className={`w-3 h-3 rounded-full ${statusStyles[status]}`}></div>;
};

const RiskProfileSelector: React.FC<{
    profile: ScalpingRiskProfile;
    setProfile: (profile: ScalpingRiskProfile) => void;
    isBotRunning: boolean;
    onOptimize: () => void;
}> = ({ profile, setProfile, isBotRunning, onOptimize }) => {
    const { t } = useTranslation();
    const profiles: { key: ScalpingRiskProfile, label: string }[] = [
        { key: 'Conservative', label: t('riskConservative') },
        { key: 'Moderate', label: t('riskModerate') },
        { key: 'Aggressive', label: t('riskAggressive') }
    ];
    return (
        <Card>
            <div className="p-4">
                <h3 className="font-bold text-lg text-white mb-3">{t('riskProfileTitle')}</h3>
                <div className="flex flex-col sm:flex-row gap-2">
                    {profiles.map(p => (
                        <button key={p.key} onClick={() => setProfile(p.key)} disabled={isBotRunning}
                            className={`w-full text-center font-semibold py-2 px-3 border-2 rounded-lg transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed ${
                                profile === p.key ? `bg-accent-cyan/20 border-accent-cyan text-accent-cyan` : `border-slate-600 text-slate-400 hover:border-slate-500`
                            }`}
                        > {p.label} </button>
                    ))}
                </div>
                {isBotRunning && <p className="text-xs text-center text-slate-400 mt-2">{t('riskChangeWarning')}</p>}
                <motion.button onClick={onOptimize} whileHover={{ scale: 1.05, filter: 'drop-shadow(0 0 8px theme(colors.accent-cyan))' }} transition={{ type: 'spring', stiffness: 400, damping: 10 }}
                    className="mt-4 w-full flex items-center justify-center gap-2 bg-accent-cyan/80 hover:bg-accent-cyan text-slate-900 font-bold py-2 px-4 rounded-lg transition-all">
                    <FaRobot /> {t('optimizeWithAI')}
                </motion.button>
            </div>
        </Card>
    );
};

interface BotTradingScreenProps {
    isBotRunning: boolean;
    setIsBotRunning: (isRunning: boolean) => void;
    eventLog: BotEvent[];
    modules: ModuleState[];
    totalCapital: number;
    totalPnl: number;
    initialCapital: number;
    handleClearLog: () => void;
    scalpingRiskProfile: ScalpingRiskProfile;
    setScalpingRiskProfile: (profile: ScalpingRiskProfile) => void;
    onUpdateModule: (updatedModule: ModuleState) => void;
    liveCoinData: LiveCoin[]; // Added liveCoinData prop
}

const BotTradingScreen: React.FC<BotTradingScreenProps> = ({ isBotRunning, setIsBotRunning, eventLog, modules, totalCapital, totalPnl, initialCapital, handleClearLog, scalpingRiskProfile, setScalpingRiskProfile, onUpdateModule, liveCoinData }) => {
    const { t } = useTranslation();
    const pnlPercentage = initialCapital > 0 ? (totalPnl / initialCapital) * 100 : 0;
    const isProfit = totalPnl >= 0;
    const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);
    
    const [isOptimizing, setIsOptimizing] = useState(false);
    const [optimizationResult, setOptimizationResult] = useState<{ recommendation: ScalpingRiskProfile; reasoning: string; } | null>(null);
    const [isOptimizationModalOpen, setIsOptimizationModalOpen] = useState(false);
    
    const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
    const [editingModule, setEditingModule] = useState<ModuleState | null>(null);

    // Tabbed UI state
    const [activeModuleTab, setActiveModuleTab] = useState<ModuleName>('Scalping');


    const handleOpenSettings = (module: ModuleState) => {
        setEditingModule(module);
        setIsSettingsModalOpen(true);
    };

    const handleSaveSettings = (updatedModule: ModuleState) => {
        onUpdateModule(updatedModule);
        setIsSettingsModalOpen(false);
        setEditingModule(null);
    };
    
    // XP System calculations moved to useMemo for performance and consistency
    const { xp, level, nextLevelXP, levelProgress } = useMemo(() => {
        const currentXp = Math.max(0, Math.floor(totalPnl * 10));
        const currentLevel = Math.floor(Math.log2(currentXp / 100 + 1)) + 1;
        const currentLevelStartXP = currentLevel > 1 ? (Math.pow(2, currentLevel - 1) - 1) * 100 : 0;
        const currentNextLevelXP = (Math.pow(2, currentLevel) - 1) * 100;
        const currentLevelProgress = (currentXp - currentLevelStartXP) / (currentNextLevelXP - currentLevelStartXP) * 100;
        return { 
            xp: currentXp, 
            level: currentLevel, 
            levelStartXP: currentLevelStartXP, // Not directly used in render, but kept for completeness
            nextLevelXP: currentNextLevelXP, 
            levelProgress: currentLevelProgress 
        };
    }, [totalPnl]);


    const handleToggleBot = () => {
        setIsBotRunning(!isBotRunning);
        setIsConfirmModalOpen(false);
    };

    const handleOptimize = async () => {
        setIsOptimizationModalOpen(true);
        setIsOptimizing(true);
        setOptimizationResult(null);
        try {
            const marketSummary = await GeminiService.getMarketSummary();
            const result = marketSummary.startsWith("gemini.error")
                ? { recommendation: 'Moderate' as ScalpingRiskProfile, reasoning: t('gemini.error.riskProfile') }
                : await GeminiService.getBotRiskProfileSuggestion(marketSummary);
            setOptimizationResult(result);
        } catch (error) {
             setOptimizationResult({ recommendation: 'Moderate', reasoning: t('gemini.error.riskProfile') });
        } finally {
            setIsOptimizing(false);
        }
    };
    
    const moduleIcons: { [key in ModuleName]: React.ReactElement } = {
        Scalping: <BarChartHorizontal size={20} />,
        Grid: <Grid size={20} />,
        Sniper: <Crosshair size={20} />,
        Farming: <DatabaseZap size={20} />, 
        LP: <Combine size={20} />,         
        Futures: <Zap size={20} />,          
    };

    const moduleTagColors: { [key in BotEvent['module']]: string } = {
        Scalping: 'text-accent-cyan',
        Grid: 'text-accent-green',
        Sniper: 'text-accent-purple',
        Farming: 'text-yellow-400', 
        LP: 'text-blue-400',       
        Futures: 'text-red-400',     
        System: 'text-yellow-400'
    };

    const moduleHighlights: { [key in ModuleName]: 'cyan' | 'green' | 'purple' | 'red' } = {
        Scalping: 'cyan',
        Grid: 'green',
        Sniper: 'purple',
        Farming: 'green', // Using green for farming module
        LP: 'purple', // Using purple for LP module
        Futures: 'red', // Using red for Futures module
    };

    return (
        <div className="p-4 md:p-6 space-y-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                    <h1 className="text-3xl font-bold bg-gradient-to-r from-accent-cyan to-accent-purple text-transparent bg-clip-text">{t('automateTitle')}</h1>
                    <p className="text-slate-400">{t('automateDescription')}</p>
                </div>
                <motion.button onClick={() => setIsConfirmModalOpen(true)} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
                    className={`px-6 py-3 font-bold rounded-lg text-lg transition-all duration-300 shadow-lg ${
                        isBotRunning ? 'bg-gradient-to-r from-red-500 to-red-600 text-white shadow-red-500/30' : 'bg-gradient-to-r from-green-500 to-green-600 text-white shadow-green-500/30'
                    }`}>
                    {isBotRunning ? t('stopBot') : t('startBot')}
                </motion.button>
            </div>
            
            <Card>
                <div className="p-4 grid grid-cols-1 md:grid-cols-3 gap-4 text-center divide-y md:divide-y-0 md:divide-x divide-slate-800">
                     <div className="pt-2 md:pt-0"><p className="text-slate-400 text-sm">{t('totalCapital')}</p><p className="text-2xl font-bold text-white">{formatCurrency(totalCapital)}</p></div>
                     <div className="pt-2 md:pt-0"><p className="text-slate-400 text-sm">{t('totalPnl')}</p><p className={`text-2xl font-bold mt-1 ${isProfit ? 'text-accent-green' : 'text-accent-red'}`}>{formatCurrency(totalPnl)}</p></div>
                     <div className="pt-2 md:pt-0"><p className="text-slate-400 text-sm">{t('totalReturn')}</p><p className={`text-2xl font-bold mt-1 ${isProfit ? 'text-accent-green' : 'text-accent-red'}`}>{isProfit ? '+' : ''}{pnlPercentage.toFixed(2)}%</p></div>
                </div>
                <div className="p-4 border-t border-slate-800">
                    <div className="flex justify-between items-center mb-1 text-sm">
                        <span className="font-bold text-accent-purple">Level {level}</span>
                        <span className="text-slate-400">{xp.toLocaleString()} / {nextLevelXP.toLocaleString()} XP</span>
                    </div>
                    <div className="w-full bg-slate-700 rounded-full h-2.5"><div className="bg-gradient-to-r from-accent-purple to-accent-cyan h-2.5 rounded-full" style={{ width: `${levelProgress}%` }}></div></div>
                </div>
            </Card>

            <RiskProfileSelector profile={scalpingRiskProfile} setProfile={setScalpingRiskProfile} isBotRunning={isBotRunning} onOptimize={handleOptimize}/>

            <h2 className="text-xl font-bold text-white mb-4">{t('botTrading.modules')}</h2>
            <Card className="p-0">
                <div className="flex flex-wrap border-b border-slate-800">
                    {modules.map((moduleItem) => (
                        <motion.button
                            key={moduleItem.name}
                            onClick={() => setActiveModuleTab(moduleItem.name)}
                            className={`flex-grow md:flex-none flex items-center justify-center md:justify-start gap-2 p-4 text-sm font-semibold transition-colors relative group
                                ${activeModuleTab === moduleItem.name ? 'text-white' : 'text-slate-400 hover:text-slate-50'}`}
                            whileHover={{ backgroundColor: activeModuleTab === moduleItem.name ? undefined : 'rgba(30,41,59,0.5)' }}
                        >
                            <span className={`mr-1 ${moduleTagColors[moduleItem.name]}`}>{moduleIcons[moduleItem.name]}</span>
                            <span>{moduleItem.name}</span>
                            {activeModuleTab === moduleItem.name && (
                                <motion.div
                                    layoutId="active-tab-indicator"
                                    className={`absolute bottom-0 left-0 right-0 h-0.5 ${moduleTagColors[moduleItem.name].replace('text-', 'bg-')}`}
                                    transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                                />
                            )}
                        </motion.button>
                    ))}
                </div>
                <div className="p-4">
                    <AnimatePresence mode="wait">
                        <motion.div
                            key={activeModuleTab}
                            initial={{ opacity: 0, y: 15 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -15 }}
                            transition={{ duration: 0.25 }}
                            className="w-full"
                        >
                            {(() => {
                                const module = modules.find(m => m.name === activeModuleTab);
                                if (!module) return null;

                                switch (module.name) {
                                    case 'Scalping':
                                        return <ScalpingModule module={module} isBotRunning={isBotRunning} onUpdateModule={onUpdateModule} liveCoinData={liveCoinData} />;
                                    case 'Farming':
                                        return <FarmingModule module={module} isBotRunning={isBotRunning} onUpdateModule={onUpdateModule} />;
                                    case 'LP':
                                        return <LpModule module={module} isBotRunning={isBotRunning} onUpdateModule={onUpdateModule} liveCoinData={liveCoinData} />;
                                    case 'Futures':
                                        return <FuturesModule module={module} isBotRunning={isBotRunning} onUpdateModule={onUpdateModule} liveCoinData={liveCoinData} />;
                                    default:
                                        // Fallback for Grid and Sniper, using a generic card structure
                                        return (
                                            <Card highlight={moduleHighlights[module.name]} className="p-4 flex flex-col h-full">
                                                <div className="flex items-center justify-between">
                                                    <div className="flex items-center space-x-2">
                                                        <StatusIndicator status={module.status} />
                                                        <div className={`mr-1 ${moduleTagColors[module.name]}`}>{moduleIcons[module.name]}</div>
                                                        <h3 className={`text-lg font-bold ${moduleTagColors[module.name]}`}>{module.name}</h3>
                                                    </div>
                                                    <button onClick={() => handleOpenSettings(module)} className="text-slate-400 hover:text-white transition-colors">
                                                        <Settings size={16} />
                                                    </button>
                                                </div>
                                                <div className="mt-2 space-y-2 flex-grow">
                                                    <MetricRow label={t('moduleCapital')}>${formatCurrency(module.capital)}</MetricRow>
                                                    <MetricRow label={t('moduleTotalPnl')}><PnlText value={module.pnl} /></MetricRow>
                                                    {module.name === 'Grid' && (
                                                        <>
                                                            <MetricRow label="Grids">{module.gridCount ?? 0}</MetricRow>
                                                            <MetricRow label="Range">${(module.lowerPrice ?? 0).toLocaleString()} - ${(module.upperPrice ?? 0).toLocaleString()}</MetricRow>
                                                            <MetricRow label="SL Price">{formatCurrency(module.gridStopLossPrice ?? 0)}</MetricRow>
                                                            <MetricRow label="TP Price">{formatCurrency(module.gridTakeProfitPrice ?? 0)}</MetricRow>
                                                        </>
                                                    )}
                                                    {module.name === 'Sniper' && (
                                                        <>
                                                            <MetricRow label="Successful Snipes">{module.snipes ?? 0}</MetricRow>
                                                            <MetricRow label="Avg. Profit">{formatCurrency(module.avgProfit ?? 0)}</MetricRow>
                                                            <MetricRow label={`${t('positionSize')} %`}>{module.positionSizePercent}% Cap</MetricRow>
                                                            <MetricRow label={`${t('stopLoss')} / ${t('takeProfit')}`}>{module.stopLossPercent}% / {module.takeProfitPercent}%</MetricRow>
                                                        </>
                                                    )}
                                                </div>
                                            </Card>
                                        );
                                }
                            })()}
                        </motion.div>
                    </AnimatePresence>
                </div>
            </Card>

            <Card className="p-0">
                <div className="flex justify-between items-center p-4 border-b border-slate-800">
                    <h2 className="text-lg font-semibold text-white">{t('eventLog')}</h2>
                    <button onClick={handleClearLog} className="text-xs text-slate-400 hover:text-accent-cyan font-semibold">{t('clearLog')}</button>
                </div>
                <div className="h-64 overflow-y-auto p-4 space-y-3">
                    {eventLog.length === 0 ? (
                        <div className="flex items-center justify-center h-full"><p className="text-slate-400">{t('logEmpty')}</p></div>
                    ) : (
                        <AnimatePresence>
                            {eventLog.map(event => (
                                <motion.div key={event.id} layout initial={{ opacity: 0, y: -20, scale: 0.9 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, scale: 0.8 }} transition={{ type: 'spring', stiffness: 300, damping: 25 }} className="flex items-start text-sm">
                                    <span className="font-mono text-xs text-slate-500 mr-3 mt-0.5">{new Date(event.timestamp).toLocaleTimeString()}</span>
                                    <div className="flex-grow">
                                        <span className={`font-semibold mr-2 ${moduleTagColors[event.module]}`}>[{event.module}]</span>
                                        <span className="text-slate-300">{event.message}</span>
                                        {event.pnl !== undefined && <PnlText value={event.pnl} className="ml-2" />}
                                    </div>
                                </motion.div>
                            ))}
                        </AnimatePresence>
                    )}
                </div>
            </Card>

            <Modal isOpen={isConfirmModalOpen} onClose={() => setIsConfirmModalOpen(false)} onConfirm={handleToggleBot} title={isBotRunning ? t('modalStopTitle') : t('modalStartTitle')} confirmText={isBotRunning ? t('stopBot') : t('startBot')} confirmColor={isBotRunning ? 'red' : 'green'}>
                <p className="text-sm text-slate-400">{isBotRunning ? t('modalStopBody') : t('modalStartBody')}</p>
            </Modal>
            
            <Modal isOpen={isOptimizationModalOpen} onClose={() => setIsOptimizationModalOpen(false)} onConfirm={() => { if (optimizationResult) { setScalpingRiskProfile(optimizationResult.recommendation); setIsOptimizationModalOpen(false); }}} title={t('modal.optimizeTitle')} confirmText={t('modal.applyRecommendation')} confirmColor="cyan" confirmDisabled={isOptimizing}>
                {isOptimizing ? (
                    <div className="text-center p-4">
                         <motion.div animate={{ rotate: [0, 360], scale: [1, 1.1, 1] }} transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }} className="w-16 h-16 text-accent-cyan mx-auto"><BrainCircuit className="w-full h-full" /></motion.div>
                         <p className="text-slate-400 mt-4 animate-pulse">{t('modal.optimizeLoading')}</p>
                    </div>
                ) : optimizationResult && (
                    <div className="p-4 space-y-4 animate-fade-in">
                        <div>
                            <h4 className="text-sm font-bold text-slate-400 uppercase tracking-wider">{t('modal.optimizeRecommendation')}</h4>
                            <div className="mt-2 inline-block px-4 py-2 rounded-lg text-lg font-bold bg-accent-cyan/20 text-accent-cyan">{t(`risk${optimizationResult.recommendation}`)}</div>
                        </div>
                        <div>
                             <h4 className="text-sm font-bold text-slate-400 uppercase tracking-wider">{t('modal.optimizeReasoning')}</h4>
                             <p className="text-sm text-slate-300 mt-2 bg-slate-800/50 p-3 rounded-md">{t(optimizationResult.reasoning)}</p>
                        </div>
                    </div>
                )}
            </Modal>

            {editingModule && (
                <ModuleSettingsModal
                    module={editingModule}
                    isOpen={isSettingsModalOpen}
                    onClose={() => setIsSettingsModalOpen(false)}
                    onSave={handleSaveSettings}
                    isBotRunning={isBotRunning}
                />
            )}
        </div>
    );
};

export default BotTradingScreen;