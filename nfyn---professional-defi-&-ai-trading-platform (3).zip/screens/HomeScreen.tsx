import React, { useState, useMemo, useEffect } from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, Legend, PieChart, Pie, Cell, Sector, ReferenceLine, CartesianGrid } from 'recharts';
import Card from '../components/Card';
import { GeminiService, PriceDataPoint } from '../services/geminiService';
import { Theme } from '../App';
import { Coin, LiveCoin, AISignal, KOL, NewsArticle, SentimentData, ApiNewsArticle, WidgetConfig, WidgetId, ModuleState } from '../types';
import { useTranslation } from '../LanguageContext';
import { MdTrendingUp, MdTrendingDown } from 'react-icons/md';
import { Lightbulb, Zap, Newspaper, Users, Settings, GripVertical, Eye, EyeOff } from 'lucide-react';
import BalanceSparkline from '../components/BalanceSparkline';
import MarketSummaryAI from '../components/MarketSummaryAI';
import { motion, AnimatePresence, Reorder } from 'framer-motion';
import LivePrices from '../components/LivePrices';
import PriceChart from '../components/trading/PriceChart';
import { PubliApisService } from '../services/publiApisService';
import SkeletonLoader from '../components/SkeletonLoader';
import { useLocalStorage } from '../hooks/useLocalStorage';
import AIPortfolioInsights from '../components/AIPortfolioInsights';
import Modal from '../components/Modal';


const TotalBalance: React.FC<{ totalCapital: number, totalPnl: number, initialCapital: number }> = ({ totalCapital, totalPnl, initialCapital }) => {
  const { t } = useTranslation();
  const pnlPercentage = initialCapital > 0 ? (totalPnl / initialCapital) * 100 : 0;
  const isProfit = totalPnl >= 0;

  const balanceHistory = React.useMemo(() => {
    const data = [];
    const startValue = totalCapital - totalPnl;
    for (let i = 0; i < 6; i++) {
        const progress = i / 6;
        const idealValue = startValue + (totalPnl * progress);
        const noise = (Math.random() - 0.5) * (totalCapital * 0.01);
        data.push({ name: `${6-i}d`, value: idealValue + noise });
    }
    data.push({ name: 'Now', value: totalCapital });
    return data;
  }, [totalCapital, totalPnl]);
  
  const trend = totalPnl >= 0 ? 'positive' : 'negative';

  return (
    <Card className="p-6">
      <div className="flex justify-between items-start">
        <div>
          <p className="text-sm text-slate-400">{t('balance')}</p>
          <p className="text-4xl font-bold mt-1 font-orbitron bg-gradient-to-r from-accent-cyan to-accent-purple text-transparent bg-clip-text">${totalCapital.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
        </div>
        <div className={`px-3 py-1 rounded-full text-sm font-bold flex items-center gap-1 ${isProfit ? 'bg-accent-green/20 text-accent-green' : 'bg-accent-red/20 text-accent-red'}`}>
          {isProfit ? <MdTrendingUp /> : <MdTrendingDown />} {pnlPercentage.toFixed(2)}%
        </div>
      </div>
      <div className="mt-4 text-sm">
        <span className="text-slate-400">{t('pnl24h')}: </span>
        <span className={`font-bold ${isProfit ? 'text-accent-green' : 'text-accent-red'}`}>
          {isProfit ? '+' : '-'}${Math.abs(totalPnl).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
        </span>
      </div>
      <div className="mt-4">
        <BalanceSparkline data={balanceHistory} trend={trend} />
      </div>
    </Card>
  );
};

const AISignals: React.FC = () => {
    const [signals, setSignals] = useState<AISignal[]>([]);

    const generateSignal = React.useCallback(() => {
        const assets: AISignal['asset'][] = ['BTC', 'ETH', 'SOL'];
        const types: AISignal['type'][] = ['BUY', 'SELL'];
        const strengths: AISignal['strength'][] = ['High', 'Medium', 'Low'];

        const newSignal: AISignal = {
            id: `sig_${Date.now()}`,
            asset: assets[Math.floor(Math.random() * assets.length)],
            type: types[Math.floor(Math.random() * types.length)],
            strength: strengths[Math.floor(Math.random() * strengths.length)],
            timestamp: Date.now(),
        };

        setSignals(prev => [newSignal, ...prev.slice(0, 4)]);
    }, []);

    useEffect(() => {
        generateSignal();
        const interval = setInterval(generateSignal, 120000); // New signal every 2 minutes
        return () => clearInterval(interval);
    }, [generateSignal]);

    return (
        <Card>
            <div className="p-4 border-b border-slate-800">
                <h3 className="font-bold text-lg text-white flex items-center gap-2 font-orbitron"><Zap className="text-accent-purple" /> AI Signals</h3>
            </div>
            <div className="p-2 space-y-2">
                {signals.map(signal => {
                    const isBuy = signal.type === 'BUY';
                    const borderColor = isBuy ? 'border-accent-green' : 'border-accent-red';
                    const bgColor = isBuy ? 'bg-accent-green/10' : 'bg-accent-red/10';
                    const shadow = isBuy ? 'shadow-glow-green' : 'shadow-glow-red';

                    return (
                        <motion.div
                            key={signal.id}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ duration: 0.5 }}
                            className={`p-3 rounded-lg flex items-center justify-between border-l-4 ${borderColor} ${bgColor}`}
                        >
                             <motion.div 
                                className="absolute inset-0 rounded-lg"
                                animate={{ boxShadow: [`0 0 0px ${isBuy ? 'rgba(140, 255, 0, 0)' : 'rgba(239, 68, 68, 0)'}`, `0 0 10px ${isBuy ? 'rgba(140, 255, 0, 0.5)' : 'rgba(239, 68, 68, 0.5)'}`, `0 0 0px ${isBuy ? 'rgba(140, 255, 0, 0)' : 'rgba(239, 68, 68, 0)'}`] }}
                                transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                            />
                            <div>
                                <p className="font-bold text-white">{signal.asset}/USDT</p>
                                <p className={`text-sm font-semibold ${isBuy ? 'text-accent-green' : 'text-accent-red'}`}>{signal.type} Signal</p>
                            </div>
                            <div className="text-right">
                                <p className="text-xs text-slate-400">Strength</p>
                                <p className="font-semibold text-white">{signal.strength}</p>
                            </div>
                        </motion.div>
                    );
                })}
            </div>
        </Card>
    );
};

const KOLWatchlistWidget: React.FC = () => {
    const { t } = useTranslation();
    const [kols, setKols] = useState<KOL[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchKOLs = async () => {
            setIsLoading(true);
            const fetchedKOLs = [{ id: '1', name: 'CryptoCred', handle: '@CryptoCred', score: 8.5, latestSignal: 'Long BTC, targeting $72k.' },
            { id: '2', name: 'Pentoshi', handle: '@Pentosh1', score: 9.2, latestSignal: 'Watching SOL for a breakout above $175.' },
            { id: '3', name: 'Hsaka', handle: '@HsakaTrades', score: 8.9, latestSignal: 'Neutral on ETH until it reclaims $3.6k support.' }]; // MOCK for now
            setKols(fetchedKOLs);
            setIsLoading(false);
        };
        fetchKOLs();
        const interval = setInterval(fetchKOLs, 5 * 60 * 1000); // Refresh every 5 minutes
        return () => clearInterval(interval);
    }, []);

    return (
        <Card>
            <div className="p-4 border-b border-slate-800">
                <h3 className="font-bold text-lg text-white font-orbitron flex items-center gap-2"><Users className="text-neon-blue" /> {t('kols')}</h3>
            </div>
            <div className="p-2 space-y-2">
                {isLoading ? (
                    [...Array(3)].map((_, i) => (
                        <div key={i} className="p-2">
                            <SkeletonLoader className="h-4 w-3/4 mb-2 rounded" />
                            <SkeletonLoader className="h-3 w-full rounded" />
                        </div>
                    ))
                ) : (
                    kols.slice(0, 3).map(kol => (
                        <div key={kol.id} className="p-2 rounded-lg hover:bg-slate-800/50">
                            <div className="flex justify-between items-center">
                                <p className="font-bold text-sm text-white">{kol.name} <span className="text-accent-cyan font-normal text-xs">{kol.handle}</span></p>
                                <p className="text-xs font-bold text-white bg-slate-700 px-2 py-1 rounded-full">{kol.score}</p>
                            </div>
                            <p className="text-xs text-slate-400 mt-1 italic">"{kol.latestSignal}"</p>
                        </div>
                    ))
                )}
            </div>
        </Card>
    );
};

const NewsFeedWidget: React.FC = () => {
    const { t } = useTranslation();
    const [newsArticles, setNewsArticles] = useState<ApiNewsArticle[]>([]);
    const [summaries, setSummaries] = useState<Record<string, string>>({});
    const [isLoading, setIsLoading] = useState(true);

    const fetchNewsAndSummaries = React.useCallback(async () => {
        setIsLoading(true);
        const fetchedArticles = await PubliApisService.getNewsFeed();
        const topArticles = fetchedArticles.slice(0, 2); 
        setNewsArticles(topArticles);

        const articlesToSummarize = topArticles.map(a => ({ id: a.id, title: a.title }));
        const summaryMap = await GeminiService.getBulkSummaries(articlesToSummarize);
        
        const translatedSummaries: Record<string, string> = {};
        for (const article of topArticles) {
            const summary = summaryMap[article.id] || "gemini.error.summary";
            translatedSummaries[article.id] = summary.startsWith("gemini.error") ? t(summary) : summary;
        }

        setSummaries(translatedSummaries);
        setIsLoading(false);
    }, [t]);

    useEffect(() => {
        fetchNewsAndSummaries();
        const interval = setInterval(fetchNewsAndSummaries, 60 * 1000); 
        return () => clearInterval(interval);
    }, [fetchNewsAndSummaries]);

    return (
        <Card>
            <div className="p-4 border-b border-slate-800">
                <h3 className="font-bold text-lg text-white font-orbitron flex items-center gap-2"><Newspaper className="text-accent-cyan" /> {t('news')}</h3>
            </div>
            <div className="p-2 space-y-3">
                {isLoading ? (
                    [...Array(2)].map((_, i) => (
                        <div key={i} className="p-2">
                            <SkeletonLoader className="h-4 w-5/6 mb-1 rounded" />
                            <SkeletonLoader className="h-3 w-1/2 rounded" />
                            <SkeletonLoader className="h-3 w-full mt-2 rounded" />
                        </div>
                    ))
                ) : (
                    newsArticles.map(article => (
                        <div key={article.id} className="p-2">
                             <p className="font-semibold text-sm text-white leading-tight">{article.title}</p>
                             <p className="text-xs text-slate-500 mt-1">{article.source}</p>
                             {summaries[article.id] && (
                                <p className="text-xs text-slate-400 mt-1 italic">
                                    <span className="font-bold text-accent-purple mr-1">AI Summary:</span>
                                    {summaries[article.id]}
                                </p>
                             )}
                        </div>
                    ))
                )}
            </div>
        </Card>
    );
};

const WIDGET_NAMES: Record<WidgetId, string> = {
    balance: 'Total Balance',
    priceChart: 'Price Chart',
    aiPortfolioInsights: 'AI Portfolio Insights',
    marketSummary: 'AI Market Briefing',
    aiSignals: 'AI Signals',
    kolWatchlist: 'KOL Watchlist',
    newsFeed: 'News Feed',
};

const ALL_WIDGETS: WidgetConfig[] = [
    { id: 'balance', visible: true },
    { id: 'priceChart', visible: true },
    { id: 'aiPortfolioInsights', visible: true },
    { id: 'marketSummary', visible: true },
    { id: 'aiSignals', visible: true },
    { id: 'kolWatchlist', visible: true },
    { id: 'newsFeed', visible: true },
];

const TEMPLATES: Record<string, WidgetConfig[]> = {
    trader: [
        { id: 'balance', visible: true },
        { id: 'priceChart', visible: true },
        { id: 'aiSignals', visible: true },
        { id: 'aiPortfolioInsights', visible: true },
        { id: 'newsFeed', visible: false },
        { id: 'kolWatchlist', visible: false },
        { id: 'marketSummary', visible: false },
    ],
    investor: [
        { id: 'balance', visible: true },
        { id: 'aiPortfolioInsights', visible: true },
        { id: 'marketSummary', visible: true },
        { id: 'newsFeed', visible: true },
        { id: 'priceChart', visible: false },
        { id: 'aiSignals', visible: false },
        { id: 'kolWatchlist', visible: false },
    ],
    full: ALL_WIDGETS,
};


const DashboardSettingsModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    widgets: WidgetConfig[];
    setWidgets: (widgets: WidgetConfig[]) => void;
}> = ({ isOpen, onClose, widgets, setWidgets }) => {
    const { t } = useTranslation();
    const [localWidgets, setLocalWidgets] = useState(widgets);

    useEffect(() => {
        setLocalWidgets(widgets);
    }, [widgets, isOpen]);

    const handleSave = () => {
        setWidgets(localWidgets);
        onClose();
    };

    const handleTemplate = (template: 'trader' | 'investor' | 'full') => {
        const templateWidgets = TEMPLATES[template];
        const currentWidgetIds = localWidgets.map(w => w.id);
        const sortedTemplate = templateWidgets.sort((a, b) => currentWidgetIds.indexOf(a.id) - currentWidgetIds.indexOf(b.id));
        setLocalWidgets(sortedTemplate);
    };

    const toggleVisibility = (id: WidgetId) => {
        setLocalWidgets(prev => prev.map(w => w.id === id ? { ...w, visible: !w.visible } : w));
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} onConfirm={handleSave} title={t('dashboard.customize')} confirmText={t('dashboard.saveLayout')}>
            <div className="p-4 space-y-6">
                <div>
                    <h3 className="text-sm font-semibold text-slate-400 mb-2">{t('dashboard.templates')}</h3>
                    <div className="flex gap-2">
                        <button onClick={() => handleTemplate('trader')} className="flex-1 text-sm bg-slate-700 hover:bg-slate-600 rounded p-2">{t('dashboard.traderMode')}</button>
                        <button onClick={() => handleTemplate('investor')} className="flex-1 text-sm bg-slate-700 hover:bg-slate-600 rounded p-2">{t('dashboard.investorMode')}</button>
                        <button onClick={() => handleTemplate('full')} className="flex-1 text-sm bg-slate-700 hover:bg-slate-600 rounded p-2">{t('dashboard.fullMode')}</button>
                    </div>
                </div>
                <div>
                    <h3 className="text-sm font-semibold text-slate-400 mb-2">{t('dashboard.widgetSettings')}</h3>
                    <Reorder.Group axis="y" values={localWidgets} onReorder={setLocalWidgets}>
                        {localWidgets.map(widget => (
                            <Reorder.Item key={widget.id} value={widget} className="bg-slate-800 p-2 my-1 rounded-lg flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                    <GripVertical className="cursor-grab text-slate-500" size={20} />
                                    <span className="text-slate-200">{t(`widget.${widget.id}`, { defaultValue: WIDGET_NAMES[widget.id] })}</span>
                                </div>
                                <button onClick={() => toggleVisibility(widget.id)}>
                                    {widget.visible ? <Eye size={20} className="text-accent-cyan" /> : <EyeOff size={20} className="text-slate-500" />}
                                </button>
                            </Reorder.Item>
                        ))}
                    </Reorder.Group>
                </div>
            </div>
        </Modal>
    );
};

const DashboardScreen: React.FC<{
    totalCapital: number;
    totalPnl: number;
    initialCapital: number;
    theme: Theme;
    liveCoinData: LiveCoin[];
    modules: ModuleState[];
}> = ({ totalCapital, totalPnl, initialCapital, theme, liveCoinData, modules }) => {
    const { t } = useTranslation();
    const [isSettingsOpen, setIsSettingsOpen] = useState(false);
    const [widgets, setWidgets] = useLocalStorage<WidgetConfig[]>('nfyn_dashboard_layout_v1', ALL_WIDGETS);

    const widgetComponents: Record<WidgetId, React.ReactNode> = {
        balance: <TotalBalance totalCapital={totalCapital} totalPnl={totalPnl} initialCapital={initialCapital} />,
        priceChart: <PriceChart liveCoinData={liveCoinData} showControls={true} />,
        aiPortfolioInsights: <AIPortfolioInsights totalCapital={totalCapital} totalPnl={totalPnl} initialCapital={initialCapital} modules={modules} />,
        marketSummary: <MarketSummaryAI />,
        aiSignals: <AISignals />,
        kolWatchlist: <KOLWatchlistWidget />,
        newsFeed: <NewsFeedWidget />,
    };
    
    // Ensure all widgets from ALL_WIDGETS are present in the state, in case new widgets are added in an update.
    React.useEffect(() => {
        const stateIds = new Set(widgets.map(w => w.id));
        const missingWidgets = ALL_WIDGETS.filter(w => !stateIds.has(w.id));
        if (missingWidgets.length > 0) {
            setWidgets(prev => [...prev, ...missingWidgets]);
        }
    }, [widgets, setWidgets]);

    const visibleWidgets = widgets.filter(w => w.visible);

    const getGridSpanClass = (id: WidgetId) => {
        switch (id) {
            case 'balance': return 'lg:col-span-4';
            case 'priceChart': return 'lg:col-span-3';
            case 'aiPortfolioInsights': return 'lg:col-span-4';
            default: return 'lg:col-span-1';
        }
    };
    
    return (
        <div className="p-4 md:p-6">
             <div className="flex justify-end mb-4">
                <motion.button 
                    onClick={() => setIsSettingsOpen(true)}
                    className="flex items-center gap-2 text-sm font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 px-4 py-2 rounded-lg transition-colors"
                    whileHover={{ scale: 1.05 }}
                >
                    <Settings size={16} />
                    {t('dashboard.customize')}
                </motion.button>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                <AnimatePresence>
                    {visibleWidgets.map(widget => (
                        <motion.div
                            key={widget.id}
                            layout
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -20 }}
                            transition={{ type: 'spring', stiffness: 200, damping: 25 }}
                            className={`${getGridSpanClass(widget.id)} ${widget.id === 'priceChart' || widget.id === 'aiSignals' || widget.id === 'kolWatchlist' || widget.id === 'newsFeed' ? 'lg:row-span-2' : ''}`}
                        >
                            {widgetComponents[widget.id]}
                        </motion.div>
                    ))}
                </AnimatePresence>
            </div>
            <DashboardSettingsModal isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} widgets={widgets} setWidgets={setWidgets} />
        </div>
    );
};

export default DashboardScreen;