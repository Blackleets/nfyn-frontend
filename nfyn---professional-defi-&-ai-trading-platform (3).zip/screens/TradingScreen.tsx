import React from 'react';
import { LiveCoin } from '../types';
import { useTranslation } from '../LanguageContext';
import Card from '../components/Card';
import SwapWidget from '../components/SwapWidget';
import TradingViewWidget from '../components/trading/TradingViewWidget';

interface TradingScreenProps {
  liveCoinData: LiveCoin[];
  isWalletConnected: boolean;
  handleWalletConnect: () => void;
}

const TradingScreen: React.FC<TradingScreenProps> = ({ liveCoinData, isWalletConnected, handleWalletConnect }) => {
  const { t } = useTranslation();
  
  return (
    <div className="p-4 md:p-6 space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        <div className="lg:col-span-3">
            <SwapWidget 
                liveCoinData={liveCoinData} 
                isWalletConnected={isWalletConnected}
                handleWalletConnect={handleWalletConnect}
            />
        </div>
        <div className="lg:col-span-2">
            <Card className="p-6 h-full flex flex-col justify-center items-center">
                <h2 className="text-2xl font-bold text-center text-accent-purple">{t('swap.toolsComingSoonTitle')}</h2>
                <p className="text-center text-slate-400 mt-2">{t('swap.toolsComingSoonBody')}</p>
            </Card>
        </div>
      </div>
      <Card className="h-[550px] p-0 overflow-hidden">
        <TradingViewWidget />
      </Card>
    </div>
  );
};

export default TradingScreen;