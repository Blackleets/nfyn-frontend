import React from 'react';

const MarketBoardScreen: React.FC = () => {
    return (
        <div>
            <h1>Market Board</h1>
            {/* Market board placeholder */}
        </div>
    );
};

export default MarketBoardScreen;
