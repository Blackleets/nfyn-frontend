import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useTranslation } from '../LanguageContext';
import Card from '../components/Card';
import { motion, AnimatePresence } from 'framer-motion';
import { LiveCoin } from '../types';
import { Play, Square, RotateCcw, BarChartHorizontal, Combine, DatabaseZap, Zap, FastForward } from 'lucide-react';

// --- TYPES (Locally defined for isolation) ---
type StrategyName = 'Scalping' | 'Farming' | 'LP' | 'Futures';
type SimEvent = {
    id: string;
    timestamp: number;
    module: StrategyName | 'System';
    message: string;
    balance: number;
};
type StrategyState = {
    name: StrategyName;
    capital: number;
    pnl: number;
    // Strategy-specific stats
    trades?: number;
    wins?: number;
    fees?: number;
    il?: number;
    rewards?: number;
    openPosition?: { side: 'Long' | 'Short'; entryPrice: number; size: number };
};
type SimulationState = {
    isRunning: boolean;
    startTime: number | null;
    endTime: number | null;
    timeLeft: number;
    initialCapital: number;
    strategies: Record<StrategyName, StrategyState>;
    eventLog: SimEvent[];
};

// --- CONSTANTS ---
const SIMULATION_DURATION = 24 * 60 * 60 * 1000; // 24 hours in ms
const INITIAL_CAPITAL = 1000;
const STRATEGIES: StrategyName[] = ['Scalping', 'Farming', 'LP', 'Futures'];
const STORAGE_KEY = 'nfyn_simulation_state';
const FAST_FORWARD_SPEED = 4;

// --- HELPERS ---
const formatCurrency = (value: number) => `$${value.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const PnlText: React.FC<{ value: number }> = ({ value }) => {
    const isProfit = value >= 0;
    return <span className={`font-bold ${isProfit ? 'text-accent-green' : 'text-accent-red'}`}>{isProfit ? '+' : ''}{formatCurrency(value)}</span>;
};

// --- REALISTIC FLIPPER CLOCK COMPONENTS ---
const AnimatedDigit: React.FC<{ digit: string }> = ({ digit }) => {
    return (
        <div className="relative w-8 h-12 md:w-10 md:h-16 bg-slate-200 dark:bg-slate-900 rounded-lg flex items-center justify-center overflow-hidden">
            <AnimatePresence>
                <motion.span
                    key={digit}
                    initial={{ y: -20, opacity: 0, scale: 0.8 }}
                    animate={{ y: 0, opacity: 1, scale: 1 }}
                    exit={{ y: 20, opacity: 0, scale: 0.8 }}
                    transition={{ type: 'spring', stiffness: 500, damping: 25 }}
                    className="absolute text-3xl md:text-5xl font-mono font-bold text-slate-800 dark:text-slate-50"
                >
                    {digit}
                </motion.span>
            </AnimatePresence>
        </div>
    );
};

const FlipperClock: React.FC<{ timeLeft: number }> = ({ timeLeft }) => {
    const { t } = useTranslation();
    const time = useMemo(() => {
        // Fix for: The left-hand side of an arithmetic operation must be of type 'any', 'number', 'bigint' or an enum type.
        const totalSeconds = Math.max(0, Math.floor(Number(timeLeft) / 1000));
        const hours = String(Math.floor(totalSeconds / 3600)).padStart(2, '0');
        const minutes = String(Math.floor((totalSeconds % 3600) / 60)).padStart(2, '0');
        const seconds = String(totalSeconds % 60).padStart(2, '0');
        return { hours, minutes, seconds };
    }, [timeLeft]);

    return (
        <div className="flex flex-col items-center">
            <p className="text-sm text-center text-slate-500 dark:text-slate-400 mb-2">{t('simulation.timeLeft')}</p>
            <div className="flex items-center justify-center gap-1.5">
                <AnimatedDigit digit={time.hours[0]} />
                <AnimatedDigit digit={time.hours[1]} />
                <span className="text-3xl md:text-5xl font-bold text-slate-500 dark:text-slate-600">:</span>
                <AnimatedDigit digit={time.minutes[0]} />
                <AnimatedDigit digit={time.minutes[1]} />
                <span className="text-3xl md:text-5xl font-bold text-slate-500 dark:text-slate-600">:</span>
                <AnimatedDigit digit={time.seconds[0]} />
                <AnimatedDigit digit={time.seconds[1]} />
            </div>
        </div>
    );
};


// --- SUB-COMPONENTS ---
const StrategyCard: React.FC<{ state: StrategyState }> = ({ state }) => {
    const { t } = useTranslation();
    const icons: Record<StrategyName, React.ReactElement> = {
        Scalping: <BarChartHorizontal className="text-accent-cyan" />,
        Farming: <DatabaseZap className="text-accent-green" />,
        LP: <Combine className="text-slate-500" />,
        Futures: <Zap className="text-accent-purple" />,
    };

    return (
        <Card>
            <div className="p-4">
                <div className="flex items-center gap-2 mb-2">
                    {icons[state.name]}
                    <h3 className="font-bold text-lg">{t(state.name.toLowerCase())}</h3>
                </div>
                <div className="space-y-1 text-sm">
                    <div className="flex justify-between"><span className="text-slate-500 dark:text-slate-400">{t('moduleCapital')}</span> <span>{formatCurrency(state.capital)}</span></div>
                    <div className="flex justify-between"><span className="text-slate-500 dark:text-slate-400">{t('moduleTotalPnl')}</span> <PnlText value={state.pnl} /></div>
                    {state.name === 'Scalping' && <>
                        <div className="flex justify-between"><span className="text-slate-500 dark:text-slate-400">{t('moduleTotalTrades')}</span> <span>{state.trades ?? 0}</span></div>
                        <div className="flex justify-between"><span className="text-slate-500 dark:text-slate-400">{t('moduleWinRate')}</span> <span>{((state.wins ?? 0) / (state.trades || 1) * 100).toFixed(1)}%</span></div>
                    </>}
                    {state.name === 'Farming' && <div className="flex justify-between"><span className="text-slate-500 dark:text-slate-400">{t('moduleRewards')}</span> <span className="text-accent-green">{formatCurrency(state.rewards ?? 0)}</span></div>}
                    {state.name === 'LP' && <>
                        <div className="flex justify-between"><span className="text-slate-500 dark:text-slate-400">{t('moduleFeesEarned')}</span> <span className="text-accent-green">{formatCurrency(state.fees ?? 0)}</span></div>
                        <div className="flex justify-between"><span className="text-slate-500 dark:text-slate-400">{t('moduleImpermanentLoss')}</span> <PnlText value={state.il ?? 0} /></div>
                    </>}
                     {state.name === 'Futures' && <div className="flex justify-between"><span className="text-slate-500 dark:text-slate-400">Open Position</span> <span>{state.openPosition ? `${state.openPosition.side}` : 'None'}</span></div>}
                </div>
            </div>
        </Card>
    );
};

const SimulationReport: React.FC<{ state: SimulationState, onReset: () => void }> = ({ state, onReset }) => {
    const { t } = useTranslation();
    // FIX: Replaced potentially unsafe Object.values().reduce() with a safer iteration over the STRATEGIES constant.
    // This ensures all strategies are accounted for and avoids errors if the state from localStorage is malformed.
    const finalBalance = STRATEGIES.reduce((sum, name) => sum + Number(state.strategies[name]?.capital || 0), 0);
    const totalPnl = finalBalance - state.initialCapital;
    const roi = (totalPnl / state.initialCapital) * 100;
    const isProfit = totalPnl >= 0;

    return (
        <Card className="animate-fade-in" highlight="purple">
            <div className="p-6 text-center">
                 <h2 className="text-2xl font-bold mb-2">{t('simulation.reportTitle')}</h2>
                 <p className="text-slate-500 dark:text-slate-400 mb-6">{t('simulation.complete')}</p>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
                    <div>
                        <p className="text-sm text-slate-500 dark:text-slate-400">{t('simulation.initialCapital')}</p>
                        <p className="text-2xl font-bold">{formatCurrency(state.initialCapital)}</p>
                    </div>
                     <div>
                        <p className="text-sm text-slate-500 dark:text-slate-400">{t('simulation.finalBalance')}</p>
                        <p className="text-2xl font-bold">{formatCurrency(finalBalance)}</p>
                    </div>
                     <div>
                        <p className="text-sm text-slate-500 dark:text-slate-400">{t('simulation.roi')}</p>
                        <p className={`text-2xl font-bold ${isProfit ? 'text-accent-green' : 'text-accent-red'}`}>{isProfit ? '+' : ''}{roi.toFixed(2)}%</p>
                    </div>
                </div>

                <h3 className="text-xl font-semibold mb-4">{t('simulation.strategyBreakdown')}</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    {STRATEGIES.map(name => <StrategyCard key={name} state={state.strategies[name]} />)}
                </div>

                <button onClick={onReset} className="mt-8 bg-accent-cyan text-slate-900 font-bold py-2 px-6 rounded-lg hover:opacity-90 transition-opacity flex items-center gap-2 mx-auto">
                    <RotateCcw size={16} /> {t('simulation.runNew')}
                </button>
            </div>
        </Card>
    );
};


const ControlButton: React.FC<{ onClick: () => void, 'aria-label': string, children: React.ReactNode, active?: boolean, className?: string }> = ({ onClick, 'aria-label': ariaLabel, children, active, className }) => (
    <button
        onClick={onClick}
        aria-label={ariaLabel}
        className={`w-14 h-14 md:w-16 md:h-16 flex items-center justify-center rounded-full transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-accent-cyan focus:ring-offset-white dark:focus:ring-offset-slate-800 ${className}
            ${active
                ? 'bg-accent-cyan text-slate-900 shadow-lg shadow-cyan-500/30'
                : 'bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-slate-600 dark:text-slate-300'
            }`}
    >
        {children}
    </button>
);


// --- MAIN COMPONENT ---
interface SimulationScreenProps {
    liveCoinData: LiveCoin[];
}

const SimulationScreen: React.FC<SimulationScreenProps> = ({ liveCoinData }) => {
    const { t } = useTranslation();

    const getInitialState = (): SimulationState => {
        const capitalPerStrategy = INITIAL_CAPITAL / STRATEGIES.length;
        return {
            isRunning: false,
            startTime: null,
            endTime: null,
            timeLeft: SIMULATION_DURATION,
            initialCapital: INITIAL_CAPITAL,
            strategies: {
                Scalping: { name: 'Scalping', capital: capitalPerStrategy, pnl: 0, trades: 0, wins: 0 },
                Farming: { name: 'Farming', capital: capitalPerStrategy, pnl: 0, rewards: 0 },
                LP: { name: 'LP', capital: capitalPerStrategy, pnl: 0, fees: 0, il: 0 },
                Futures: { name: 'Futures', capital: capitalPerStrategy, pnl: 0 },
            },
            eventLog: [],
        };
    };

    const [simulation, setSimulation] = useState<SimulationState>(() => {
        try {
            const savedState = localStorage.getItem(STORAGE_KEY);
            if (savedState) {
                const parsed = JSON.parse(savedState) as SimulationState;
                if (parsed.isRunning && parsed.endTime) {
                    const now = Date.now();
                    parsed.timeLeft = Math.max(0, parsed.endTime - now);
                    if (parsed.timeLeft === 0) parsed.isRunning = false;
                }
                return parsed;
            }
        } catch (error) {
            console.error("Failed to load simulation state:", error);
        }
        return getInitialState();
    });

    const [speed, setSpeed] = useState(1);

    const addEvent = useCallback((module: StrategyName | 'System', message: string) => {
        setSimulation(prev => {
            // FIX: Replaced potentially unsafe Object.values().reduce() with a safer iteration over the STRATEGIES constant.
            const totalBalance = STRATEGIES.reduce((sum, name) => sum + Number(prev.strategies[name]?.capital || 0), 0);
            const newEvent: SimEvent = {
                id: `${Date.now()}-${Math.random()}`,
                timestamp: Date.now(),
                module,
                message,
                balance: totalBalance,
            };
            return { ...prev, eventLog: [newEvent, ...prev.eventLog.slice(0, 199)] };
        });
    }, []);
    
    const runSimulationTick = useCallback((marketData: LiveCoin[]) => {
        const btcPrice = marketData.find(p => p.symbol === 'BTC')?.price;
        if (!btcPrice) return;

        setSimulation(prev => {
            const newStrategies: Record<StrategyName, StrategyState> = { ...prev.strategies };
            
            // --- Scalping Logic ---
            const scalping: StrategyState = { ...newStrategies.Scalping };
            if (Math.random() < 0.2) { // 20% chance to act
                if (scalping.openPosition) { // Close position
                    const pnl = (btcPrice - Number(scalping.openPosition.entryPrice)) * (Number(scalping.openPosition.size) / Number(scalping.openPosition.entryPrice));
                    scalping.capital = Number(scalping.capital) + pnl;
                    scalping.pnl = Number(scalping.pnl) + pnl;
                    scalping.trades = (scalping.trades ?? 0) + 1;
                    if (pnl > 0) scalping.wins = (scalping.wins ?? 0) + 1;
                    addEvent('Scalping', `Closed trade. PnL: ${formatCurrency(pnl)}`);
                    delete scalping.openPosition;
                } else { // Open position
                    const size = Number(scalping.capital) * 0.1;
                    scalping.openPosition = { side: 'Long', entryPrice: btcPrice, size };
                    addEvent('Scalping', `Opened LONG BTC at ${formatCurrency(btcPrice)}`);
                }
            }
            newStrategies.Scalping = scalping;

            // --- Farming Logic (20% APY) ---
            const farming: StrategyState = { ...newStrategies.Farming };
            const dailyYield = Number(farming.capital) * 0.20;
            const tickYield = dailyYield / (SIMULATION_DURATION / (15000 / Number(speed)));
            farming.rewards = (farming.rewards ?? 0) + tickYield;
            farming.pnl = Number(farming.pnl) + tickYield;
            farming.capital = Number(farming.capital) + tickYield;
            newStrategies.Farming = farming;
            
            // --- LP Logic ---
            const lp: StrategyState = { ...newStrategies.LP };
            const feeYield = Number(lp.capital) * 0.10 / (SIMULATION_DURATION / (15000 / Number(speed)));
            const ilChange = (Math.random() - 0.5) * Number(lp.capital) * 0.001; // Random IL
            lp.fees = (lp.fees ?? 0) + feeYield;
            lp.il = (lp.il ?? 0) + ilChange;
            lp.pnl = Number(lp.pnl) + feeYield + ilChange;
            lp.capital = Number(lp.capital) + feeYield + ilChange;
            newStrategies.LP = lp;

            // --- Futures Logic ---
            const futures: StrategyState = { ...newStrategies.Futures };
            if (futures.openPosition) {
                 const pnlChange = ((btcPrice / Number(futures.openPosition.entryPrice)) - 1) * Number(futures.openPosition.size) * 10; // 10x leverage
                 if (Math.random() < 0.1) { // 10% chance to close
                    futures.capital = Number(futures.capital) + pnlChange;
                    futures.pnl = Number(futures.pnl) + pnlChange;
                    addEvent('Futures', `Closed 10x LONG. PnL: ${formatCurrency(pnlChange)}`);
                    delete futures.openPosition;
                 }
            } else if (Math.random() < 0.05) { // 5% chance to open
                 futures.openPosition = { side: 'Long', entryPrice: btcPrice, size: Number(futures.capital) * 0.2 };
                 addEvent('Futures', `Opened 10x LONG BTC at ${formatCurrency(btcPrice)}`);
            }
            newStrategies.Futures = futures;


            return { ...prev, strategies: newStrategies };
        });
    }, [addEvent, speed]);

    // UI Clock Tick (every second)
    useEffect(() => {
        let clockInterval: number;
        if (simulation.isRunning && simulation.timeLeft > 0) {
            clockInterval = window.setInterval(() => {
                setSimulation(prev => {
                    if (!prev.endTime) return prev;
                    const newTimeLeft = Math.max(0, prev.endTime - Date.now());
                    if (newTimeLeft === 0) {
                        // FIX: Replaced potentially unsafe Object.values().reduce() with a safer iteration over the STRATEGIES constant.
                        addEvent('System', `Simulation complete. Final balance: ${formatCurrency(STRATEGIES.reduce((sum, name) => sum + Number(prev.strategies[name]?.capital || 0), 0))}`);
                        return { ...prev, isRunning: false, timeLeft: 0 };
                    }
                    return { ...prev, timeLeft: newTimeLeft };
                });
            }, 1000);
        }
        return () => {
            if (clockInterval) window.clearInterval(clockInterval);
        };
    }, [simulation.isRunning, simulation.endTime, addEvent]);

    // Logic Tick (uses props instead of fetching)
    useEffect(() => {
        let logicInterval: number;
        if (simulation.isRunning && simulation.timeLeft > 0 && liveCoinData.length > 0) {
            logicInterval = window.setInterval(() => {
                const simulationMarketData = liveCoinData.filter(c => ['BTC', 'ETH'].includes(c.symbol));
                if (simulationMarketData.length > 0) {
                    runSimulationTick(simulationMarketData);
                }
            }, 15000 / speed);
        }
        return () => {
            if (logicInterval) window.clearInterval(logicInterval);
        };
    }, [simulation.isRunning, simulation.timeLeft, runSimulationTick, speed, liveCoinData]);

    // Save state to localStorage
    useEffect(() => {
        try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(simulation));
        } catch (error) {
            console.error("Failed to save simulation state:", error);
        }
    }, [simulation]);
    
    const handleStart = () => {
        setSpeed(1);
        const now = Date.now();
        const initialState = getInitialState();
        setSimulation({
            ...initialState,
            isRunning: true,
            startTime: now,
            endTime: now + SIMULATION_DURATION,
            timeLeft: SIMULATION_DURATION,
            eventLog: [{
                id: `${now}`,
                timestamp: now,
                module: 'System',
                message: 'Simulation started.',
                balance: INITIAL_CAPITAL,
            }]
        });
    };
    
    const handleReset = () => {
        setSimulation(getInitialState());
        setSpeed(1);
    };

    const handleTogglePlayPause = () => {
        setSimulation(prev => {
            if (prev.isRunning) {
                // Pausing
                return { ...prev, isRunning: false, endTime: null };
            } else {
                // Resuming
                if (prev.timeLeft <= 0) return prev;
                return {
                    ...prev,
                    isRunning: true,
                    // Fix for: Argument of type 'unknown' is not assignable to parameter of type 'number'.
                    endTime: Date.now() + (Number(prev.timeLeft) / Number(speed)),
                };
            }
        });
    };
    
    const handleFastForward = () => {
        setSpeed(prevSpeed => {
            const newSpeed = prevSpeed === 1 ? FAST_FORWARD_SPEED : 1;
            setSimulation(prevSim => {
                if (prevSim.isRunning) {
                    return {
                        ...prevSim,
                        endTime: Date.now() + (Number(prevSim.timeLeft) / newSpeed),
                    };
                }
                return prevSim;
            });
            return newSpeed;
        });
    };

    const isComplete = simulation.startTime !== null && simulation.timeLeft <= 0;

    if (isComplete) {
        return <SimulationReport state={simulation} onReset={handleReset} />;
    }

    return (
        <div className="p-4 md:p-6 space-y-6">
            <div className="text-center">
                 <h1 className="text-3xl font-bold bg-gradient-to-r from-accent-cyan to-accent-purple text-transparent bg-clip-text">{t('simulation.title')}</h1>
                 <p className="text-slate-500 dark:text-slate-400 mt-1">{t('simulation.description')}</p>
            </div>
            
            {simulation.startTime === null ? (
                <Card className="text-center p-8">
                    <motion.button
                        onClick={handleStart}
                        className="bg-accent-green text-white font-bold py-4 px-8 rounded-lg text-lg flex items-center gap-3 mx-auto shadow-lg shadow-green-500/30"
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                    >
                        <Play size={24} /> {t('simulation.start')}
                    </motion.button>
                </Card>
            ) : (
                <Card>
                    <div className="p-6 flex flex-col items-center">
                        <FlipperClock timeLeft={simulation.timeLeft} />
                        <div className="mt-8 w-full max-w-xs">
                             <h3 className="text-sm font-semibold text-center text-slate-500 dark:text-slate-400 mb-4 uppercase tracking-wider">{t('simulation.manualTimeControl')}</h3>
                             <div className="flex items-center justify-center gap-4 md:gap-6">
                                <ControlButton
                                    onClick={handleTogglePlayPause}
                                    aria-label={t(simulation.isRunning ? 'simulation.pause' : 'simulation.play')}
                                >
                                    {simulation.isRunning ? <Square size={24} /> : <Play size={24} />}
                                </ControlButton>
                                <ControlButton
                                    onClick={handleFastForward}
                                    aria-label={t('simulation.speed')}
                                    active={speed > 1}
                                >
                                    <div className="flex items-center justify-center relative">
                                        <FastForward size={24} />
                                        {speed > 1 &&
                                            <motion.span
                                                initial={{ scale: 0 }}
                                                animate={{ scale: 1 }}
                                                className="absolute -bottom-1 -right-1 text-xs font-bold bg-accent-cyan text-slate-900 rounded-full w-5 h-5 flex items-center justify-center"
                                            >
                                                {speed}x
                                            </motion.span>
                                        }
                                    </div>
                                </ControlButton>
                                <ControlButton
                                    onClick={handleReset}
                                    aria-label={t('simulation.reset')}
                                >
                                    <RotateCcw size={24} />
                                </ControlButton>
                            </div>
                        </div>
                    </div>
                </Card>
            )}

            <Card>
                <div className="p-4 grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                    <div>
                        <p className="text-sm text-slate-500 dark:text-slate-400">{t('simulation.initialCapital')}</p>
                        <p className="text-xl font-bold">{formatCurrency(simulation.initialCapital)}</p>
                    </div>
                    <div>
                        <p className="text-sm text-slate-500 dark:text-slate-400">{t('simulation.totalProfitability')}</p>
                        <p className="text-xl font-bold">
                            {/* FIX: Replaced potentially unsafe Object.values().reduce() with a safer iteration over the STRATEGIES constant. */}
                            <PnlText value={STRATEGIES.reduce((sum, name) => sum + Number(simulation.strategies[name]?.pnl || 0), 0)} />
                        </p>
                    </div>
                     <div>
                        <p className="text-sm text-slate-500 dark:text-slate-400">Current Balance</p>
                        <p className="text-xl font-bold">{/* FIX: Replaced potentially unsafe Object.values().reduce() with a safer iteration over the STRATEGIES constant. */}
{formatCurrency(STRATEGIES.reduce((sum, name) => sum + Number(simulation.strategies[name]?.capital || 0), 0))}</p>
                    </div>
                </div>
            </Card>

            <div>
                <h2 className="text-xl font-semibold mb-3">{t('simulation.strategyBreakdown')}</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    {STRATEGIES.map(name => <StrategyCard key={name} state={simulation.strategies[name]} />)}
                </div>
            </div>

            <Card className="p-0">
                <div className="p-4 border-b border-slate-200 dark:border-slate-700">
                    <h2 className="text-lg font-semibold">{t('eventLog')}</h2>
                </div>
                <div className="h-64 overflow-y-auto p-4 space-y-2">
                    {simulation.eventLog.length === 0 ? (
                        <div className="flex items-center justify-center h-full text-slate-500 dark:text-slate-400">{t('simulation.logEmpty')}</div>
                    ) : (
                        <AnimatePresence>
                            {simulation.eventLog.map(event => (
                                <motion.div
                                    key={event.id}
                                    layout
                                    initial={{ opacity: 0, x: -20 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    exit={{ opacity: 0, x: 20 }}
                                    transition={{ duration: 0.2 }}
                                    className="flex items-start text-sm"
                                >
                                    <span className="font-mono text-xs text-slate-400 dark:text-slate-500 mr-3 mt-0.5 whitespace-nowrap">
                                        {new Date(event.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                                    </span>
                                    <p className="text-slate-600 dark:text-slate-300">
                                        <span className="font-semibold mr-1">[{event.module}]</span>
                                        {event.message}
                                    </p>
                                </motion.div>
                            ))}
                        </AnimatePresence>
                    )}
                </div>
            </Card>
        </div>
    );
};

export default SimulationScreen;