import React, { useState, useRef, useMemo } from 'react';
import Card from '../components/Card';
import Modal from '../components/Modal';
import { FaUserCircle, FaWallet } from 'react-icons/fa';
import { motion, AnimatePresence } from 'framer-motion';
import { useTranslation } from '../LanguageContext';
import { Crown, Edit, Camera, Save, X, Trophy } from 'lucide-react';
import { ProfileData } from '../types';
import { ACHIEVEMENTS } from '../constants';

interface ProfileScreenProps {
  areSmartAlertsEnabled: boolean;
  setAreSmartAlertsEnabled: (enabled: boolean) => void;
  totalCapital: number;
  totalPnl: number;
  profileData: ProfileData;
  setProfileData: (data: ProfileData) => void;
}

const ProfileScreen: React.FC<ProfileScreenProps> = ({ areSmartAlertsEnabled, setAreSmartAlertsEnabled, totalCapital, totalPnl, profileData, setProfileData }) => {
  const { t } = useTranslation();
  
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editFormData, setEditFormData] = useState(profileData);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const xp = useMemo(() => Math.max(0, Math.floor(totalPnl * 10)), [totalPnl]);
  const level = useMemo(() => Math.floor(Math.log2(xp / 100 + 1)) + 1, [xp]);

  const unlockedAchievements = useMemo(() => ACHIEVEMENTS.filter(a => a.unlocked(xp, level)), [xp, level]);

  const handleEditClick = () => {
    setEditFormData(profileData);
    setAvatarPreview(profileData.avatar || null);
    setIsEditModalOpen(true);
  };

  const handleCancelEdit = () => {
    setIsEditModalOpen(false);
    setAvatarPreview(null);
  };

  const handleSaveEdit = () => {
    setProfileData({ ...editFormData, avatar: avatarPreview || profileData.avatar });
    setIsEditModalOpen(false);
    setAvatarPreview(null);
  };

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onloadend = () => {
        setAvatarPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="p-4 md:p-6 space-y-6">
      <Card className="p-6 bg-gradient-to-br from-slate-800/80 to-slate-900/50 border-t-2 border-accent-purple/80 overflow-hidden">
        <div className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-6">
          <div className="relative">
            <div className="w-24 h-24 rounded-full border-4 border-accent-cyan shadow-cyan flex items-center justify-center bg-slate-700 animate-fade-in">
              {profileData.avatar ? (
                <img src={profileData.avatar} alt="User Avatar" className="w-full h-full object-cover rounded-full" />
              ) : (
                <FaUserCircle className="w-20 h-20 text-slate-500" />
              )}
            </div>
             <button onClick={handleEditClick} className="absolute -bottom-2 -right-2 bg-accent-cyan text-slate-900 p-2 rounded-full shadow-lg hover:scale-110 transition-transform">
                <Edit size={16} />
             </button>
          </div>

          <div className="text-center sm:text-left">
            <h1 className="text-3xl font-bold font-orbitron animate-fade-in bg-gradient-to-r from-accent-cyan to-accent-purple text-transparent bg-clip-text" style={{ animationDelay: '150ms' }}>
              {profileData.displayName}
            </h1>
            <p className="text-slate-400">@{profileData.username}</p>
            <div className="flex items-center justify-center sm:justify-start gap-4 mt-2">
              <span className="text-accent-purple font-semibold text-base animate-fade-in" style={{ animationDelay: '300ms' }}>Level {level} - Pro Trader</span>
            </div>
          </div>
        </div>
      </Card>
      
      <Card>
        <div className="p-4">
            <h2 className="font-semibold text-sm uppercase text-slate-400 mb-4 font-orbitron">Dashboard</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
              <div>
                <p className="text-2xl font-bold text-accent-cyan">{xp.toLocaleString()}</p>
                <p className="text-sm text-slate-400">XP</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-accent-cyan">{level}</p>
                <p className="text-sm text-slate-400">Level</p>
              </div>
               <div>
                <p className="text-2xl font-bold text-accent-cyan">{totalCapital.toLocaleString('en-US', { style: 'currency', currency: 'USD' })}</p>
                <p className="text-sm text-slate-400">Wallet Balance</p>
              </div>
              <div>
                 <p className={`text-2xl font-bold ${totalPnl >= 0 ? 'text-accent-green' : 'text-accent-red'}`}>
                    {totalPnl >= 0 ? '+' : ''}{totalPnl.toLocaleString('en-US', { style: 'currency', currency: 'USD' })}
                 </p>
                 <p className="text-sm text-slate-400">Total PnL</p>
              </div>
            </div>
        </div>
      </Card>
      
      <Card>
        <div className="p-6">
          <h2 className="text-xl font-semibold text-slate-50 mb-4 font-orbitron">{t('achievements')}</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {unlockedAchievements.map(ach => (
              <div key={ach.id} className="text-center p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                <ach.icon className="w-12 h-12 mx-auto text-accent-cyan" />
                <p className="font-bold mt-2 text-sm text-white">{t(`achievement.${ach.id}`)}</p>
                <p className="text-xs text-slate-400">{ach.description}</p>
              </div>
            ))}
          </div>
        </div>
      </Card>
      
      <Card>
        <div className="p-6">
          <h2 className="text-xl font-semibold text-slate-50 mb-4">User Settings</h2>
          <div className="space-y-4 max-w-md">
            <div className="flex items-center justify-between">
              <label htmlFor="smart-alerts" className="text-slate-300">{t('smartAlerts')}</label>
              <button
                id="smart-alerts"
                onClick={() => setAreSmartAlertsEnabled(!areSmartAlertsEnabled)}
                className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors duration-300 ${areSmartAlertsEnabled ? 'bg-accent-cyan' : 'bg-slate-700'}`}
                role="switch" aria-checked={areSmartAlertsEnabled}
              >
                <span className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform duration-300 ${areSmartAlertsEnabled ? 'translate-x-6' : 'translate-x-1'}`} />
              </button>
            </div>
             <div className="flex items-center justify-between">
              <span className="text-slate-300">Email</span>
              <span className="text-slate-400 font-mono">{profileData.email}</span>
            </div>
          </div>
        </div>
      </Card>

      <AnimatePresence>
        {isEditModalOpen && (
          <Modal isOpen={isEditModalOpen} onClose={handleCancelEdit} onConfirm={handleSaveEdit} title="Edit Profile" confirmText="Save Changes" confirmColor="cyan">
            <div className="space-y-6 p-4">
              <div className="flex flex-col items-center">
                <div className="relative w-28 h-28">
                  <div className="w-28 h-28 rounded-full border-4 border-accent-purple shadow-purple flex items-center justify-center bg-slate-700">
                    {avatarPreview ? (
                      <img src={avatarPreview} alt="Avatar Preview" className="w-full h-full object-cover rounded-full" />
                    ) : (
                      <FaUserCircle className="w-24 h-24 text-slate-500" />
                    )}
                  </div>
                  <input type="file" accept="image/*" ref={fileInputRef} onChange={handleAvatarChange} className="hidden" capture="user" />
                  <button onClick={() => fileInputRef.current?.click()} className="absolute bottom-0 right-0 bg-accent-cyan text-slate-900 p-2 rounded-full shadow-lg hover:scale-110 transition-transform">
                    <Camera size={18} />
                  </button>
                </div>
              </div>
              <div className="space-y-4">
                 <div>
                    <label className="block text-sm font-medium text-slate-400 mb-1">Username</label>
                    <input type="text" value={editFormData.username} onChange={e => setEditFormData({...editFormData, username: e.target.value})} className="w-full bg-slate-900 border border-slate-600 rounded-md px-3 py-1.5 text-sm" />
                 </div>
                 <div>
                    <label className="block text-sm font-medium text-slate-400 mb-1">Display Name</label>
                    <input type="text" value={editFormData.displayName} onChange={e => setEditFormData({...editFormData, displayName: e.target.value})} className="w-full bg-slate-900 border border-slate-600 rounded-md px-3 py-1.5 text-sm" />
                 </div>
                 <div>
                    <label className="block text-sm font-medium text-slate-400 mb-1">Email</label>
                    <input type="email" value={editFormData.email} onChange={e => setEditFormData({...editFormData, email: e.target.value})} className="w-full bg-slate-900 border border-slate-600 rounded-md px-3 py-1.5 text-sm" />
                 </div>
              </div>
            </div>
          </Modal>
        )}
      </AnimatePresence>
    </div>
  );
};

export default ProfileScreen;