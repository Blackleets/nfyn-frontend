import React, { useState, useMemo, useEffect } from 'react';
import { GovernanceProposal } from '../types';
import Card from '../components/Card';
import { useTranslation } from '../LanguageContext';
import { FaPlus, FaTrash } from 'react-icons/fa';
import { motion, AnimatePresence } from 'framer-motion';
import { GOVERNANCE_PROPOSALS } from '../constants';
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Cell } from 'recharts';
import { Vote, CheckCircle, XCircle, Clock } from 'lucide-react';

const StatusBadge: React.FC<{ status: GovernanceProposal['status'] }> = ({ status }) => {
    const styles = {
        Active: 'bg-accent-cyan/20 text-accent-cyan',
        Passed: 'bg-accent-green/20 text-accent-green',
        Failed: 'bg-accent-red/20 text-accent-red',
    };
    const icons = {
        Active: <Clock size={14} />,
        Passed: <CheckCircle size={14} />,
        Failed: <XCircle size={14} />,
    };
    return (
        <span className={`px-3 py-1 text-sm font-bold rounded-full flex items-center gap-1.5 ${styles[status]}`}>
            {icons[status]} {status}
        </span>
    );
};

const Countdown: React.FC<{ endDate: number }> = ({ endDate }) => {
    const { t } = useTranslation();
    const [timeLeft, setTimeLeft] = useState(endDate - Date.now());

    useEffect(() => {
        const timer = setInterval(() => {
            setTimeLeft(endDate - Date.now());
        }, 1000);
        return () => clearInterval(timer);
    }, [endDate]);

    if (timeLeft <= 0) return <span className="text-slate-400">{t('gov.ended')}</span>;

    const days = Math.floor(timeLeft / (1000 * 60 * 60 * 24));
    const hours = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));

    return (
        <span className="font-mono">
            {t('gov.endsIn')} {days}{t('gov.days')} {hours}{t('gov.hours')} {minutes}{t('gov.minutes')}
        </span>
    );
};

const ProposalCard: React.FC<{ proposal: GovernanceProposal, onVote: (id: string, vote: 'For' | 'Against') => void }> = ({ proposal, onVote }) => {
    const { t } = useTranslation();
    const [expanded, setExpanded] = useState(false);

    const totalVotes = proposal.votesFor + proposal.votesAgainst;
    const forPercentage = totalVotes > 0 ? (proposal.votesFor / totalVotes) * 100 : 0;
    const againstPercentage = totalVotes > 0 ? (proposal.votesAgainst / totalVotes) * 100 : 0;
    
    const chartData = [
        { name: 'Votes', For: forPercentage, Against: againstPercentage }
    ];

    return (
        <Card className="p-0 overflow-hidden">
            <div className="p-4 cursor-pointer" onClick={() => setExpanded(!expanded)}>
                <div className="flex justify-between items-start gap-4">
                    <h3 className="text-lg font-bold text-slate-50">{proposal.title}</h3>
                    <StatusBadge status={proposal.status} />
                </div>
                <div className="text-sm text-slate-400 mt-2">
                    {proposal.status === 'Active' ? <Countdown endDate={proposal.endDate} /> : <span>&nbsp;</span>}
                </div>
            </div>
            <AnimatePresence>
                {expanded && (
                    <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.3, ease: "easeInOut" }}
                        className="overflow-hidden"
                    >
                        <div className="border-t border-slate-800 p-4 space-y-4">
                            <p className="text-sm text-slate-300">{proposal.description}</p>
                            
                            <div>
                                <h4 className="font-semibold mb-2">{t('gov.votes')}</h4>
                                <div className="h-20">
                                    <ResponsiveContainer width="100%" height="100%">
                                        <BarChart data={chartData} layout="vertical" barCategoryGap={0}>
                                            <XAxis type="number" hide domain={[0, 100]} />
                                            <YAxis type="category" dataKey="name" hide />
                                            <Bar dataKey="For" stackId="a" fill="#8cff00" background={{ fill: '#1a1a1f' }} />
                                            <Bar dataKey="Against" stackId="a" fill="#EF4444" />
                                        </BarChart>
                                    </ResponsiveContainer>
                                </div>
                                <div className="flex justify-between text-sm mt-1">
                                    <span className="text-accent-green">{t('gov.for')}: {proposal.votesFor.toLocaleString()} ({forPercentage.toFixed(1)}%)</span>
                                    <span className="text-accent-red">{t('gov.against')}: {proposal.votesAgainst.toLocaleString()} ({againstPercentage.toFixed(1)}%)</span>
                                </div>
                            </div>

                            {proposal.status === 'Active' && (
                                <div>
                                    <h4 className="font-semibold mb-2">{t('gov.castVote')}</h4>
                                    <div className="flex gap-4">
                                        <motion.button whileTap={{ scale: 0.95 }} onClick={() => onVote(proposal.id, 'For')} className="w-full bg-accent-green/80 hover:bg-accent-green text-white font-bold py-2 rounded-lg transition-colors">
                                            {t('gov.for')}
                                        </motion.button>
                                        <motion.button whileTap={{ scale: 0.95 }} onClick={() => onVote(proposal.id, 'Against')} className="w-full bg-accent-red/80 hover:bg-accent-red text-white font-bold py-2 rounded-lg transition-colors">
                                            {t('gov.against')}
                                        </motion.button>
                                    </div>
                                </div>
                            )}
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </Card>
    );
};

const GovernanceScreen: React.FC = () => {
    const { t } = useTranslation();
    const [proposals, setProposals] = useState<GovernanceProposal[]>(GOVERNANCE_PROPOSALS);
    const [statusFilter, setStatusFilter] = useState<'All' | 'Active' | 'Passed' | 'Failed'>('All');

    const handleVote = (id: string, vote: 'For' | 'Against') => {
        setProposals(prev => prev.map(p => {
            if (p.id === id) {
                // Simulate vote with wallet weight
                const votePower = Math.floor(Math.random() * 500) + 50;
                return {
                    ...p,
                    votesFor: vote === 'For' ? p.votesFor + votePower : p.votesFor,
                    votesAgainst: vote === 'Against' ? p.votesAgainst + votePower : p.votesAgainst,
                };
            }
            return p;
        }));
    };
    
    const filteredProposals = useMemo(() => {
        return proposals
            .filter(p => statusFilter === 'All' || p.status === statusFilter)
            .sort((a, b) => b.endDate - a.endDate); // Show most recent first
    }, [proposals, statusFilter]);

    const filterOptions = [
        { value: 'All', labelKey: 'gov.status.all' },
        { value: 'Active', labelKey: 'gov.status.active' },
        { value: 'Passed', labelKey: 'gov.status.passed' },
        { value: 'Failed', labelKey: 'gov.status.failed' },
    ];

    return (
        <div className="p-4 md:p-6 space-y-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                    <h1 className="text-3xl font-bold bg-gradient-to-r from-accent-cyan to-accent-purple text-transparent bg-clip-text">{t('gov.title')}</h1>
                    <p className="text-slate-400">{t('gov.description')}</p>
                </div>
                <motion.button whileHover={{ scale: 1.05 }} className="bg-accent-cyan text-slate-900 font-bold py-2 px-4 rounded-lg flex items-center gap-2">
                    <FaPlus /> {t('gov.newProposal')}
                </motion.button>
            </div>
            
            <Card className="p-4">
                <div className="flex space-x-1 p-0.5 bg-slate-800 rounded-md">
                    {filterOptions.map(opt => (
                        <button key={opt.value} onClick={() => setStatusFilter(opt.value as any)}
                            className={`flex-1 px-2 py-1 text-sm font-semibold rounded transition-colors ${statusFilter === opt.value ? 'bg-slate-700 shadow text-white' : 'text-slate-400 hover:bg-slate-700/50'}`}>
                            {t(opt.labelKey)}
                        </button>
                    ))}
                </div>
            </Card>

            <div className="space-y-4">
                <AnimatePresence>
                    {filteredProposals.map(p => (
                        <motion.div key={p.id} layout initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                            <ProposalCard proposal={p} onVote={handleVote} />
                        </motion.div>
                    ))}
                </AnimatePresence>
            </div>
        </div>
    );
};

export default GovernanceScreen;
