

import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import Header from './components/Header';
import DashboardScreen from './screens/HomeScreen';
import TradingScreen from './screens/TradingScreen';
import NewsScreen from './screens/NewsScreen';
import LearnScreen from './screens/LearnScreen';
import ProfileScreen from './screens/ProfileScreen';
import BotTradingScreen from './screens/BotTradingScreen';
import OnboardingScreen from './nfyn/onboarding/OnboardingScreen';
import GovernanceScreen from './screens/PlannerScreen';
import SimulationScreen from './screens/SimulationScreen';
import TokenDiscoveryScreen from './screens/TokenDiscoveryScreen'; // Renamed import from TokensScreen
import MarketMosaicScreen from './nfyn/pages/market';
import MarketOverviewScreen from './screens/MarketOverviewScreen';
import CommunityScreen from './screens/CommunityScreen';
import { BotEvent, ModuleState, ModuleName, BotTrade, ScalpingRiskProfile, ScheduledEvent, AppNotification, Screen, LiveCoin, TickerAsset, ProfileData, ChatChannel } from './types';
import { NfynLogo } from './components/icons/Logo';
import { Sun, Moon, Languages, FlaskConical, Star, LayoutGrid, Compass, Vote, BrainCircuit } from 'lucide-react';
import BottomNav from './components/BottomNav';
import NotificationCenter from './components/NotificationCenter';
import NotificationPanel from './components/NotificationPanel';
import Modal from './components/Modal';
import { useTranslation } from './LanguageContext';
import { motion, AnimatePresence } from 'framer-motion';
import { FaHome, FaRobot, FaBell, FaGraduationCap, FaCalendarAlt, FaUsers } from 'react-icons/fa';
import { MdShowChart } from 'react-icons/md';
import { HiUsers } from 'react-icons/hi';
import { fetchMarketData, fetchForexDataForTicker } from './services/coingeckoService';
import TickerTape from './components/TickerTape';
import CosmicBackground from './components/CosmicBackground';
import { useMobile } from './hooks/useMobile';

export type Theme = 'light' | 'dark';

const INITIAL_CAPITAL = 45780;
const MODULE_NAMES: ModuleName[] = ['Scalping', 'Grid', 'Sniper', 'Farming', 'LP', 'Futures'];


const MASTER_COIN_IDS = [
    'bitcoin', 'ethereum', 'solana', 'binancecoin', 'xrp', 'cardano', 'dogecoin', 'polygon', 'tether',
    'shiba-inu', 'pepe', 'the-open-ton', 'bonk', 'polkadot', 'tron', 'litecoin', 'near', 'chainlink'
];


const Sidebar: React.FC<{
  activeScreen: Screen;
  setActiveScreen: (screen: Screen) => void;
  isSidebarOpen: boolean;
  theme: Theme;
  toggleTheme: () => void;
}> = ({ activeScreen, setActiveScreen, isSidebarOpen, theme, toggleTheme }) => {
  const { t, language, setLanguage } = useTranslation();
  
  const navItems: { labelKey: string; screen: Screen; icon: React.ReactElement<{ className?: string }> }[] = [
    { labelKey: 'Dashboard', screen: 'Dashboard', icon: <FaHome /> },
    { labelKey: 'MarketOverview', screen: 'MarketOverview', icon: <Compass /> },
    { labelKey: 'Community', screen: 'Community', icon: <FaUsers /> },
    { labelKey: 'Trade', screen: 'Trade', icon: <MdShowChart /> },
    { labelKey: 'Automate', screen: 'Automate', icon: <FaRobot /> },
    { labelKey: 'Market', screen: 'Market', icon: <LayoutGrid /> },
    { labelKey: 'TokenDiscovery', screen: 'Tokens', icon: <Star /> }, // Label updated
    { labelKey: 'Simulation', screen: 'Simulation', icon: <FlaskConical /> },
    { labelKey: 'Intel', screen: 'Intel', icon: <FaBell /> },
    { labelKey: 'Governance', screen: 'Governance', icon: <Vote /> },
    { labelKey: 'Academy', screen: 'Academy', icon: <FaGraduationCap /> },
    { labelKey: 'Profile', screen: 'Profile', icon: <HiUsers /> },
  ];

  return (
    <aside className={`fixed top-0 left-0 z-40 w-64 h-screen bg-dark-card/80 backdrop-blur-lg border-r border-slate-800 transition-transform transition-colors duration-300 md:translate-x-0 ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
      <div className="h-full px-3 py-4 overflow-y-auto flex flex-col">
        <div className="flex items-center justify-center mb-10 h-16">
          <NfynLogo className="w-24 h-9" />
        </div>
        <ul className="space-y-2 font-medium">
          {navItems.map(item => (
            <li key={item.screen}>
              <motion.a
                href="#"
                onClick={(e) => { e.preventDefault(); setActiveScreen(item.screen); }}
                className={`flex items-center p-3 rounded-lg group transition-all duration-200 relative ${activeScreen === item.screen ? 'bg-accent-cyan/10 text-accent-cyan' : 'text-slate-400 hover:bg-slate-800 hover:text-slate-50'}`}
                whileHover={{ x: 5, boxShadow: '0 0 15px rgba(0, 240, 255, 0.4)' }}
                transition={{ type: 'spring', stiffness: 400, damping: 15 }}
              >
                {activeScreen === item.screen && <motion.div layoutId="sidebar-active-indicator" className="absolute left-0 top-2 bottom-2 w-1 bg-accent-cyan rounded-r-full"></motion.div>}
                <motion.div whileHover={{ scale: 1.2, rotate: 5 }} transition={{ type: 'spring', stiffness: 400, damping: 10 }}>
                  {React.cloneElement(item.icon, { className: 'w-6 h-6' })}
                </motion.div>
                <span className="ml-3">{t(item.labelKey)}</span>
              </motion.a>
            </li>
          ))}
        </ul>
        <div className="mt-auto pt-4 space-y-2">
            <button onClick={toggleTheme} className="flex items-center justify-center w-full p-3 rounded-lg text-slate-400 hover:bg-slate-800 hover:text-slate-50 transition-colors duration-200">
                {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
                <span className="ml-3 text-sm font-medium">{t(theme === 'dark' ? 'lightMode' : 'darkMode')}</span>
            </button>
             <div className="relative">
                <Languages className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 pointer-events-none" />
                <select 
                  value={language} 
                  onChange={(e) => setLanguage(e.target.value as 'en' | 'es')}
                  className="w-full appearance-none bg-transparent p-3 pl-10 rounded-lg text-slate-400 hover:bg-slate-800 text-sm font-medium focus:outline-none"
                  aria-label="Select language"
                >
                    <option value="en" className="bg-slate-800">English</option>
                    <option value="es" className="bg-slate-800">Español</option>
                </select>
            </div>
        </div>
      </div>
    </aside>
  );
};


const App: React.FC = () => {
  const [showOnboarding, setShowOnboarding] = useState(() => !localStorage.getItem('nfyn_onboarding_v2_completed'));
  const [activeScreen, setActiveScreen] = useState<Screen>('Dashboard');
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const [theme, setTheme] = useState<Theme>('dark');
  const [liveCoinData, setLiveCoinData] = useState<LiveCoin[]>([]);
  const [liveForexData, setLiveForexData] = useState<TickerAsset[]>([]);
  const { t } = useTranslation();
  const isMobile = useMobile();

  const [isNotificationPanelOpen, setIsNotificationPanelOpen] = useState(false);
  const [isWalletModalOpen, setIsWalletModalOpen] = useState(false);
  const [isConnectingWallet, setIsConnectingWallet] = useState(false);
  const [isWalletConnected, setIsWalletConnected] = useState(false);
  const [areSmartAlertsEnabled, setAreSmartAlertsEnabled] = useState(true);
  const [initialChatChannel, setInitialChatChannel] = useState<ChatChannel | 'AI' | undefined>(undefined);
  
  const [profileData, setProfileData] = useState<ProfileData>({
    username: 'lee_renmos',
    displayName: 'Lee renmos',
    email: 'lee.renmos@example.com',
    avatar: '', 
  });

  const lastBalanceAlertCapital = useRef(INITIAL_CAPITAL);
  const lastNotifiedLevel = useRef(1);
  const previousPricesRef = useRef<Map<string, number>>(new Map());

  const handleOnboardingComplete = () => {
    localStorage.setItem('nfyn_onboarding_v2_completed', 'true');
    setShowOnboarding(false);
  };

  const toggleTheme = () => setTheme(prev => prev === 'dark' ? 'light' : 'dark');

  useEffect(() => {
    document.documentElement.classList.add('dark');
  }, []);
  
    const [notifications, setNotifications] = useState<AppNotification[]>([]);
  
  const addNotification = useCallback((message: string) => {
    setNotifications(prev => [{ id: Date.now(), message, read: false }, ...prev.slice(0, 49)]);
  }, []);

  const removeNotification = useCallback((id: number) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }, []);

  useEffect(() => {
    const TICKER_FOREX_PAIRS = ['EUR/USD', 'GBP/USD', 'USD/JPY', 'AUD/USD', 'USD/CAD'];

    const updateMarketData = async () => {
      const cryptoDataPromise = fetchMarketData(MASTER_COIN_IDS);
      const forexDataPromise = fetchForexDataForTicker(TICKER_FOREX_PAIRS);

      const [cryptoData] = await Promise.all([
          cryptoDataPromise,
          forexDataPromise.then(setLiveForexData)
      ]);
      
      if (cryptoData.length > 0) {
        setLiveCoinData(cryptoData);

        // Price change alert logic
        if (areSmartAlertsEnabled && previousPricesRef.current.size > 0) {
            for (const coin of cryptoData) {
                const prevPrice = previousPricesRef.current.get(coin.id);
                if (prevPrice) {
                    const change = ((coin.price - prevPrice) / prevPrice) * 100;
                    if (Math.abs(change) > 5) { // 5% threshold
                        addNotification(t('alert.priceSpike', { symbol: coin.symbol }));
                        // Update ref to avoid repeated notifications for the same spike
                        previousPricesRef.current.set(coin.id, coin.price);
                    }
                }
            }
        }
        
        // Update previous prices ref after checking
        cryptoData.forEach(coin => previousPricesRef.current.set(coin.id, coin.price));
      }
    };

    updateMarketData();
    const intervalId = setInterval(updateMarketData, 60000);

    return () => clearInterval(intervalId);
  }, [addNotification, areSmartAlertsEnabled, t]);

  const tickerAssets: TickerAsset[] = useMemo(() => {
    const cryptoForTicker: TickerAsset[] = liveCoinData
      .filter(c => ['BTC', 'ETH', 'SOL', 'BNB', 'XRP', 'DOGE'].includes(c.symbol))
      .map(c => ({
        symbol: c.symbol,
        price: c.price,
        change: c.change24h
      }));
    return [...cryptoForTicker, ...liveForexData];
  }, [liveCoinData, liveForexData]);

  const [isBotRunning, setIsBotRunning] = useState(false);
  const [eventLog, setEventLog] = useState<BotEvent[]>([]);
  const [scalpingRiskProfile, setScalpingRiskProfile] = useState<ScalpingRiskProfile>('Moderate');

  const [modules, setModules] = useState<ModuleState[]>(() =>
    MODULE_NAMES.map(name => {
        const baseModule = {
            name,
            capital: INITIAL_CAPITAL / MODULE_NAMES.length,
            pnl: 0,
            status: 'Idle',
        };

        switch (name) {
            case 'Scalping':
                return { 
                    ...baseModule, 
                    totalTrades: 0, 
                    wins: 0, 
                    winRate: 0, 
                    openPositions: [], 
                    closedTrades: [],
                    stopLossPercent: 1.5,
                    takeProfitPercent: 3,
                    positionSizePercent: 10,
                };
            case 'Grid':
                return { 
                    ...baseModule, 
                    gridCount: 5, 
                    upperPrice: 72000, 
                    lowerPrice: 65000,
                    gridStopLossPrice: 63000,
                    gridTakeProfitPrice: 75000,
                };
            case 'Sniper':
                return { 
                    ...baseModule, 
                    snipes: 0, 
                    avgProfit: 0,
                    stopLossPercent: 10,
                    takeProfitPercent: 50,
                    positionSizePercent: 5,
                };
            case 'Farming':
                return {
                    ...baseModule,
                    farmingPools: [
                        { id: '1', platform: 'MockFarm', pair: 'ETH-USDT', apy: 15.0, risk: 'Medium', stakedAmount: 0, rewardsEarned: 0 },
                    ],
                    minApyThreshold: 10, // Default for AI analysis
                };
            case 'LP':
                return {
                    ...baseModule,
                    lpPositions: [],
                    rangeTolerance: 5, // Default for AI analysis
                };
            case 'Futures':
                return {
                    ...baseModule,
                    futuresPositions: [],
                    maxLeverage: 20,
                    fundingRateThreshold: 0.001, // Default for AI analysis
                    positionSizePercent: 10,
                    stopLossPercent: 5,
                };
            default:
                return baseModule;
        }
    })
  );
  
  const totalCapital = useMemo(() => modules.reduce((sum, m) => sum + m.capital, 0), [modules]);
  const totalPnl = useMemo(() => modules.reduce((sum, m) => sum + m.pnl, 0), [modules]);

  const addEvent = useCallback((module: ModuleName | 'System', message: string, pnl?: number) => {
      const newEvent: BotEvent = {
          id: `${Date.now()}-${Math.random()}`,
          timestamp: Date.now(),
          module,
          message,
          pnl,
      };
      setEventLog(prev => [newEvent, ...prev.slice(0, 49)]);
  }, []);

  const runSimulation = useCallback(() => {
    // Get BTC price for simulation
    const btcPrice = liveCoinData.find(coin => coin.symbol === 'BTC')?.price || 70000;
    
    setModules(prevModules => {
        return prevModules.map(module => {
            if (module.status !== 'Active') return module;

            let pnlChange = 0;
            let newModuleState = { ...module };

            switch (module.name) {
                case 'Scalping':
                    if (Math.random() < 0.3) {
                       pnlChange = (Math.random() - 0.45) * module.capital * 0.01;
                       newModuleState.pnl += pnlChange;
                       newModuleState.capital += pnlChange;
                       newModuleState.totalTrades = (newModuleState.totalTrades ?? 0) + 1;
                       if (pnlChange > 0) newModuleState.wins = (newModuleState.wins ?? 0) + 1;
                       newModuleState.winRate = ((newModuleState.wins ?? 0) / (newModuleState.totalTrades || 1)) * 100;
                       addEvent('Scalping', `Quick trade executed`, pnlChange);
                    }
                    break;
                case 'Grid':
                    if (Math.random() < 0.5) {
                        pnlChange = Math.random() * module.capital * 0.005;
                        newModuleState.pnl += pnlChange;
                        newModuleState.capital += pnlChange;
                        addEvent('Grid', `Grid trade closed in profit`, pnlChange);
                    }
                    break;
                case 'Sniper':
                    if (Math.random() < 0.02) {
                        pnlChange = (Math.random() * 0.5 + 0.1) * module.capital;
                        newModuleState.pnl += pnlChange;
                        newModuleState.capital += pnlChange;
                        newModuleState.snipes = (newModuleState.snipes ?? 0) + 1;
                        addEvent('Sniper', `New token launch SNIPED!`, pnlChange);
                    }
                    break;
                case 'Farming':
                    // Simulate daily yield
                    if (newModuleState.farmingPools && newModuleState.farmingPools.length > 0) {
                        const dailyYieldRate = (newModuleState.farmingPools[0].apy / 365) / 100;
                        const yieldAmount = module.capital * dailyYieldRate * (Math.random() * 1.2 + 0.8); // Randomize slightly
                        pnlChange = yieldAmount;
                        newModuleState.pnl += pnlChange;
                        newModuleState.capital += pnlChange;
                        newModuleState.farmingPools[0].rewardsEarned = (newModuleState.farmingPools[0].rewardsEarned ?? 0) + pnlChange;
                        addEvent('Farming', `Earned ${pnlChange.toFixed(2)} in rewards`);
                    }
                    break;
                case 'LP':
                    // Simulate fees and impermanent loss/gain
                    if (newModuleState.lpPositions && newModuleState.lpPositions.length > 0) {
                        const feeEarned = module.capital * 0.0005 * (Math.random() * 2); // 0.05% of capital as fees
                        const impermanentLoss = (Math.random() - 0.5) * module.capital * 0.001;
                        pnlChange = feeEarned + impermanentLoss;
                        newModuleState.pnl += pnlChange;
                        newModuleState.capital += pnlChange;
                        newModuleState.lpPositions[0].fees = (newModuleState.lpPositions[0].fees ?? 0) + feeEarned;
                        newModuleState.lpPositions[0].il = (newModuleState.lpPositions[0].il ?? 0) + impermanentLoss;
                        addEvent('LP', `LP fees and impermanent loss updated`, pnlChange);
                    }
                    break;
                case 'Futures':
                    // Simulate futures position PnL based on BTC price
                    if (newModuleState.futuresPositions && newModuleState.futuresPositions.length > 0) {
                        const pos = newModuleState.futuresPositions[0];
                        const priceDiff = btcPrice - pos.entry;
                        const potentialPnl = (priceDiff / pos.entry) * pos.size * pos.leverage;
                        
                        // Close position randomly or due to target/stop loss
                        if (Math.random() < 0.1) {
                            pos.currentPrice = btcPrice;
                            pos.pnl = potentialPnl;
                            pnlChange = potentialPnl;
                            newModuleState.pnl += pnlChange;
                            newModuleState.capital += pnlChange;
                            newModuleState.futuresPositions = []; // Close position
                            addEvent('Futures', `Closed position on BTC. PnL: ${pnlChange.toFixed(2)}`, pnlChange);
                        } else {
                            pos.currentPrice = btcPrice;
                            pos.pnl = potentialPnl; // Update floating PnL
                            newModuleState.futuresPositions = [pos]; // Keep updated position
                        }
                    } else if (Math.random() < 0.05 && btcPrice > 0) { // Open new position
                        const leverage = newModuleState.maxLeverage ?? 10;
                        const positionSize = (module.capital * (newModuleState.positionSizePercent ?? 10) / 100);
                        newModuleState.futuresPositions = [{
                            id: `fut-${Date.now()}`,
                            symbol: 'BTC',
                            leverage: leverage,
                            entry: btcPrice,
                            pnl: 0,
                            side: 'Long',
                            size: positionSize,
                            currentPrice: btcPrice,
                        }];
                        addEvent('Futures', `Opened new LONG BTC futures position at ${btcPrice.toFixed(2)}`);
                    }
                    break;
            }
            return newModuleState;
        });
    });
}, [addEvent, liveCoinData]);
  
  const handleClearLog = useCallback(() => setEventLog([]), []);
  
  const handleUpdateModule = useCallback((updatedModule: ModuleState) => {
    setModules(prev => 
        prev.map(m => m.name === updatedModule.name ? { ...m, ...updatedModule } : m)
    );
  }, []);

  useEffect(() => {
      let interval: number | null = null;
      if (isBotRunning) {
          addEvent('System', 'Bot activated. All modules are online.');
          setModules(prev => prev.map(m => ({ ...m, status: 'Active' })));
          interval = window.setInterval(runSimulation, 2000);
      } else {
           if (eventLog.length > 0 && eventLog[0]?.module !== 'System' || eventLog[0]?.message.includes('activated')) {
              addEvent('System', 'Bot stopped. Holding all positions.');
           }
           setModules(prev => prev.map(m => ({ ...m, status: 'Idle' })));
      }
      return () => {
          if (interval) window.clearInterval(interval);
      };
  }, [isBotRunning, runSimulation, addEvent]);

  const [watchlist, setWatchlist] = useState<string[]>(() => {
    try {
        return JSON.parse(localStorage.getItem('nfyn_watchlist_v2') || '[]');
    } catch { return []; }
  });

  useEffect(() => {
      localStorage.setItem('nfyn_watchlist_v2', JSON.stringify(watchlist));
  }, [watchlist]);

  const toggleWatchlist = (coinId: string) => {
      setWatchlist(prev => 
          prev.includes(coinId) ? prev.filter(id => id !== coinId) : [...prev, coinId]
      );
  };
  
  // SMART NOTIFICATION & GAMIFICATION SERVICE
  useEffect(() => {
    if (!areSmartAlertsEnabled) return;

    // Balance alert
    const capitalChangePercent = ((totalCapital - lastBalanceAlertCapital.current) / lastBalanceAlertCapital.current) * 100;
    if (Math.abs(capitalChangePercent) >= 2) {
        addNotification(t('balanceAlert', { change: capitalChangePercent.toFixed(2) }));
        lastBalanceAlertCapital.current = totalCapital;
    }
    
    // Level up alert
    const xp = Math.max(0, Math.floor(totalPnl * 10));
    const currentLevel = Math.floor(Math.log2(xp / 100 + 1)) + 1;
    if (currentLevel > lastNotifiedLevel.current) {
        addNotification(`🎉 ${t('levelUp', { level: currentLevel })}`);
        lastNotifiedLevel.current = currentLevel;
    }

    // Simulated Whale Alert
    if (Math.random() < 0.005) { // Low probability chance on each render
        const randomCoin = MASTER_COIN_IDS[Math.floor(Math.random() * MASTER_COIN_IDS.length)];
        addNotification(t('alert.whaleMove', { symbol: randomCoin.toUpperCase() }));
    }

  }, [totalCapital, totalPnl, areSmartAlertsEnabled, addNotification, t]);

  const unreadNotificationCount = useMemo(() => notifications.filter(n => !n.read).length, [notifications]);

  const handleOpenNotifications = () => {
    setIsNotificationPanelOpen(true);
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const handleClearNotifications = () => setNotifications([]);

  const handleWalletConnect = () => {
    setIsWalletModalOpen(true);
    setIsConnectingWallet(true);
    setTimeout(() => {
      setIsConnectingWallet(false);
      setIsWalletConnected(true);
      addNotification('Wallet connected successfully!');
      setTimeout(() => setIsWalletModalOpen(false), 1500);
    }, 2000);
  };

  const screenTitleMap: Record<Screen, string> = {
      Dashboard: t('Dashboard'), MarketOverview: t('MarketOverview'), Trade: t('Trade'),
      Automate: t('Automate'), Market: t('Market'), Tokens: t('TokenDiscovery'), // Updated key
      Simulation: t('Simulation'), Intel: t('Intel'), Governance: t('Governance'),
      Academy: t('Academy'), Profile: t('Profile'), Community: t('Community'),
  };
  
  const xp = useMemo(() => Math.max(0, Math.floor(totalPnl * 10)), [totalPnl]);

  const renderScreen = () => {
    switch (activeScreen) {
      case 'Dashboard': return <DashboardScreen totalCapital={totalCapital} totalPnl={totalPnl} initialCapital={INITIAL_CAPITAL} theme={theme} liveCoinData={liveCoinData} modules={modules} />;
      case 'MarketOverview': return <MarketOverviewScreen />;
      case 'Community': return <CommunityScreen initialActiveChannel={initialChatChannel} onChannelChange={setInitialChatChannel} />;
      case 'Trade': return <TradingScreen liveCoinData={liveCoinData} isWalletConnected={isWalletConnected} handleWalletConnect={handleWalletConnect} />;
      case 'Automate': return <BotTradingScreen 
          isBotRunning={isBotRunning} setIsBotRunning={setIsBotRunning} eventLog={eventLog}
          modules={modules} totalCapital={totalCapital} totalPnl={totalPnl}
          initialCapital={INITIAL_CAPITAL} handleClearLog={handleClearLog}
          scalpingRiskProfile={scalpingRiskProfile} setScalpingRiskProfile={setScalpingRiskProfile}
          onUpdateModule={handleUpdateModule}
          liveCoinData={liveCoinData} // Pass liveCoinData to BotTradingScreen
        />;
      case 'Market': return <MarketMosaicScreen watchlist={watchlist} toggleWatchlist={toggleWatchlist} />;
      case 'Tokens': return <TokenDiscoveryScreen watchlist={watchlist} toggleWatchlist={toggleWatchlist} liveCoinData={liveCoinData} />; // Use new component
      case 'Simulation': return <SimulationScreen liveCoinData={liveCoinData} />;
      case 'Intel': return <NewsScreen />;
      case 'Governance': return <GovernanceScreen />;
      case 'Academy': return <LearnScreen />;
      case 'Profile': return <ProfileScreen areSmartAlertsEnabled={areSmartAlertsEnabled} setAreSmartAlertsEnabled={setAreSmartAlertsEnabled} totalCapital={totalCapital} totalPnl={totalPnl} profileData={profileData} setProfileData={setProfileData} />;
      default: return <DashboardScreen totalCapital={totalCapital} totalPnl={totalPnl} initialCapital={INITIAL_CAPITAL} theme={theme} liveCoinData={liveCoinData} modules={modules} />;
    }
  };

  if (showOnboarding) {
    return <OnboardingScreen onComplete={handleOnboardingComplete} />;
  }

  return (
    <div className="min-h-screen bg-dark-bg font-sans text-slate-50 transition-colors duration-300">
      <CosmicBackground />
      <Sidebar 
        activeScreen={activeScreen} 
        setActiveScreen={(s) => { setActiveScreen(s); setSidebarOpen(false); }} 
        isSidebarOpen={isSidebarOpen}
        theme={theme}
        toggleTheme={toggleTheme}
      />
      <div className="md:ml-64 transition-all duration-300 relative z-10">
        <Header 
          activeScreenTitle={screenTitleMap[activeScreen]} 
          onMenuClick={() => setSidebarOpen(!isSidebarOpen)}
          onProfileClick={() => setActiveScreen('Profile')}
          onNotificationsClick={handleOpenNotifications}
          onWalletClick={handleWalletConnect}
          unreadNotificationCount={unreadNotificationCount}
          isWalletConnected={isWalletConnected}
          profileData={profileData}
          totalCapital={totalCapital}
          xp={xp}
          isMobile={isMobile}
        />
        <TickerTape assets={tickerAssets} />
        <main className="pb-16 md:pb-0">
           <AnimatePresence mode="wait">
            <motion.div
              key={activeScreen}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25 }}
            >
              {renderScreen()}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
      <BottomNav 
        activeScreen={activeScreen}
        setActiveScreen={(s) => { setActiveScreen(s); setSidebarOpen(false); }}
      />
      <NotificationCenter notifications={notifications} onDismiss={removeNotification} />
      <NotificationPanel 
        isOpen={isNotificationPanelOpen}
        onClose={() => setIsNotificationPanelOpen(false)}
        notifications={notifications}
        onClear={handleClearNotifications}
      />
      {isSidebarOpen && <div onClick={() => setSidebarOpen(false)} className="fixed inset-0 bg-black/50 z-30 md:hidden"></div>}
      <motion.button
        whileHover={{ scale: 1.1, boxShadow: '0 0 25px rgba(180, 0, 255, 0.8)' }}
        whileTap={{ scale: 0.9 }}
        onClick={() => {
            setActiveScreen('Community');
            setInitialChatChannel('AI');
        }}
        className="fixed bottom-20 md:bottom-6 right-4 md:right-6 z-50 w-16 h-16 bg-accent-purple rounded-full flex items-center justify-center text-white shadow-lg shadow-purple-500/50"
        aria-label={t('openAIAssistant')}
      >
        <motion.div
            animate={{ scale: [1, 1.2, 1], rotate: [0, 10, -10, 0] }}
            transition={{ duration: 2, repeat: Infinity, repeatDelay: 3 }}
        >
        <BrainCircuit size={32} />
        </motion.div>
      </motion.button>
      
      <AnimatePresence>
        {isWalletModalOpen && (
             <Modal isOpen={isWalletModalOpen} onClose={() => setIsWalletModalOpen(false)} onConfirm={() => {}} title={t('connectWallet')}>
                <div className="text-center p-4">
                    {isConnectingWallet ? (
                        <>
                         <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }} className="w-12 h-12 border-4 border-t-accent-cyan border-slate-700 rounded-full mx-auto" />
                         <p className="text-slate-400 mt-4 animate-pulse">{t('connecting')}</p>
                        </>
                    ) : isWalletConnected ? (
                         <>
                            <motion.div initial={{ scale: 0.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="w-16 h-16 bg-green-500/20 text-green-500 rounded-full mx-auto flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                            </motion.div>
                            <p className="font-semibold text-slate-50 mt-4">{t('walletConnected')}</p>
                         </>
                    ) : null}
                </div>
             </Modal>
        )}
      </AnimatePresence>
    </div>
  );
};

export default App;